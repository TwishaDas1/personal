import { Component, OnInit } from '@angular/core';
import { CheckconfigService } from '../../Services/checkconfig.service';
import { JobItem } from '../../Model/JobItem';
import { UserService } from '../../../SDTM/Services/user.service';
import { State, process } from '@progress/kendo-data-query';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { orderBy } from '@progress/kendo-data-query';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import {SortDescriptor} from '@progress/kendo-data-query';
import { map } from 'rxjs/operators/map';



@Component({
  selector: 'check-configuration',
  templateUrl: './check-configuration.component.html',
  styleUrls: ['./check-configuration.component.css']
})


export class CheckConfigurationComponent implements OnInit {
  public view: GridDataResult;
  dataResult: JobItem[] = [];
  public domainStatuses: any[];
  public popupType: any;
  public jobItem: JobItem;
  appName: string;
  configTypeIcons: Object[];
  configTypeImage: string;
  configTypeTitle: string;
  statusShowOptions = false;
  statusDrpSelected = false;
  studyDrpSelected = false;
  studyShowOptions = false;
  categoryDrpSelected = false;
  categoryShowOptions = false;
  checkDrpSelected = false;
  checkShowOptions = false;
  formDrpSelected = false;
  formshowOptions = false;
  therapeuticAreaDrpSelected = false;
  therapeuticAreasShowOptions = false;
  variableShowOptions = false;
  variableDrpSelected = false;
  SourceTypeDrpSelected = false;
  SourceTypeshowOptions = false;
  SourceFileDrpshowOptions = false;
  SourceFileDrpSelected = false;
  public therapeuticAreas: any[];
  public studyTitles: any[];
  public studyCategory: any[];
  public studyCheck: any[];
  public studyCheckCategory: any[];
  public studyStatus: any[];
  public form: any[];
  public variables: any[];
  public sourceFile: any[];
  public sourceVariable: any[];
  public searchDqChecks: any = {};
  public isAdminUser = false;
  public dqJobs: JobItem[] = [];
  public checkbox = false;
  public isCheckboxSelected = false;
  public selectedItemsList = [];
  public gridState: State = {
    sort:[{ field: "dqCheck; category; variable; input"}],
    skip: 0,
    take: 10
  };
  pageSize = 10;
  private msg: any;
  public statusColor: any;
  public run = false;
  public domain = false;
  public dqJobRun = [];
  public spinner: boolean = false;
  public action: boolean = true;
  public checkCategory: any[] = [];
  public showCheck: boolean = false;
  public fileSourceVariable: any[] = [];
  public dependencyArray: any[]=[];
  public dependencyArrayDV: any[]=[];
  public dependencyArrayDependency: any[]=[];
    constructor(private checkConfigService: CheckconfigService, private userService: UserService,
    private http: HttpClient) { }
  ngOnInit() {

    const userDetails = this.userService.getUser();
    if (userDetails !== undefined && userDetails.userName === 'admin') {
      this.isAdminUser = true;
    }

    // this.checkConfigService.getJobs().subscribe(jobs => this.dqJobs = jobs);
    this.configTypeImage = "assets/images/NewStudyConf.png";
    this.configTypeTitle = "Data Quality Checks";
    this.configTypeIcons = [
      { "icontitle": "Create New Check", "iconImageSrc": "assets/images/AddStudy.png", "action": "add", "inputParam": "" },
      { "icontitle": "Upload", "iconImageSrc": "assets/images/NewNote.png", "action": "", "inputParam": "" },
      { "icontitle": "Download", "iconImageSrc": "assets/images/studyDownload.png", "": "", "inputParam": "" },
      { "icontitle": "Refresh", "iconImageSrc": "assets/images/Refresh.png", "action": "refresh" },
      { "icontitle": "Report", "iconImageSrc": "assets/images/Email.png", "action": "report" },
      { "icontitle": "Import", "iconImageSrc": "assets/images/RightImage1.png", "action": "import" }

    ];
    this.appName = "Data Quality";

    this.checkConfigService.fetchDomainStatuses().subscribe(data => {
      this.domainStatuses = data;
    });
    this.checkConfigService.fetchTherapeuticAreas().subscribe(data => {
      this.therapeuticAreas = data;
    });
    this.checkConfigService.fetchStudyTitles().subscribe(data => {
      this.studyTitles = data;
    });
    this.checkConfigService.fetchStudyCategory().subscribe(data => {
      this.studyCategory = data;
    });
    this.checkConfigService.fetchStudyCheck().subscribe(data => {
      this.studyCheck = data;
    });
    this.checkConfigService.fetchStudyCheckCategory().subscribe(data => {
      this.studyCheckCategory = data;
    });
    this.checkConfigService.fetchStatus().subscribe(data => {
      this.studyStatus = data;
    });
    this.checkConfigService.fetchForm().subscribe(data => {
      this.form = data;
    });

    this.checkConfigService.fetchSourceVariable().subscribe(data => {
      this.sourceVariable = data;
    });
    this.checkConfigService.getDependency().subscribe(data => {
      this.dependencyArray=data; 
    });
  }


  addHandlerIconClick(data) {
    if (!data.flag) {
      return;
    } else {
      this.addHandler(data.flag);
    }
  }

  public addHandler(flag: any) {
    this.jobItem = new JobItem();
    this.jobItem.form = this.searchDqChecks.form;
    this.jobItem.study = this.searchDqChecks.study;
    this.jobItem.formStatus = this.searchDqChecks.formStatus;
    console.log(this.jobItem);
    this.popupType = flag;
    if (this.popupType === "refresh" && this.searchDqChecks.study) {

      this.filterDqChecks();
    }
  }

  public cancelHandler() {
    this.jobItem = undefined;
  }

  public importHandler(template: JobItem) {
   // this.checkConfigService.ImportCustomChecks(template);
   console.log(template);
    this.parseData(template);
    this.jobItem = undefined;
  }

  public saveHandler(template: JobItem) {
    console.log()
    this.checkConfigService.saveCustomChecks(template);
    this.filterDqChecks();
    this.jobItem = undefined;
  }

  public updateHandler(template: JobItem) {
    console.log(template);
    this.checkConfigService.updateCustomChecks(template).subscribe(data => {this.dataChange(data)
    });
    this.jobItem = undefined;
  }

  public downloadHandler(template: JobItem) {
    this.jobItem = undefined;
  }

  public emailHandler(template: JobItem) {
    this.jobItem = undefined;
  }

  public editHandler({ dataItem }) {
    this.jobItem = dataItem;
    if (this.jobItem && this.jobItem.checkLogic) {
      this.setDynamicFields();
    }
    this.popupType = 'edit';
  }
    public removeHandler({ dataItem }) {
    this.jobItem = dataItem;
    this.popupType = 'delete';
  }
  deletedItem: any;
  public deleteHandler(template: JobItem) {
    this.checkConfigService.deleteCustomCheck(template).subscribe(data => {
      this.dataDelete(data)
      //this.deletedItem = data;
    });
    //this.deletedItem = data;
    this.filterDqChecks();
    this.jobItem = undefined;
  }

  public flagHandler(template: JobItem) {
    this.checkConfigService.updateFlags(template, this.selectedItemsList, this.checkbox, this.searchDqChecks).subscribe(data => {
    });
    for (let i = 0; i < this.selectedItemsList.length; i++) {
      console.log("flagHandler");
      this.view.data.find(job => job.uniqueId == this.selectedItemsList[i]).notes = template.notes;
    }
    this.filterDqChecks();
    this.jobItem = undefined;
    this.checkbox = false;
    this.isCheckboxSelected = false;
  }

  public noteHandler(template: JobItem) {
    this.checkConfigService.updateNotes(template, this.selectedItemsList, this.checkbox, this.searchDqChecks)
       .subscribe(data => {
         console.log("inside")
       });
   
      for (let i = 0; i < this.selectedItemsList.length; i++) {
        console.log("outside")
      this.view.data.find(job => job.uniqueId == this.selectedItemsList[i]).notes = template.notes;
        //dqJobs
      }

    this.filterDqChecks();
    this.jobItem = undefined;
    this.checkbox = false;
    this.isCheckboxSelected = false;
  }
  public statusDrp(): void {
    if (this.statusDrpSelected === false) {
      this.statusShowOptions = true;
      this.statusDrpSelected = true;
    } else {
      this.statusShowOptions = false;
      this.statusDrpSelected = false;
    }
  }
  public studyDrp(): void {
    if (this.studyDrpSelected === false) {
      this.studyShowOptions = true;
      this.studyDrpSelected = true;
    } else {
      this.studyShowOptions = false;
      this.studyDrpSelected = false;
    }
  }
  public categoryDrp(): void {
    if (this.categoryDrpSelected === false) {
      this.categoryShowOptions = true;
      this.categoryDrpSelected = true;
    } else {
      this.categoryShowOptions = false;
      this.categoryDrpSelected = false;
    }
  }
  public checkDrp(): void {
    if (this.checkDrpSelected === false) {
      this.checkShowOptions = true;
      this.checkDrpSelected = true;
    } else {
      this.checkShowOptions = false;
      this.checkDrpSelected = false;
    }
  }
  public statDrp(): void {
    if (this.statusDrpSelected === false) {
      this.statusShowOptions = true;
      this.statusDrpSelected = true;
    } else {
      this.statusShowOptions = false;
      this.statusDrpSelected = false;
    }
  }
  public formDrp(): void {
    if (this.formDrpSelected === false) {
      this.formshowOptions = true;
      this.formDrpSelected = true;
    } else {
      this.formshowOptions = false;
      this.formDrpSelected = false;
    }
  }
  public StudyTypeDrp(): void {
    if (this.SourceTypeDrpSelected === false) {
      this.SourceTypeshowOptions = true;
      this.SourceTypeDrpSelected = true;
    } else {
      this.SourceTypeshowOptions = false;
      this.SourceTypeDrpSelected = false;
    }
  }

  public SourceFileDrp(): void {
    if (this.SourceFileDrpSelected === false) {
      this.SourceFileDrpshowOptions = true;
      this.SourceFileDrpSelected = true;
    } else {
      this.SourceFileDrpshowOptions = false;
      this.SourceFileDrpSelected = false;
    }
  }
  public therapeuticAreaDrp(): void {
    if (this.therapeuticAreaDrpSelected === false) {
      this.therapeuticAreasShowOptions = true;
      this.therapeuticAreaDrpSelected = true;
    } else {
      this.therapeuticAreasShowOptions = false;
      this.therapeuticAreaDrpSelected = false;
    }
  }

  public variableDrp(): void {
    if (this.variableDrpSelected === false) {
      this.variableShowOptions = true;
      this.variableDrpSelected = true;
    } else {
      this.variableShowOptions = false;
      this.variableDrpSelected = false;
    }
  }

  public clear() {
    this.checkConfigService.fetchStudyTitles().subscribe(data => {
      this.studyTitles = data;
    });
    this.view={
      data:[],
      total:0
    }
   this.dataResult=[];
   this.dependencyArrayDV=[];
   this. dependencyArrayDependency=[];
    this.checkCategory = [];
    this.searchDqChecks = {};
    this.variables = [];
    this.showCheck = false;
    this.studyShowOptions = false;
    this.studyDrpSelected = false;
    this.formDrpSelected = false;
    this.formshowOptions = false;
    this.categoryDrpSelected = false;
    this.categoryShowOptions = false;
    this.checkDrpSelected = false;
    this.checkShowOptions = false;
    this.SourceTypeDrpSelected = false;
    this.SourceTypeshowOptions = false;
    this.SourceFileDrpshowOptions = false;
    this.SourceFileDrpSelected = false;
    this.variableDrpSelected = false;
    this.variableShowOptions = false;
    this.therapeuticAreaDrpSelected = false;
    this.therapeuticAreasShowOptions = false;
    this.statusShowOptions = false;
    this.statusDrpSelected = false;
    this.dqJobs = [];
    this.checkbox = false;
    this.isCheckboxSelected = false;
    this.selectedItemsList = [];
  }

  filterStudies(therapeuticArea: any) {
    if (therapeuticArea === 'undefined') {
      // do nothing
    } else if (therapeuticArea === 'all') {
      this.checkConfigService.fetchStudyTitles().subscribe(data => {
        this.studyTitles = data;
      });
    } else {
      this.checkConfigService.fetchStudiessBytherapeuticArea(therapeuticArea).subscribe(data => {
        this.studyTitles = data;
      });
    }
  }

  public getVariables(table: any) {

    if (this.form != null) {
      const selectedItem = this.form.find((x: any) => x[0] === table);
      if (selectedItem) {

        this.searchDqChecks.formName = selectedItem[1];
      }
    }
    // this.checkConfigService.fetchVariables(table).subscribe(data => {
    //   this.variables = data;
    // });
  }

  public getStudy(): String {
    if (this.searchDqChecks != null && this.searchDqChecks.study != null && this.searchDqChecks.form != null) {
      return this.searchDqChecks.study;
    }
  }

  public getDomain(): String {

    let selectedDomain = '';
    //console.log(selectedDomain);
    if (this.searchDqChecks != null && this.searchDqChecks.form != null
      && this.form != null && this.form.length > 0) {
        for (let i = 0; i < this.form.length; i++) {
//console.log(this.searchDqChecks.form+"2222222");
         if (this.sourceVariable[i].formName === this.searchDqChecks.form) {
//console.log(this.sourceVariable[i].formDescription);
          selectedDomain = this.sourceVariable[i].formDescription;
         }
          //console.log(selectedDomain+"1111111")
          // break;
        
      }

      for (let obj of this.dqJobs) {
        this.searchDqChecks.formStatus = obj.formStatus;
        this.getColor(this.searchDqChecks.formStatus);
        break;
      }
      return selectedDomain + ' Form';
    }
    return null;
  }


  onItemSelect(item: any) {
    this.selectedItemsList.push(item.uniqueId);
  }

  public switchCheckFlag(dataItem, flag) {
    dataItem.checkFlag = flag;
    this.checkConfigService.updateCheckFlag(dataItem, this.searchDqChecks).subscribe(data => {
    });
    this.filterDqChecks();
  }

  public actionOnJob(item: any, action) {

    if (action == 'Disable') {
      item.jobDisabled = true;
      this.updateStatus(item, 'Disabled');

    } else {

      //Need to proceed only if action is not 'Disable'

      if (action == 'Enable') {
        item.jobDisabled = false;
        item.jobStatus = 'Not started';
        this.updateStatus(item, 'Not started');// this will ideally be from Disable to Enable

      } else {
        if (action == 'Run') {
          item.jobIsRunning = true;

        } else if (action == 'Cancel') {
          item.jobIsRunning = false;
        }

        let headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`http://10.0.2.156?Study_name=${item.study}&domain_array=${item.domainCode}&Action=${action}`, { headers: headers })
          .subscribe(data => { this.msg = data });
      }
    }
  }


  public updateStatus(item, action) {
    const searchUrl = '/api/CDR/DQ/updateStatus';
    const url = `${searchUrl}/${item.uniqueId}/${action}`;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put(url, item, { headers: headers }).subscribe(data => {
    });
  }


  public setDynamicFields() {
    let arr = [];
    let localArr = [];
    let localLogic = this.jobItem.checkLogic;
    let localCheck = this.jobItem.dqCheck;
    arr = localLogic.split(';');
    for (let i = 0; i < arr.length - 1; i++) {
      let temp = arr[i];
      localArr = temp.split('=');
      this.setFormFieldValue(localArr[0], localArr[1]);
    }
  }

  public setFormFieldValue(field, value) {
    if (field === 'SV') {
      // Source Variable SV
      this.jobItem.sourceVariable = value;
    } else if (field === 'FV') {
      // Form Variable FV
      this.jobItem.variable = value;
    } else if (field === 'LT') {
      // Length LT
      this.jobItem.checkLength = value;
    } else if (field === 'DV') {
      // Dependent Variable DV
      this.jobItem.dependentVariable = value;
    } else if (field === 'IV') {
      // Independent Variable IV
      this.jobItem.independentVariable = value;
    } else if (field === 'DD') {
      // Dependency DD
      this.jobItem.dependency = value;
    } else if (field === 'LR') {
      // Lower Range LR
      this.jobItem.lowerRange = value;
    } else if (field === 'UR') {
      // Upper Range UR
      this.jobItem.upperRange = value;
    } else if (field === 'ID') {
      // Initial Date ID
      this.jobItem.initialDate = value;
    } else if (field === 'SD') {
      // Secondary Date SD
      this.jobItem.secondaryDate = value;
    }
  }



  public getColor(status: any) {


    switch (status) {
      case 'Not Started': this.statusColor = 'White'; break;
      case 'In Progress': this.statusColor = 'Grey'; break;
      case 'Ready for Review': this.statusColor = 'Yellow'; break;
      case 'Approved': this.statusColor = 'Green'; break;
      case 'Rejected': this.statusColor = 'Red'; break;
      default: this.statusColor = 'Blue'; break;
    }

  }

  tempData: any;

  //public updateFormStatus(template: JobItem) {

  //this.checkConfigService.updateFormStatus(template).subscribe(data => {
  //this.tempData = data;
  // });

  //this.jobItem = undefined;
  //}


  public confirmFormStatus(value: any) {

    // if ((value === 'Approved' || value === 'Rejected') && !this.isAdminUser) {

    // return false;
    // }
    //this.searchDqChecks.checkStatus
    // if (value === 'Not Started' || value === 'In Progress') {
    //
    this.jobItem = new JobItem();
    this.jobItem.study = this.searchDqChecks.study;
    this.jobItem.form = this.searchDqChecks.formName;
    this.jobItem.formStatus = value;

    // this.updateFormStatus(this.jobItem);
    // } else {

    this.searchDqChecks.formStatus = value;
    this.addHandler('formStatus');
    // }
  }

  public confirmHandler(jobItem: JobItem) {
    this.jobItem.study = this.searchDqChecks.study;
    this.jobItem.form = this.searchDqChecks.form;
    this.jobItem.formStatus = jobItem.formStatus;
    this.checkConfigService.updateFormStatus(this.jobItem)
      .subscribe(data => {
        this.dqJobs = data;
      });
    // this.filterDqChecks();
    this.jobItem = undefined;
    this.domain = true;
  }
  public onRunSelect() {
    if (this.run === false) {
      this.run = true;
    }
    else {
      this.run = false;
    }
  }
  public reset() {

    this.selectedItemsList = [];
    this.spinner = false;
    this.action = true;
  }
  public runForAllSelectedDomains() {
    if (this.selectedItemsList.length !== 0) {

      this.spinner = true;
      this.action = false;
    }

  }
  public spinnerFunction() {
    if ((this.spinner == true) && (this.action == false)) {
      this.spinner = !this.spinner;
      this.action = !this.action;
    }
  }

  public resetCheck() {
    this.checkCategory = [];
  }
  public studyCategoryCheck(value) {
    console.log(value);
    if(value=="all"){
      console.log("all");
      this.showCheck = false;
    }
    else{
      console.log("not all");
    let a = 0;
    this.showCheck = true;
    value = value.toLowerCase();
    for (let i = 0; i < this.studyCheckCategory.length; i++) {
      if (value == this.studyCheckCategory[i].category) {
        this.checkCategory[a] = this.studyCheckCategory[i].check;
        a++;
      }
    }
  }
}
  public studyFileVariable(value) {
    this.getDependencyDropdown(value);
    let a = 0;
    for (let i = 0; i < this.sourceVariable.length; i++) {
      if (value == this.sourceVariable[i].formName) {
        this.fileSourceVariable[a] = this.sourceVariable[i].formVariableName;
        a++;
      }
    }
  }
  public resetVariable() {
    this.fileSourceVariable = [];
  }
  public getGridData() {
    if (this.searchDqChecks.form && this.searchDqChecks.study) {
      console.log("getGrid");
      this.filterDqChecks();
    }
 }
  public pageChange(event: PageChangeEvent): void {
    this.gridState.skip = event.skip;
    this.loadTable();
  }

public sortChange(sort: SortDescriptor[]): void {
  this.gridState.sort = sort;
  this.sortTable();
}
public sortTable(): void{
  this.view = {
    data: orderBy(this.view.data, this.gridState.sort),
    total: this.dataResult.length
};
}

public loadTable(): void {
  this.view = {
    data: this.dataResult.slice(this.gridState.skip, this.gridState.skip + this.pageSize),
    total: this.dataResult.length
  };
    this.sortTable();
}
public filterDqChecks() {
   this.checkConfigService.filterDqChecks(this.searchDqChecks).subscribe(data => { this.parseData(data) });
}
 public parseData(results){
  this.dataResult = [];
  //this.dependencyArray=[];
  for (let item of results) {
    let customObj = new JobItem();
    //Model values in LHS and DB columns in RHS
    customObj.uniqueId = item.uniqueId;
    customObj.study = item.study;
    customObj.form = item.form;
    customObj.category = item.category;
    customObj.dqCheck = item.dqCheck;
    customObj.variable = item.variable;
    customObj.input = item.input;
    customObj.jobStatus = item.jobStatus;
    customObj.jobStartTimestamp = item.job_start_timestamp;
    customObj.jobEndTimestamp = item.job_end_timestamp;
    customObj.message = item.message;
    customObj.checkEnable = item.checkEnable;
    //customObj.checkLogic = item.checkLogic;
    customObj.checkFlag = item.checkFlag;
    customObj.jobIsRunning = item.jobIsRunning;
    customObj.jobDisabled = item.jobDisabled;
    customObj.sourceVariable = item.variable;
    customObj.independentVariable = item.variable;
    
    if(customObj.dqCheck=="Dependency"){
  customObj.dependentVariable = item.input;
  customObj.dependency = item.input2;
    }
    if(customObj.dqCheck=="Range"){
    customObj.upperRange = item.input;
    customObj.lowerRange = item.input2;
    }
    if(customObj.dqCheck=="Chronological"){
    customObj.initialDate = item.input;
    customObj.secondaryDate = item.input2;
    }
    customObj.checkLength = item.input;
    customObj.formStatus = item.formStatus;
   
    this.dataResult.push(customObj);
    }
    this.loadTable();
  }

 public dataChange(template){
   for(let i=0;i<this.view.data.length;i++){
   if(template.uniqueId==this.view.data[i].uniqueId){
    this.view.data[i]=template;
   }
   if(this.view.data[i])
   {
     
    this.view.data[i].sourceVariable = this.view.data[i].variable;
    console.log(this.view.data[i].sourceVariable)
    this.view.data[i].independentVariable = this.view.data[i].variable;
    if(this.view.data[i].dqCheck=="Dependency"){
      this.view.data[i].dependentVariable = this.view.data[i].input;
      this.view.data[i].dependency = this.view.data[i].input2;
      }
      if(this.view.data[i].dqCheck=="Range"){
        this.view.data[i].upperRange = this.view.data[i].input;
        this.view.data[i].lowerRange = this.view.data[i].input2;
      }
      if(this.view.data[i].dqCheck=="Chronological"){
        this.view.data[i].initialDate =this.view.data[i].input;
        this.view.data[i].secondaryDate = this.view.data[i].input2;
      }
      if(this.view.data[i].dqCheck=="Data Length")
      this.view.data[i].checkLength =this.view.data[i].input;
   }
   
 }
}
public dataDelete(template){
  if(template==1){
  this.filterDqChecks();
  }
}
public getDependencyDropdown(template){
  console.log(template);
  template=template.toLowerCase();
  console.log(template);
  let i=0;
  let a=0;
  for(i=0;i<this.dependencyArray.length;i++){
 if(template==this.dependencyArray[i].form)
 {
   this.dependencyArrayDV[a]=this.dependencyArray[i].input;
   this.dependencyArrayDependency[a]=this.dependencyArray[i].input2;
   a++;
 }
}
}
}
