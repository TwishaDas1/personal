import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { JobItem } from '../../Model/JobItem';
import { CheckconfigService } from '../../Services/checkconfig.service';

@Component({
  selector: 'dq-custom-checks',
  templateUrl: './custom-checks.component.html',
  styleUrls: ['./custom-checks.component.css']
})
export class CustomChecksComponent implements OnInit {
  [x: string]: any;
            @Input() public categories: any[];
            @Input() public checks: any[];
            @Input() public variables: any[];
            @Input() public sourceVariables: any[];
           // @Input() public sourceVariable:any[];
            public categoryData:any[];
            public checkData:any[];
            public sourceVariable:any[];
            public active = false;
            public opened = false;
            public errorMsg: string;
            public dqCustomCheck: FormGroup = new FormGroup({
              'study': new FormControl(),
              'form': new FormControl(),
              'category': new FormControl(),
              'dqCheck': new FormControl(),
              'variable': new FormControl(),
              'input': new FormControl()
          });
          checkDescription: String;
          categoryDescription: String;
          tooltip: String;
          @Input() public popupType;

          @Input() public set model(jobItem: JobItem) {
            console.log(this.dqCustomCheck.value.form);
              this.dqCustomCheck.reset(jobItem);
              
              this.active = jobItem !== undefined && this.popupType === 'add';

              if(this.active && this.popupType)
              {
                console.log(this.dqCustomCheck.value.form);
              }
          }

          @Output() cancel: EventEmitter<any> = new EventEmitter();
          @Output() save: EventEmitter<any> = new EventEmitter();

          constructor(private checkConfigService: CheckconfigService) { }

          ngOnInit() {
            this.checkConfigService.fetchStudyCategory().subscribe(data => {
              this.categoryData = data;
          });
          this.checkConfigService.fetchStudyCheck().subscribe(data => {
            this.checkData = data;
          });
          this.checkConfigService.fetchSourceVariable().subscribe(data => {
            this.sourceVariable = data;
          });
        }
          public close() {
            this.opened = false;
          }

          public onCancel(e): void {
              e.preventDefault();
              this.closeForm();
          }

          private closeForm(): void {
              this.errorMsg = '';
              this.active = false;
              this.cancel.emit();
          }

          public onSave(e): void {
            e.preventDefault();
            this.save.emit(this.dqCustomCheck.value);
            this.active = false;
          }
        public onSelect(categoryName: String) {
            for (let i = 0; i < this.categoryData.length; i++) {
              if (categoryName === this.categoryData[i].categoryName) {
                this.categoryDescription = this.categoryData[i].categoryDescription;
                break;
              }
            }
            this.tooltip = this.categoryDescription;
        }
          public onSelectCheck(checkName: String) {
              for (let i = 0; i < this.checkData.length; i++) {
                if (checkName === this.checkData[i].checkName) {
                  this.checkDescription = this.checkData[i].checkDescription;
                  break;
                }
              }
              this.tooltip = this.checkDescription;
          }
}
