import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataqualityConfirmstatusComponent } from './dataquality-confirmstatus.component';

describe('DataqualityConfirmstatusComponent', () => {
  let component: DataqualityConfirmstatusComponent;
  let fixture: ComponentFixture<DataqualityConfirmstatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataqualityConfirmstatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataqualityConfirmstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
