import { Component, OnInit } from '@angular/core';
import { CheckconfigService } from '../../Services/checkconfig.service';
import { SeriesLabels } from '@progress/kendo-angular-charts';
import { LegendLabels } from '@progress/kendo-angular-charts';

@Component({
  selector: 'dataquality-home',
  templateUrl: './dataquality-home.component.html',
  styleUrls: ['./dataquality-home.component.css']
})
export class DataqualityHomeComponent implements OnInit {
  appName: string;
  studyList: any[] = [];
  study: Object;

  constructor(private checkConfigService: CheckconfigService) { }


  ngOnInit() {
    this.appName = " - Data Quality";

    this.checkConfigService.getStudiesForDashboard().subscribe(data => {
      this.studyList = data.studies;
    });
  }

  public seriesLabels: SeriesLabels = {
    visible: true, // Note that visible defaults to false
    padding: 3,
    font: 'bold 12px Open Sans',
  };


  public seriesPieLabels: SeriesLabels = {
    visible: true, // Note that visible defaults to false
    font: 'bold 10px Open Sans',
    color: 'white',
    position: 'center',
  };

  public legendLabels: LegendLabels = {
    font: '10px Open Sans',
    color: 'black'
  };

  public deleteNotification(studyId, notification) {
    let study = this.studyList.find(obj => obj.studyId = studyId);
    let notifications = study.notifications;
    let index = notifications.findIndex(d => d.id === notification.id);
    notifications.splice(index, 1);//remove element from array

    this.checkConfigService.deleteNotification(notification.id).subscribe(data => {
    });

  }

  public notificationRead(study, notification) {
    study.openNotifications = study.openNotifications + 1;
    study.newNotifications = study.newNotifications - 1;
    notification.notificationStop = 'Y';

    this.checkConfigService.notificationStop(notification.id).subscribe(data => {
      console.log(this.studyList);
    });
  }

}
