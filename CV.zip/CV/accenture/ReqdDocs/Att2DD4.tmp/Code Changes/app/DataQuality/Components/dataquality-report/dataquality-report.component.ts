import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { JobItem } from '../../Model/JobItem';
import { process } from '@progress/kendo-data-query';
import { checkList } from '../../Model/checks';
import { CheckconfigService } from '../../Services/checkconfig.service';

@Component({
  selector: 'dq-dataquality-report',
  templateUrl: './dataquality-report.component.html',
  styleUrls: ['./dataquality-report.component.css']
})
export class DataqualityReportComponent implements OnInit {

  public active = false;
  public opened = false;
  public errorMsg: string;
  public dqReportForm: FormGroup = new FormGroup({
    'study': new FormControl()
  });

  @Input() public popupType;

  @Input() public set model(jobItem: JobItem) {
    this.dqReportForm.reset(jobItem);
    this.active = jobItem !== undefined && this.popupType === 'report';
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() download: EventEmitter<any> = new EventEmitter();
  @Output() email: EventEmitter<any> = new EventEmitter();

  constructor(private checkConfigService: CheckconfigService) { }

  dqJobs: JobItem[] = [];
  status: string;

  ngOnInit() {
    this.checkConfigService.getJobs().subscribe(jobs => this.dqJobs = jobs);
  }

  public close() {
    this.opened = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.errorMsg = '';
    this.active = false;
    this.cancel.emit();
  }

  public onDownload(e): void {
    e.preventDefault();
    this.download.emit(this.dqReportForm.value);
    this.active = false;
  }

  public sendEmail(): void {
    this.checkConfigService.sendEmail().subscribe(string => this.status = string);
    this.active = false;
  }

  public group: any[] = [{
    field: 'Category.CategoryName'
  }];


  //  public excelData: any[] = this.dqJobs;

  public headerPaddingCells: any = {
    background: '#ff0000'
  };

}
