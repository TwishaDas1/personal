import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dataquality',
  templateUrl: './dataquality.component.html',
  styleUrls: ['./dataquality.component.css']
})
export class DataqualityComponent implements OnInit {

  navBarItems: Object[];
  appName: string;

  constructor() { }

  ngOnInit() {
    this.appName = " - Data Quality";
    this.navBarItems = [
      { "navBarTitle": "Home", "navBarLink": "" },
      { "navBarTitle": "Data Quality Checks", "navBarLink": "checkConfig" }
    ]

  }


}
