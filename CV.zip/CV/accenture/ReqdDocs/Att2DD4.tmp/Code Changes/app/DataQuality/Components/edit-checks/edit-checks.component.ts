import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { JobItem } from '../../Model/JobItem';
import { CheckconfigService } from '../../Services/checkconfig.service';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Http } from '@angular/http';
@Component({
  selector: 'dq-edit-checks',
  templateUrl: './edit-checks.component.html',
  styleUrls: ['./edit-checks.component.css']
})
export class EditChecksComponent implements OnInit {
  [x: string]: any;
  @Input() public categories: any[];
  @Input() public checks: any[];
  @Input() public variables: any[];
  @Input() public sourceVariables:any[];
  @Input() public dependentVariable: any[];
  @Input() public dependency: any[];
            //public checkData: any[];
            public switches = ['Enabled', 'Disabled'];
            public active = false;
            public opened = false;
            public errorMsg: string;
            public dqEditCheck: FormGroup = new FormGroup({
              'uniqueId': new FormControl(),
              'study': new FormControl(),
              'form': new FormControl(),
              'category': new FormControl(),
              'dqCheck': new FormControl(),
              'variable': new FormControl(),
              'checkLogic': new FormControl(),
              'input': new FormControl(),
              'checkEnable': new FormControl(),
              'jobStatus': new FormControl(),
              'job_start_timestamp': new FormControl(),
              'job_end_timestamp': new FormControl(),
              'message': new FormControl(),
              'notes': new FormControl(),
              'checkFlag': new FormControl(),
              'sourceVariable': new FormControl(),
              'independentVariable': new FormControl(),
              'dependentVariable': new FormControl(),
              'dependency': new FormControl(),
              'upperRange': new FormControl(),
              'lowerRange': new FormControl(),
              'initialDate': new FormControl(),
              'secondaryDate': new FormControl(),
              'checkLength': new FormControl(),
          });
          categoryDescription:String;
          checkDescription: String;
          tooltip: String;
          tooltipc: String;
          public sourceVariable: any[];
          @Input() public popupType;

          @Input() public set model(jobItem: JobItem) {
              this.dqEditCheck.reset(jobItem);
              this.active = jobItem !== undefined && this.popupType === 'edit';
              if (this.active && jobItem.dqCheck) {
                this.onSelectCheck(jobItem.dqCheck);
                console.log(jobItem.dqCheck);
                } 
              if (this.active && jobItem.category) {
                  this.onSelect(jobItem.category);
                  console.log(jobItem.category);
             }
             //this.getDependencyDropdown(jobItem.form);
            //  console.log(this.dqEditCheck.value.sourceVariable);
            //  console.log(this.dqEditCheck.value.initialDate);
            //  console.log(this.dqEditCheck.value.secondaryDate);
             console.log(this.variables);
              // if (this.active && jobItem.checkLogic) {
                //  this.setDynamicFields();
             // }
          }
  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() update: EventEmitter<any> = new EventEmitter();

          constructor(private checkConfigService: CheckconfigService, private http: HttpClient) { }

          ngOnInit() {
            this.checkConfigService.fetchSourceVariable().subscribe(data => {
              this.sourceVariable = data;
            });
            
          }
          


  public close() {
    this.opened = false;
    
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.errorMsg = '';
    this.active = false;
    this.sourceVariables = [];
    this.dependentVariable = [];
    this.dependency = [];
    this.cancel.emit();
  }

  public onUpdate(e): void {
    e.preventDefault();
    this.update.emit(this.dqEditCheck.value);
    this.active = false;


  }
  public onSelectCheck(checkName: string) {
    for (let i = 0; i < this.checks.length; i++) {
      if (checkName === this.checks[i].checkName) {
        this.checkDescription = this.checks[i].checkDescription;
        break;
      }
    }
    this.tooltipc = this.checkDescription;

  }
  public onSelect(category) {
    for (let i = 0; i < this.categories.length; i++) {
      if (category === this.categories[i].categoryName) {
        this.categoryDescription = this.categories[i].categoryDescription;
        break;
      }
    }
    this.tooltip = this.categoryDescription;
  }
}