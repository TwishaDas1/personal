import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { JobItem } from '../../Model/JobItem';
import { CheckconfigService } from '../../Services/checkconfig.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'dq-import-checks',
  templateUrl: './import-checks.component.html',
  styleUrls: ['./import-checks.component.css']
})
export class ImportChecksComponent implements OnInit {

    public libraries: any[];
    public form: any[];
    public studyTitles: any[];
    public active = false;
    public opened = false;
    public errorMsg: string;
    public override= false;
    public dqImportForm: FormGroup = new FormGroup({
      'study': new FormControl(),
      'library': new FormControl(),
      'form': new FormControl()
  });
public isDisabled = true;
  @Input() public popupType;

  @Input() public set model(jobItem: JobItem) {
      this.dqImportForm.reset(jobItem);
      this.active = jobItem !== undefined && this.popupType === 'import';
      console.log(this.dqImportForm.value.study);
      console.log(this.dqImportForm.value.form);
      if(this.active && this.popupType && ((this.dqImportForm.value.study == null) ||
      (this.dqImportForm.value.form == null))){
       this.opened = true;
       this.errorMsg = 'Please select the required fields.';
       }
       else if(this.active && this.popupType && this.dqImportForm.value.study) {
        this.isDisabled = false;
       }
  }

  @Output() cancel: EventEmitter<any> = new EventEmitter();
  @Output() import: EventEmitter<any> = new EventEmitter();

  constructor(private checkConfigService: CheckconfigService,private http: HttpClient) { }

  ngOnInit() {
    this.checkConfigService.fetchForm().subscribe(data => {
      this.form = data;
      });
      this.checkConfigService.fetchlibrary().subscribe(data => {
      this.libraries = data;
      });
  }
  public close() {
    this.opened = false;
  }

  public onCancel(e): void {
      e.preventDefault();
      this.closeForm();
  }

  private closeForm(): void {
      this.errorMsg = '';
      this.active = false;
      this.isDisabled = true;
      this.cancel.emit();
  }

  public onImport(e): void {
    e.preventDefault();
    if (this.dqImportForm.value.library == null || this.dqImportForm.value.form == null) {
      this.opened = true;
      this.errorMsg = 'Please select all the fields.';
    }
     if(!this.override && this.dqImportForm.value.library && this.dqImportForm.value.form) {
       console.log("override"+this.override+1); 
      this.checkConfigService.checkImport(this.dqImportForm).subscribe(res => {this.isDataPresent(res)
      this.opened = true;
    });
    
}
 else if (this.override && this.dqImportForm.value.library && this.dqImportForm.value.form){
  console.log("override"+this.override+2);
   this.checkConfigService.doImport(this.dqImportForm).subscribe(res => {this.fetchData(res)});
  }
}
public isDataPresent(res){
  if(res!==null && res.length> 0!){
    this.errorMsg="The data already exists. Do you want to override it?";
    this.override=true;
}
}
public fetchData(res){
  if(res!==null){ 
  //this.import.emit(this.dqImportForm.value);
  this.import.emit(res);
  this.active = false;
  this.errorMsg = '';
}
}
}
