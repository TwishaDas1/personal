import { Timestamp } from "rxjs/Rx";

export class JobItem {

    public uniqueId: number;
    public study: string;
    public form: string;
    public category: string;
    public dqCheck: string;
    public variable: string;
    public input: string;
    public input2: string;
    public jobStatus: string;
    public jobStartTimestamp: Date;
    public jobEndTimestamp: Date;
    public message: string;
    public checkEnable: string;
    public checkLogic: string;
    public notes: string;
    public checkFlag: string;
    public jobIsRunning: boolean = false;
    public jobDisabled: boolean = false;
    public sourceVariable: string;
    public independentVariable: string;
    public dependentVariable: string;
    public dependency: string;
    public upperRange: string;
    public lowerRange: string;
    public initialDate: string;
    public secondaryDate: string;
    public checkLength: string;
    public formStatus: string;
    public therapeuticArea: string;

}