/* tslint:disable */
export const checkList = [{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

},
{
    "StudyId": 1,
    "CheckName": "Check 1 failed",

}];
