import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { JobItem } from '../Model/JobItem';
import { Observable } from '../../../../node_modules/rxjs';
// import { BehaviorSubject } from 'rxjs/BehaviorSubject';
// import { tap } from 'rxjs/operators/tap';
@Injectable({
  providedIn: 'root'
})
export class CheckconfigService {

  constructor(private http: HttpClient) {

  }

  public getJobs() {
    return this.http.get<JobItem[]>(`/api/CDR/DQ/dqMatrix/jobs`);
  }

  public sendEmail(): any {
    return this.http.get<any>(`/api/CDR/DQ/sendEmail`);
  }


  public fetchDomainStatuses(): any {
    return this.http.get<any[]>(`/api/CDR/domain/statuses`);
  }
  public fetchTherapeuticAreas(): any {

    return this.http.get<any[]>(`/api/CDR/matrix/therapeutics`);
  }
  public fetchStudyTitles() {
    return this.http.get<any[]>(`/api/CDR/study/dropdown`);
  }
  public fetchStudyCategory() {
    return this.http.get<any[]>(`/api/CDR/DQ/quality/categories`);
  }
  public fetchStudyCheck() {
    return this.http.get<any[]>(`/api/CDR/DQ/quality/checks`);
  }
  public fetchStudyCheckCategory() {
    console.log("service");
    return this.http.get<any[]>(`/api/CDR/DQ/quality/categoryChecks`);
  }

  public fetchStatus() {
    return this.http.get<any[]>('api/CDR/DQ/quality/dqJobStatuses');
  }
  // public fetchForm() {
  //   return this.http.get<any[]>('api/CDR/lookup/sourceForms');
  // }
  public fetchlibrary() {
    return this.http.get<any[]>('api/CDR/DQ/quality/libraries');
  }
  public fetchVariables(table: any) {
    return this.http.get<any[]>(`api/CDR/lookup/sourceVariables/${table}`);
  }

  public fetchForm() {
    return this.http.get<any[]>('api/CDR/DQ/quality/form');
  }
  //SourceFile()
  public fetchSourceVariable() {
    return this.http.get<any[]>('api/CDR/DQ/quality/formVariable');
  }

  public fetchStudiessBytherapeuticArea(therapeuticArea: any) {
    let params = new HttpParams();
    params = params.set('therapeuticArea', therapeuticArea);
    return this.http.get<any[]>(`/api/CDR/study/ByTherapeuticArea`, { params: params });
  }

  filterDqChecks(searchDqChecks: any): Observable<any> {
    console.log("filter")
    let params = new HttpParams();
    if (searchDqChecks.study) {
      params = params.set('study', searchDqChecks.study);
    }
    if (searchDqChecks.form) {
      params = params.set('form', searchDqChecks.form);
    }
    if (searchDqChecks.category) {
      params = params.set('category', searchDqChecks.category);
    }
    if (searchDqChecks.check) {
      params = params.set('check', searchDqChecks.check);
    }
    if (searchDqChecks.variable) {
      params = params.set('variable', searchDqChecks.variable);
    }
    if (searchDqChecks.status) {
      params = params.set('status', searchDqChecks.status);
    }

    return this.http.get<any[]>(`/api/CDR/DQ/dqMatrix/filter/jobs`, { params: params })

  }


  public updateNotes(data, selectedRules, isAllRulesSelected, searchDqChecks): Observable<any> {
    let params = new HttpParams();
    if (data.study) {
      params = params.set('study', data.study);
    }
    if (data.form) {
      params = params.set('form', data.form);
    }
    if (selectedRules) {
      params = params.set('selectedRules', selectedRules);
    }
    if (isAllRulesSelected) {
      params = params.set('isAllRulesSelected', isAllRulesSelected);
    }
    if (data.notes) {
      params = params.set('notes', data.notes);
    }
    const updateUrl = '/api/CDR/DQ/dqChecks/updateNotesForChecks';
    const url = `${updateUrl}`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put(url, searchDqChecks, { params: params });
  }

  public updateFlags(data, selectedRules, isAllRulesSelected, searchDqChecks): Observable<any> {
    let params = new HttpParams();
    if (data.study) {
      params = params.set('study', data.study);
    }
    if (data.form) {
      params = params.set('form', data.form);
    }
    if (selectedRules) {
      params = params.set('selectedRules', selectedRules);
    }
    if (isAllRulesSelected) {
      params = params.set('isAllRulesSelected', isAllRulesSelected);
    }
    if (data.notes) {
      params = params.set('notes', data.notes);
    }

    const updateUrl = '/api/CDR/DQ/dqChecks/updateFlagsForChecks';
    const url = `${updateUrl}`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put(url, searchDqChecks, { params: params });
  }

  public updateCheckFlag(data: any, searchDqChecks): Observable<any> {
    const updateUrl = '/api/CDR/DQ/matrix/updateCheckFlag';
    const url = `${updateUrl}/${data.uniqueId}/${data.checkFlag}`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put(url, searchDqChecks, { headers: headers });
  }

  public saveCustomChecks(template: JobItem) {
    const createUrl = '/api/CDR/DQ/customCheck/create';
    let url = `${createUrl}`;
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post(url, template, { headers: headers }).subscribe(data => {
    });
  }
  public deleteCustomCheck(template: JobItem): Observable<any> {
    const deleteUrl = '/api/CDR/DQ/customCheck/delete';
    const url = `${deleteUrl}/${template.uniqueId}`;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.delete(url, { headers: headers });
  }

  public getStudiesForDashboard(): Observable<any> {
    return this.http.get<any[]>('/api/CDR/DQ/dataQualityDashboard');
  }

  public updateFormStatus(jobItem) {
   const createUrl = '/api/CDR/DQ/updateFormStatus';
    ///let url = `${createUrl}/${jobItem.formStatus}/${jobItem.form}/${jobItem.study}`;
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.put<any[]>(createUrl, jobItem, { headers: headers });

  }
    public updateCustomChecks(template: JobItem) {
      const updateUrl = '/api/CDR/DQ/customCheck/update';
      let url = `${updateUrl}`;
      let headers = new HttpHeaders();
      headers.append('Content-Type', 'application/json');
      return this.http.post(url, template, {headers: headers})
  }
  public ImportCustomChecks(dqImportForm) {
    const study = dqImportForm.study;
    const form = dqImportForm.form;
    const library = dqImportForm.library;
    const createUrl = '/api/CDR/DQ/quality/fetch';
    if (study && form && library === !null) {
      let url = `${createUrl}/${form}/${library}/${study}`;
      let headers = new HttpHeaders();
      headers.append('Content-Type', 'application/json');
      return this.http.get(url).subscribe(data => {
      });
    }
  }

  public deleteNotification(id: string) {
    return this.http.delete<any>(`/api/CDR/DQ/deleteNotification/${id}`);
  }


  public notificationStop(id: string) {
    return this.http.delete<any>(`/api/CDR/DQ/notificationStop/${id}`);
  }
  private data: any[] = [];
  // public read(searchDqChecks) {
  //   this.filterDqChecks(searchDqChecks)
  //       // .pipe(
  //     tap(data => {
  //         this.data = data;
  //     })
  // )
  // .subscribe(data => {
  //     super.next(data);
  // });
  //}

  public checkImport(dqImportForm){
    const study=dqImportForm.value.study;
    const form=dqImportForm.value.form;
    const library=dqImportForm.value.library;
    const createUrl = '/api/CDR/DQ/quality/check';
    let url = `${createUrl}/${form}/${library}/${study}`;
    return this.http.get<any[]>(url)
    
  }
  public doImport(dqImportForm){
    const study=dqImportForm.value.study;
    const form=dqImportForm.value.form;
    const library=dqImportForm.value.library;
    const createUrl = '/api/CDR/DQ/quality/fetch';
    let url = `${createUrl}/${form}/${library}/${study}`;
    return this.http.get<any[]>(url)
  }

  public getDependency(){
    console.log("inside d service");
    return this.http.get<any[]>('/api/CDR/DQ/dependency');
  }
}
