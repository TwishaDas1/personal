import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-properties',
  templateUrl: './app-properties.component.html',
  styleUrls: ['./app-properties.component.css']
})
export class AppPropertiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
