import { Component, Input, Output, EventEmitter, Inject, OnInit } from '@angular/core';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { BusinessEditService } from '../../Services';
import { Matrix, StudyDetails, LookupTable } from '../../Models';



@Component({
    selector: 'business-rule-config-edit',
    templateUrl: './business-rule-config-edit.component.html',
    styleUrls: ['./business-rule-config-edit.component.css']

})
export class BusinessRuleConfigEditComponent implements OnInit {

    public isImportFromStudy: boolean = false;
    public templateStudyTitles: any[];
    public studyList: StudyDetails[];
    public studyPopDomains: any[];
    public selectedDomains: any[];
    public searchBRStudy: any = {};
    public transPlaceHolder = 'Enter Transformation Logic';
    private businessEditService: BusinessEditService;
    public transTypes: any[];
    public lookups: any[] = [];
    public lookupVariables: any[] = [];
    public lookupVariablesFormName: any[] = [];
    public lookupVariablesFormNamePlus: any[] = [];
    public lookupVariablesFormName1: any[] = [];
    public lookupVariablesFormName2: any[] = [];
    public lookupVariablesFormName3: any[] = [];
    public lookupVariablesFormName4: any[] = [];
    public lookupVariablesFormName5: any[] = [];
    public lookupTables: LookupTable[] = [];
    public sdtmVariables: any[];
    transformationCodeMap = new Map<string, string>();


    public active = false;
    public opened: boolean = false;
    public errorMsg: string;
    public defaultMessage = '';
    public override = false;
    public previousLength = 0;
    public countToAdditionalLoop = 0;
    public textAdditional = '';
    hideOriginalAddButton: boolean = false;
    public selectedCreateStudy: StudyDetails;
    public studyVersion: string;
    public editBusinessForm: FormGroup = new FormGroup({
        'id': new FormControl(),

        'study': new FormControl(),
        'matrixStudy': new FormControl(),
        'domain': new FormControl(),
        'importDomain': new FormControl(),
        'subDomain': new FormControl(),
        'targetFile': new FormControl(),
        'targetField': new FormControl(),
        'sourceFile': new FormControl(),
        'sourceField': new FormControl(),
        'joinLogic': new FormControl(),
        'transformation_type': new FormControl(),
        'transformation_logic': new FormControl(),
        'back_transformation_logic': new FormControl(),
        'defaultMessage': new FormControl(),
        'formName': new FormControl(),
        'formLable': new FormControl(),
        'domainStatus': new FormControl(),
        'notes': new FormControl(),
        'ruleFlag': new FormControl(),

        'customCode': new FormControl(),
        'dateForComputation': new FormControl(),
        'operation': new FormControl(),
        'concatLogic': new FormControl(),
        'sourceFilePlus': new FormControl(),
        'formNamePlus': new FormControl(),
        'sourceFile1': new FormControl(),
        'formName1': new FormControl(),
        'sourceFile2': new FormControl(),
        'formName2': new FormControl(),
        'sourceFile3': new FormControl(),
        'formName3': new FormControl(),
        'sourceFile4': new FormControl(),
        'formName4': new FormControl(),
        'sourceFile5': new FormControl(),
        'formName5': new FormControl(),
        'sourceFieldPlus': new FormControl(),
        'sourceField1': new FormControl(),
        'sourceField2': new FormControl(),
        'sourceField3': new FormControl(),
        'sourceField4': new FormControl(),
        'sourceField5': new FormControl(),
        'addVar': new FormControl(),
        'joinLogic1': new FormControl(),
        'joinLogic2': new FormControl(),
        'joinLogic3': new FormControl(),
        'joinLogic4': new FormControl(),
        'joinLogic5': new FormControl(),
        'lookupType': new FormControl(),
        'transformationCode': new FormControl()
    });

    constructor(private http: HttpClient, @Inject(BusinessEditService) businessEditServiceFactory: any) {
        this.businessEditService = businessEditServiceFactory();
    }
    private res: any[] = [];
    @Input() public isNew = false;
    @Input() public gridData: any;
    @Input() public domainName: any;
    public formName: string;
    public formNameLabel: string;
    public formNameValue: string;
    public sourceFileValue: string;
    public formNamePlusLabel: string;
    public formNamePlusValue: string;
    public sourceFilePlusValue: string;
    public sourceFilePlusLabel: string;
    public formNameLabel1: string;
    public formNameValue1: string;
    public sourceFileValue1: string;
    public sourceFileLabel1: string;
    public formNameLabel2: string;
    public formNameValue2: string;
    public sourceFileValue2: string;
    public sourceFileLabel2: string;
    public formNameLabel3: string;
    public formNameValue3: string;
    public sourceFileValue3: string;
    public sourceFileLabel3: string;
    public formNameLabel4: string;
    public formNameValue4: string;
    public sourceFileValue4: string;
    public sourceFileLabel4: string;
    public formNameLabel5: string;
    public formNameValue5: string;
    public sourceFileValue5: string;
    public sourceFileLabel5: string;
    public transformation_logic_by_def: string;
    public matrix: Matrix;
    public errorMsg2: string;

    @Input() public set model(matrix: Matrix) {
        this.matrix = new Matrix();
        this.matrix = matrix;
        // this.selectedStudy = this.matrix.study;
        // this.getStudyTitlesByVersion(matrix.studyVersion);
        this.editBusinessForm.reset(matrix);
        this.active = matrix !== undefined;
        if (this.active && matrix.transformation_logic) {
            var contentInBracketsTemp = matrix.transformation_logic.split("(");

            var contentInBrackets;
            if (contentInBracketsTemp && contentInBracketsTemp[0] && contentInBracketsTemp[1]) {
                contentInBrackets = contentInBracketsTemp[1].split(")");
            }


            var contentToSplit;
            if (contentInBrackets) {
                contentToSplit = contentInBrackets[0];
            }
            var splitArray;
            if (contentToSplit) {
                splitArray = contentToSplit.split(",");
            }

            if (splitArray != null && splitArray.length > 0) {

                var arrayLength = splitArray.length;
                if (0 < arrayLength) {

                    var formGroup = splitArray[0].split("@");

                    this.editBusinessForm.value.formName = formGroup[0];
                    //this.editBusinessForm.value.formLable =  formGroup[0];
                    this.editBusinessForm.value.sourceFile = formGroup[1];
                    this.formNameValue = formGroup[0];
                    this.sourceFileValue = formGroup[1];



                    const form = this.lookupTables.find((x: any) => x.formName === this.formNameValue);
                    if (form) {
                        this.formNameLabel = form.formDescription;
                        this.tempValFormName = this.formNameLabel;
                        this.editBusinessForm.value.formLable = this.formNameLabel;

                    }
                    this.businessEditService.fetchLookUpVariables(matrix.formName).subscribe(data => {
                        this.lookupVariablesFormName = data;
                        const varForm = this.lookupVariablesFormName.find((x: any) => x.formVariableName === this.sourceFileValue);
                        if (varForm) {
                            this.editBusinessForm.value.sourceField = varForm.formVariableDescription;
                            this.sourceFileLabel = varForm.formVariableDescription;

                        }
                    });


                }

                if (1 < arrayLength) {
                    var formGroupPlus = splitArray[1].split("@");
                    this.editBusinessForm.value.formNamePlus = formGroupPlus[0];
                    this.editBusinessForm.value.sourceFilePlus = formGroupPlus[1];
                    this.formNamePlusValue = formGroupPlus[0];
                    this.sourceFilePlusValue = formGroupPlus[1];

                    const form = this.lookupTables.find((x: any) => x.formName === this.formNamePlusValue);
                    if (form) {
                        this.formNamePlusLabel = form.formDescription;

                    }
                    this.businessEditService.fetchLookUpVariables(this.formNamePlusValue).subscribe(data => {
                        this.lookupVariablesFormNamePlus = data;
                        const varForm = this.lookupVariablesFormNamePlus.find((x: any) =>
                            x.formVariableName === this.sourceFilePlusValue);
                        if (varForm) {
                            this.editBusinessForm.value.sourceFilePlus = varForm.formVariableDescription;
                            this.sourceFilePlusLabel = varForm.formVariableDescription;
                        }
                    });



                }
                if (2 < arrayLength) {

                    var formGroup1 = splitArray[2].split("@");
                    this.editBusinessForm.value.formName1 = formGroup1[0];
                    this.editBusinessForm.value.sourceFile1 = formGroup1[1];
                    this.formNameValue1 = formGroup1[0];
                    this.sourceFileValue1 = formGroup1[1];

                    const form = this.lookupTables.find((x: any) => x.formName === this.formNameValue2);
                    if (form) {
                        this.formNameLabel1 = form.formDescription;;

                    }

                    this.businessEditService.fetchLookUpVariables(this.formNameValue1).subscribe(data => {
                        this.lookupVariablesFormName1 = data;
                        const varForm = this.lookupVariablesFormName1.find((x: any) =>
                            x.formVariableName === this.sourceFileValue1);
                        if (varForm) {
                            this.editBusinessForm.value.sourceFile1 = varForm.formVariableDescription;
                            this.sourceFileLabel1 = varForm.formVariableDescription;
                        }
                    });
                }
                if (3 < arrayLength) {
                    var formGroup2 = splitArray[3].split("@");
                    this.editBusinessForm.value.formName2 = formGroup2[0];
                    this.editBusinessForm.value.sourceFile2 = formGroup2[1];
                    this.formNameValue2 = formGroup2[0];
                    this.sourceFileValue2 = formGroup2[1];

                    const form = this.lookupTables.find((x: any) => x.formName === this.formNameValue2);
                    if (form) {
                        this.formNameLabel2 = form.formDescription;;
                    }
                    this.businessEditService.fetchLookUpVariables(this.formNameValue2).subscribe(data => {
                        this.lookupVariablesFormName2 = data;
                        const varForm = this.lookupVariablesFormName2.find((x: any) =>
                            x.formVariableName === this.sourceFileValue2);
                        if (varForm) {
                            this.editBusinessForm.value.sourceFile2 = varForm.formVariableDescription;
                            this.sourceFileLabel2 = varForm.formVariableDescription;
                        }
                    });
                }
                if (4 < arrayLength) {
                    var formGroup3 = splitArray[4].split("@");
                    this.editBusinessForm.value.formName3 = formGroup3[0];
                    this.editBusinessForm.value.sourceFilePlus = formGroup3[1];
                    this.formNameValue3 = formGroup3[0];
                    this.sourceFileValue3 = formGroup3[1];

                    const form = this.lookupTables.find((x: any) => x.formName === this.formNameValue3);
                    if (form) {
                        this.formNameLabel3 = form.formDescription;;
                    }
                    this.businessEditService.fetchLookUpVariables(this.formNameValue3).subscribe(data => {
                        this.lookupVariablesFormName3 = data;
                        const varForm = this.lookupVariablesFormName3.find((x: any) =>
                            x.formVariableName === this.sourceFileValue3);
                        if (varForm) {
                            this.editBusinessForm.value.sourceFile3 = varForm.formVariableDescription;
                            this.sourceFileLabel3 = varForm.formVariableDescription;
                        }
                    });
                }
                if (5 < arrayLength) {
                    var formGroup4 = splitArray[5].split("@");
                    this.editBusinessForm.value.formName4 = formGroup4[0];
                    this.editBusinessForm.value.sourceFile4 = formGroup4[1];
                    this.formNameValue4 = formGroup4[0];
                    this.sourceFileValue4 = formGroup4[1];

                    const form = this.lookupTables.find((x: any) => x.formName === this.formNameValue4);
                    if (form) {
                        this.formNameLabel4 = form.formDescription;;
                    }
                    this.businessEditService.fetchLookUpVariables(this.formNameValue4).subscribe(data => {
                        this.lookupVariablesFormName1 = data;
                        const varForm = this.lookupVariablesFormName4.find((x: any) =>
                            x.formVariableName === this.sourceFileValue4);
                        if (varForm) {
                            this.editBusinessForm.value.sourceFile4 = varForm.formVariableDescription;
                            this.sourceFileLabel4 = varForm.formVariableDescription;
                        }
                    });
                }
                if (6 < arrayLength) {
                    var formGroup5 = splitArray[6].split("@");
                    this.editBusinessForm.value.formName5 = formGroup5[0];
                    this.editBusinessForm.value.sourceFile5 = formGroup5[1];
                    this.formNameValue5 = formGroup5[0];
                    this.sourceFileValue5 = formGroup5[1];

                    const form = this.lookupTables.find((x: any) => x.formName === this.formNameValue5);
                    if (form) {
                        this.formNameLabel5 = form.formDescription;;
                    }
                    this.businessEditService.fetchLookUpVariables(this.formNameValue5).subscribe(data => {
                        this.lookupVariablesFormName5 = data;
                        const varForm = this.lookupVariablesFormName5.find((x: any) =>
                            x.formVariableName === this.sourceFileValue1);
                        if (varForm) {
                            this.editBusinessForm.value.sourceFile5 = varForm.formVariableDescription;
                            this.sourceFileLabel5 = varForm.formVariableDescription;
                        }
                    });
                }
            } else {
                // checks for "No transformation" to go here since split array will be undefined

                this.editBusinessForm.value.formName = matrix.formName;
                this.editBusinessForm.value.sourceFile = matrix.sourceField;
                this.formNameValue = matrix.formName;
                this.sourceFileValue = matrix.sourceField;



                const form = this.lookupTables.find((x: any) => x.formName === this.formNameValue);
                if (form) {
                    this.formNameLabel = form.formDescription;
                    this.tempValFormName = this.formNameLabel;
                    this.editBusinessForm.value.formLable = this.formNameLabel;

                }
                this.businessEditService.fetchLookUpVariables(matrix.formName).subscribe(data => {
                    this.lookupVariablesFormName = data;
                    this.editBusinessForm.value.sourceField = this.sourceFileValue;
                    this.sourceFileLabel = this.sourceFileValue;

                });

            }//end of else

        }// END of if(this.active && matrix.addVar)


        if (this.active && matrix.transformation_type) {

            this.changePlaceholderAndValue(matrix.transformation_type, 'init');//init keyed in to identify first time loading of pop up
            this.transformationCode = matrix.transformation_logic;
            this.transformationCodeToCompare = matrix.transformation_logic;
        }
        if (this.active && matrix.formName) {
            //this.onSelect(matrix.formName, 'formName');
        }
        if (this.active && matrix.defaultMessage) {
            this.defaultMessage = matrix.defaultMessage;
        }
    }

    @Output() cancel: EventEmitter<any> = new EventEmitter();
    @Output() save: EventEmitter<Matrix> = new EventEmitter();
    @Output() delete: EventEmitter<Matrix> = new EventEmitter();
    @Output() fetch: EventEmitter<Matrix> = new EventEmitter();
    @Output() update: EventEmitter<Matrix> = new EventEmitter();
    @Output() ruleFlag: EventEmitter<Matrix> = new EventEmitter();
    @Output() ruleNote: EventEmitter<Matrix> = new EventEmitter();



    public getStudyTitlesByVersion(studyVersion: string) {
        this.businessEditService.getStudyTitlesByVersion(studyVersion).subscribe(data => {
            this.templateStudyTitles = data;
        });
    }

    public onSave(e, isNew: any) {
        e.preventDefault();
        if (isNew === 'add') {
            //alert(this.editBusinessForm.value.study);
            //alert(this.editBusinessForm.value.domain);
            if (this.editBusinessForm.value.study == null || this.editBusinessForm.value.domain == null) {
                this.opened = true;
                this.errorMsg = 'Please select study and domain to add a business rule.';
            } else {
                this.save.emit(this.editBusinessForm.value);
                this.active = false;
                this.transPlaceHolder = 'Enter Transformation';
            }
        } else if (isNew === 'edit') {

            if (this.editBusinessForm.value.transformation_type === 'Manual Entry' &&
                this.editBusinessForm.value.transformation_logic.length == 0) {
                this.onForm();
            }
            else if ((this.editBusinessForm.value.transformation_type === "Upper"
                || this.editBusinessForm.value.transformation_type === "Lower"
                || this.editBusinessForm.value.transformation_type === "Minimum"
                || this.editBusinessForm.value.transformation_type === "Maximum"
                || this.editBusinessForm.value.transformation_type === "Average"
                || this.editBusinessForm.value.transformation_type === "ISO Date Format"
                || this.editBusinessForm.value.transformation_type === "No Transformation")
                && (this.editBusinessForm.value.formName.length == 0 ||
                    this.editBusinessForm.value.sourceFile.length == 0)) {

                this.onForm();
            }
            else if (
                this.editBusinessForm.value.transformation_type === "Lookup Transformation"
                && (this.editBusinessForm.value.formName.length == 0 ||
                    this.editBusinessForm.value.sourceFile.length == 0 ||
                    this.editBusinessForm.value.lookupType.length == 0)
            ) {
                this.onForm();
            }
            else if (this.editBusinessForm.value.transformation_type === "Custom Code" &&
                (this.editBusinessForm.value.formName.length == 0 ||
                    this.editBusinessForm.value.sourceFile.length == 0 ||
                    this.editBusinessForm.value.customCode == null)) {
                this.onForm();
            }
            else if ((this.editBusinessForm.value.transformation_type === "Concatenation") &&
                (
                    //this.editBusinessForm.value.concatLogic == null || this.editBusinessForm.value.concatLogic.length == 0 ||
                    this.editBusinessForm.value.formName == null || this.editBusinessForm.value.formName.length == 0 ||
                    this.editBusinessForm.value.sourceFile == null || this.editBusinessForm.value.sourceFile.length == 0 ||
                    this.editBusinessForm.value.formNamePlus == null || this.editBusinessForm.value.formNamePlus.length == 0 ||
                    this.editBusinessForm.value.sourceFilePlus == null || this.editBusinessForm.value.sourceFilePlus.length == 0
                )) {
                this.onForm();

            }


            else if (this.editBusinessForm.value.transformation_type === "Number of Days"
                && (this.editBusinessForm.value.formName.length == 0 ||
                    this.editBusinessForm.value.sourceFile.length == 0 ||
                    this.editBusinessForm.value.formNamePlus.length == 0 ||
                    this.editBusinessForm.value.sourceFilePlus.length == 0)) {
                this.onForm();
            }

            else if ((this.editBusinessForm.value.transformation_type === "Date Computation") &&
                (this.editBusinessForm.value.formName.length == 0
                    || this.editBusinessForm.value.sourceFile.length == 0
                    || this.editBusinessForm.value.operation.length == 0
                    || this.editBusinessForm.value.dateForComputation.length == 0)) {
                this.onForm();
            }


            else {

                this.editBusinessForm.value.formLable = this.formLabel;
                this.editBusinessForm.value.sourceField = this.sourceFileLabel;
                this.editBusinessForm.value.transformation_logic = this.transformationCodeToCompare;
                this.editBusinessForm.value.back_transformation_logic = this.transformationCode;
                this.save.emit(this.editBusinessForm.value);
                this.resetFlags();
                this.revertValues();
                this.active = false;
                this.transPlaceHolder = 'Enter Transformation';
            }
        } else {
            this.save.emit(this.editBusinessForm.value);
            this.active = false;
            this.transPlaceHolder = 'Enter Transformation';
        }
    }

    public onForm() {
        this.opened = true;
        this.errorMsg = 'Please populate all required fields (denoted by asterisk *).';
    }
    public close() {
        this.opened = false;
    }

    public onCancel(e): void {
        e.preventDefault();
        this.closeForm();
        this.revertValues();
    }

    private closeForm(): void {
        this.errorMsg = '';
        this.defaultMessage = '';
        this.studyPopDomains = [];
        this.previousLength = 0;
        this.transPlaceHolder = 'Enter Transformation';
        this.active = false;
        this.cancel.emit();
        this.resetFlags();
        this.revertValues();
    }
    public revertValues(): void {
        this.formNamePlusLabel = '';
        this.formNamePlusValue = '';
        this.sourceFilePlusValue = '';
        this.sourceFilePlusLabel = '';
        this.formNameLabel1 = '';
        this.formNameValue1 = '';
        this.sourceFileValue1 = '';
        this.sourceFileLabel1 = '';
        this.formNameLabel2 = '';
        this.formNameValue2 = '';
        this.sourceFileValue2 = '';
        this.sourceFileLabel2 = '';
        this.formNameLabel3 = '';
        this.formNameValue3 = '';
        this.sourceFileValue3 = '';
        this.sourceFileLabel3 = '';
        this.formNameLabel4 = '';
        this.formNameValue4 = '';
        this.sourceFileValue4 = '';
        this.sourceFileLabel4 = '';
        this.formNameLabel5 = '';
        this.formNameValue5 = '';
        this.sourceFileValue5 = '';
        this.sourceFileLabel5 = '';
        //this.formLabel = '';
        this.sourceFileLabel = '';
        this.formNameLabel = '';
        //this.sourceFile = '';
        this.formNameValue = '';
        this.sourceFileValue = '';

    }
    public resetFlags(): void {
        this.titlePlaceHolder = '';
        this.description = '';
        this.descrip = '';
        this.date = false;
        this.iso = false;
        this.showPopulatedText = false;
        this.showSourceFile = false;
        this.showSourceVariable = false;
        this.showJoinLogic = false;
        this.showJoinLogic1 = false;
        this.showJoinLogic2 = false;
        this.showJoinLogic3 = false;
        this.showJoinLogic4 = false;
        this.showJoinLogic5 = false;

        this.showConcatLogic = false;
        this.showCustomCode = false;
        this.showOperation = false;
        this.showForNumberOfDays = false;
        this.showCustomText = false;
        this.textOne = '';
        this.textTwo = '';
        this.countToLoop = 0;
        this.showDateOfComputation = false;
        this.showLookupFile = false;
        this.showLookupType = false;
        this.opened = false;
        this.errorMsg = '';
        this.showArithmeticOpFormula = false;
        this.dateOfComputation = '';
        this.operation = '';
        this.sourceFile = '';
        this.sourceVar = '';
        //this.countToAdditionalLoop =0;
        this.transformationCode = '';
        this.hideTransformationCode = false;
        this.transformationCodeMap = new Map<string, string>();
        this.transformationCodeVar = '';

    }

    public onDelete(e): void {
        e.preventDefault();
        this.delete.emit(this.editBusinessForm.value);
        this.active = false;
    }

    public ngOnInit(): void {
        this.businessEditService.fetchTransformationTypes().subscribe(data => {
            this.transTypes = data;
        });
        this.businessEditService.fetchLookUpData().subscribe(data => {
            this.populateLookupTable(data);

        });
        this.businessEditService.fetchSDTMVariables().subscribe(data => {
            this.sdtmVariables = data;
        });
        this.businessEditService.fetchStudyTitles().subscribe(data => {
            this.studyList = data;
        });



    }

    public titlePlaceHolder = '';
    public description = '';
    public descrip = '';
    date: boolean = false;
    iso: boolean = false;
    showPopulatedText: boolean = false;
    showSourceFile: boolean = false;
    showSourceVariable: boolean = false;
    showJoinLogic: boolean = false;
    showJoinLogic1: boolean = false;
    showJoinLogic2: boolean = false;
    showJoinLogic3: boolean = false;
    showJoinLogic4: boolean = false;
    showJoinLogic5: boolean = false;

    showConcatLogic: boolean = false;
    showCustomCode: boolean = false;
    showOperation: boolean = false;
    showForNumberOfDays: boolean = false;
    public textOne = '';
    public textTwo = '';
    countToLoop = 0;
    public showCustomText: boolean = false;
    showDateOfComputation: boolean = false;
    showLookupFile: boolean = false;
    showLookupType: boolean = false;
    showArithmeticOpFormula: boolean = false;
    hideTransformationCode: boolean = false;
    public dateOfComputation = '';
    public operation = '';
    public sourceFile = '';
    public sourceVar = '';
    public transformationCode = '';
    public transformationCodeVar = '';
    public formLabel = '';
    public sourceFileLabel = '';

    public populateLookupTable(data: any) {
        for (let item of data) {
            let customObj = new LookupTable();
            //Model values in LHS and DB columns in RHS
            customObj.formName = item.formName;
            customObj.formDescription = item.formDescription;
            this.lookupTables.push(customObj);
        }

    }
    public changePlaceholderAndValue(value: any, type) {
        this.resetFlags();
        if (type != "init") {
            this.formNameValue = "undefined";
            this.sourceFileValue = "undefined";
            this.formNamePlusValue = "undefined";
            this.sourceFilePlusValue = "undefined";

        }
        switch (value) {


            case 'Manual Entry':
                this.titlePlaceHolder = 'Manual Entry';
                this.description = 'Populates the field with the value entered.';
                this.transPlaceHolder = 'eg: Hello World';
                this.showPopulatedText = true;
                this.transformationCode = '';
                break;
            case 'Upper':
                this.titlePlaceHolder = 'Upper';
                this.description = 'Converts text in selected variable to all uppercase.';
                this.descrip = 'Ex: male becomes MALE.';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.transformationCode = 'UPPER';
                break;
            case 'Lower':
                this.titlePlaceHolder = 'Lower';
                this.description = 'Converts text in selected variable to all lowercase.';
                this.descrip = 'Ex: MALE becomes male';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.transformationCode = 'LOWER';
                break;
            case 'Minimum':
                this.titlePlaceHolder = 'Minimum';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable';
                this.description = 'Calculates lowest value of numeric values in selected variable.';
                this.descrip = 'Ex: MINIMUM of AGE (12,13,14) = 12';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.transformationCode = 'MIN';
                break;
            case 'Maximum':
                this.titlePlaceHolder = 'Maximum';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable';
                this.description = 'Calculates highest value of numeric values in selected variable.';
                this.descrip = 'Ex: MAXIMUM of TEMP (55,60,65) = 65';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.transformationCode = 'MAX';
                break;
            case 'Average':
                this.titlePlaceHolder = 'Average';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable';
                this.description = 'Calculates average of all numeric values in selected variable.';
                this.descrip = 'Ex: AVERAGE of Age (12,13,14) = 13';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.transformationCode = 'AVG';
                break;

            case 'Number of Days':
                this.titlePlaceHolder = 'Number of Days';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable_1- Source_File@Source_Variable_2';
                this.description = 'Calculates the Number of Days between two dates.';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.showForNumberOfDays = true;
                this.countToLoop = 1;
                this.showCustomLabels(this.titlePlaceHolder);
                if (!(this.editBusinessForm.value.formName === this.editBusinessForm.value.formNamePlus)) {

                    this.showJoinLogic = true;
                } else {
                    this.showJoinLogic = false;

                }
                this.transformationCode = 'DAYDIFF';
                break;
            case 'Date Computation':
                this.titlePlaceHolder = 'Date Computation';
                this.transPlaceHolder = 'eg: (01/01/2018) - Source_File@Source_Variable or (CURRENTDATE)-Source_File@Source_Variable ';
                this.description = 'Calculates new date by adding or subtracting days to a date.';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.showOperation = true;
                this.showDateOfComputation = true;
                if (this.editBusinessForm.value.dateForComputation) {
                    this.dateOfComputation = this.editBusinessForm.value.dateForComputation;
                } else {
                    this.dateOfComputation = 'CURRENTDATE';
                }
                if (this.editBusinessForm.value.operation) {
                    this.operation = this.editBusinessForm.value.operation;
                } else {
                    this.operation = 'OPERATION';
                }
                if (this.editBusinessForm.value.formName) {
                    this.sourceFile = this.editBusinessForm.value.formName;
                } else {
                    this.sourceFile = 'SOURCEFILE';
                }
                if (this.editBusinessForm.value.sourceFile) {
                    this.sourceVar = this.editBusinessForm.value.sourceFile;
                } else {
                    this.sourceVar = 'SOURCEVARIABLE';
                }
                this.date = true;
                this.transformationCode = 'DATECOMPUTATION';
                break;
            case 'Custom Code':
                this.titlePlaceHolder = 'Custom Code';
                this.transPlaceHolder = 'Please refer readme text for custom python code examples';
                this.description = 'Reads and executes custom python code.';
                //this.showSourceFile = true;
                //this.showSourceVariable = true;
                this.showCustomCode = true;
                this.showJoinLogic = true;
                this.transformationCode = 'PYTHONSCRIPT';
                break;
            case 'ISO Date Format':
                this.titlePlaceHolder = 'ISO Date Format';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable';
                this.description = 'Converts any date into standardized ISO Date Format.';
                this.descrip = 'Ex: 1/1/18 -> 01/01/2018';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.iso = true;
                this.transformationCode = 'DATEISO';
                break;
            case 'No Transformation':
                this.titlePlaceHolder = 'No Transformation';
                this.transPlaceHolder = '';
                this.description = 'No transformation is applied and value is directly mapped.';
                this.descrip = 'Ex. M16-043 -> M16-043';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.hideTransformationCode = true;
                break;
            case 'Lookup Transformation':
                this.titlePlaceHolder = 'Lookup';
                this.transPlaceHolder = 'eg: Lookup_Type,Source_File@Source_Variable';
                this.description = 'Refers Lookup file to replace key with corresponding value.';
                this.descrip = 'Ex. If referencing Country names, use ISO_COUNTRY lookup type';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.showLookupFile = true;
                this.showLookupType = true;
                this.showCustomLabels(this.titlePlaceHolder);
                this.transformationCode = 'CODELIST';
                break;
            case 'Concatenation':
                this.titlePlaceHolder = 'Concatenation';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable_1, Source_File@Source_Variable_2';
                this.description = 'Combines multiple fields into one.';
                this.descrip = 'Ex. GENDER + AGE = “Male 18”';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.countToLoop = 2;
                this.showCustomLabels(this.titlePlaceHolder);
                this.showConcatLogic = true;
                this.textAdditional = 'Variable';
                this.transformationCode = 'CONCAT';
                break;
            case 'Arithemetic Operation':
                this.titlePlaceHolder = 'Arithmetic Operation';
                this.transPlaceHolder = 'eg: Source_File@Source_Variable_1+(Source_File@Source_Variable_2/10)-9';
                this.description = 'Carries out the specified operation.';
                this.descrip = 'Ex. S_DM_RAW@AGE / 2 = 9';
                this.showSourceFile = true;
                this.showSourceVariable = true;
                this.textAdditional = 'Variable';
                this.showCustomLabels(this.titlePlaceHolder);
                this.countToLoop = 2;
                this.showArithmeticOpFormula = true;
                this.transformationCode = 'ARITH';
                break;

            case 'Sequence Generator':
                this.titlePlaceHolder = 'Sequence Generator';
                this.transPlaceHolder = 'eg: Source_Variable';
                this.transformationCode = 'SEQGENERATOR';
                break;

            default:
                this.transPlaceHolder = 'Enter Transformation';
        }
        this.transformationCodeTransType = this.transformationCode;


    }
    public showCustomLabels(scenario) {
        this.showCustomText = true;
        switch (scenario) {
            case 'Number of Days':
                this.textOne = 'Earlier Date';
                this.textTwo = 'Later Date';
                break;
            case 'Concatenation':
                this.textOne = 'Variable 1';
                this.textTwo = 'Variable 2';
                break;
            case 'Arithmetic Operation':
                this.textOne = 'Variable 1';
                this.textTwo = 'Variable 2';
                break;
            case 'Lookup':
                this.textOne = 'Source Variable';
                this.textTwo = 'Lookup';
                break;
        }
    }
    public tempValFormName: string;


    public onSelect(table: any, formName) {
        if (this.lookupTables != null) {
            const selectedItem = this.lookupTables.find((x: any) => x.formName === table);

            if (selectedItem) {
                //this.editBusinessForm.value.formName = selectedItem[1]
                this.editBusinessForm.value.formLable = selectedItem.formDescription;
                switch (formName) {
                    case 'formName': {
                        this.editBusinessForm.value.formName = selectedItem.formDescription;
                        this.formLabel = selectedItem.formDescription;
                        this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
                            this.lookupVariablesFormName = data;
                        });
                        this.tempValFormName = this.editBusinessForm.value.formName;

                        break;
                    }
                    case 'formNamePlus': {
                        this.editBusinessForm.value.formNamePlus = selectedItem.formDescription;
                        this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
                            this.lookupVariablesFormNamePlus = data;
                        });
                        this.formNamePlusLabel = this.editBusinessForm.value.formNamePlus;
                        if (this.editBusinessForm.value.transformation_type === "Concatenation"
                            || this.editBusinessForm.value.transformation_type === "Number of Days"
                            || this.editBusinessForm.value.transformation_type === "Arithemetic Operation") {

                            if (this.tempValFormName === this.formNamePlusLabel) {
                                this.showJoinLogic = false;
                            } else {
                                this.showJoinLogic = true;

                            }
                        }
                        break;
                    }

                    case 'formName1': {
                        this.editBusinessForm.value.formName1 = selectedItem.formDescription;
                        this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
                            this.lookupVariablesFormName1 = data;
                        });

                        this.formNameLabel1 = this.editBusinessForm.value.formName1;

                        if ((this.formNameLabel1 === this.formNamePlusLabel) ||
                            (this.formNameLabel1 === this.tempValFormName)) {
                            this.showJoinLogic1 = false;
                        } else {
                            this.showJoinLogic1 = true;

                        }
                        break;
                    }

                    case 'formName2': {
                        this.editBusinessForm.value.formName2 = selectedItem.formDescription;
                        this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
                            this.lookupVariablesFormName2 = data;
                        });
                        this.formNameLabel2 = this.editBusinessForm.value.formName2;

                        if ((this.formNameLabel2 === this.formNamePlusLabel) ||
                            (this.formNameLabel2 === this.tempValFormName) ||
                            (this.formNameLabel2 === this.formNameLabel1)) {
                            this.showJoinLogic2 = false;
                        } else {
                            this.showJoinLogic2 = true;

                        }
                        break;
                    }

                    case 'formName3': {
                        this.editBusinessForm.value.formName3 = selectedItem.formDescription;
                        this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
                            this.lookupVariablesFormName3 = data;
                        });
                        this.formNameLabel3 = this.editBusinessForm.value.formName3;
                        if ((this.formNameLabel3 === this.formNamePlusLabel) ||
                            (this.formNameLabel3 === this.tempValFormName) ||
                            (this.formNameLabel3 === this.formNameLabel1) ||
                            (this.formNameLabel3 === this.formNameLabel2)) {
                            this.showJoinLogic3 = false;
                        } else {
                            this.showJoinLogic3 = true;

                        }
                        break;
                    }

                    case 'formName4': {
                        this.editBusinessForm.value.formName4 = selectedItem.formDescription;
                        this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
                            this.lookupVariablesFormName4 = data;
                        });
                        this.formNameLabel4 = this.editBusinessForm.value.formName4;
                        if ((this.formNameLabel4 === this.formNamePlusLabel) ||
                            (this.formNameLabel4 === this.tempValFormName) ||
                            (this.formNameLabel4 === this.formNameLabel1) ||
                            (this.formNameLabel4 === this.formNameLabel2) ||
                            (this.formNameLabel4 === this.formNameLabel3)
                        ) {
                            this.showJoinLogic4 = false;
                        } else {
                            this.showJoinLogic4 = true;
                        }
                        break;
                    }
                    case 'formName5': {
                        this.editBusinessForm.value.formName5 = selectedItem.formDescription;
                        this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
                            this.lookupVariablesFormName5 = data;
                        });
                        this.formNameLabel5 = this.editBusinessForm.value.formName5;
                        if ((this.formNameLabel5 === this.editBusinessForm.value.formNamePlus) ||
                            (this.formNameLabel5 === this.tempValFormName) ||
                            (this.formNameLabel5 === this.formNameLabel1) ||
                            (this.formNameLabel5 === this.formNameLabel2) ||
                            (this.formNameLabel5 === this.formNameLabel3) ||
                            (this.formNameLabel5 === this.formNameLabel4)
                        ) {
                            this.showJoinLogic5 = false;
                        } else {
                            this.showJoinLogic5 = true;
                        }
                        break;
                    }


                }
                if (this.editBusinessForm.value.transformation_type === "Custom Code") {
                    this.showJoinLogic = true;
                }
            }
        }
        /*this.businessEditService.fetchLookUpVariables(table).subscribe(data => {
			this.lookupVariables=data;
          });
          switch(formName){
               		case 'formName':
                	this.lookupVariablesFormName = this.lookupVariables;
                	case 'formNamePlus':
                	this.lookupVariablesFormNamePlus = this.lookupVariables;
                	case 'formName1':
                	this.lookupVariablesFormName1 = this.lookupVariables;
                	case 'formName2':
                	this.lookupVariablesFormName2 = this.lookupVariables;
                	case 'formName3':
                	this.lookupVariablesFormName3 = this.lookupVariables;
                	case 'formName4':
                	this.lookupVariablesFormName4 = this.lookupVariables;
                	case 'formName5':
                	this.lookupVariablesFormName5 = this.lookupVariables;
                }*/
    }

    public populateOperation(value) {
        this.editBusinessForm.value.operation = value;
        this.operation = this.editBusinessForm.value.operation;
    }
    public onSelectVariable(table: any, val) {
        var checkVal = '';
        var transformationCodeTempVar = '';

        switch (val) {
            case 'sourceFile': {
                checkVal = this.editBusinessForm.value.formName;
                this.lookupVariables = this.lookupVariablesFormName;
                break;
            }
            case 'sourceFilePlus': {
                checkVal = this.editBusinessForm.value.formNamePlus;
                this.lookupVariables = this.lookupVariablesFormNamePlus;
                break;
            }
            case 'sourceFile1': {
                checkVal = this.editBusinessForm.value.formName1;
                this.lookupVariables = this.lookupVariablesFormName1;
                break;
            }
            case 'sourceFile2': {
                checkVal = this.editBusinessForm.value.formName2;
                this.lookupVariables = this.lookupVariablesFormName2;
                break;
            }
            case 'sourceFile3': {
                checkVal = this.editBusinessForm.value.formName3;
                this.lookupVariables = this.lookupVariablesFormName3;
                break;
            }
            case 'sourceFile4': {
                checkVal = this.editBusinessForm.value.formName4;
                this.lookupVariables = this.lookupVariablesFormName4;
                break;
            }
            case 'sourceFile5': {
                checkVal = this.editBusinessForm.value.formName5;
                this.lookupVariables = this.lookupVariablesFormName5;
                break;
            }
        }
        if (this.lookupTables != null && checkVal) {
            const sourceForm = this.lookupTables.find((x: any) => x.formName === checkVal);
            if (sourceForm) {
                this.editBusinessForm.value.formLable = sourceForm.formDescription;
                transformationCodeTempVar = sourceForm.formName;
            }
        }
        if (this.lookupVariables != null) {
            const selectedItem = this.lookupVariables.find((x: any) => x.formVariableName === table);
            if (selectedItem) {
                transformationCodeTempVar = transformationCodeTempVar + "@" + selectedItem['formVariableName'];
                if (this.transformationCodeMap.has(val)) {
                    this.transformationCodeMap.delete(val);
                }
                this.transformationCodeMap.set(val, transformationCodeTempVar);
                this.populateTransformationCodeVar();

                switch (val) {
                    case 'sourceFile':
                        this.editBusinessForm.value.sourceField = selectedItem['formVariableDescription'];
                        this.sourceFileLabel = selectedItem['formVariableDescription'];
                    case 'sourceFilePlus':
                        this.editBusinessForm.value.sourceFieldPlus = selectedItem['formVariableDescription'];
                    case 'sourceFile1':
                        this.editBusinessForm.value.sourceField1 = selectedItem['formVariableDescription'];
                    case 'sourceFile2':
                        this.editBusinessForm.value.sourceField2 = selectedItem['formVariableDescription'];
                    case 'sourceFile3':
                        this.editBusinessForm.value.sourceField3 = selectedItem['formVariableDescription'];
                    case 'sourceFile4':
                        this.editBusinessForm.value.sourceField4 = selectedItem['formVariableDescription'];
                    case 'sourceFile5':
                        this.editBusinessForm.value.sourceField5 = selectedItem['formVariableDescription'];
                }
            }
        }
    }
    public transformationCodeTransType = '';
    public transformationCodeToCompare = '';
    public populateTransformationCodeVar() {
        this.transformationCodeVar = '';
        this.transformationCodeToCompare = '';
        var size = this.transformationCodeMap.size;

        var count = 0;
        for (let key of Array.from(this.transformationCodeMap.keys())) {
            count = count + 1;
            this.transformationCodeVar = this.transformationCodeVar + this.transformationCodeMap.get(key);

            if (count < size) {
                this.transformationCodeVar = this.transformationCodeVar + ",";
            }
        }
        if (this.hideTransformationCode) {
            this.transformationCode = 'No Transformation';
        } else {
            this.transformationCode = this.transformationCodeTransType + "(" + this.transformationCodeVar + ")";
        }
        this.transformationCodeToCompare = this.transformationCode;

    }
    public getTransformationCode() {
        return this.transformationCode;
    }
    filterDomains(studyTitle: any) {
        this.studyPopDomains = [];
        if (studyTitle !== 'undefined') {
            this.businessEditService.fetchDomainsByStudy(studyTitle).subscribe(data => {
                this.studyPopDomains = data;
            });
        }
    }

    public fetchTemplate(): void {
        const checkUrl = '/api/CDR/matrix/getWorkingCopyDomains';
        const study = this.editBusinessForm.value.study;
        const matrixStudy = this.editBusinessForm.value.matrixStudy;
        let domains = [];
        this.selectedDomains = this.editBusinessForm.value.importDomain;
        if (study === null || matrixStudy === null || (this.selectedDomains === null)) {
            this.opened = true;
            this.errorMsg = 'Please select values to import business rules';
        } else {
            for (let i = 0; i < this.selectedDomains.length; i++) {
                domains.push(this.selectedDomains[i].domain);
            }
            if (!this.override) {
                this.previousLength = this.selectedDomains.length;
            }
            if (this.previousLength !== this.selectedDomains.length) {
                this.override = false;
            }

            const url = `/${study}/${domains}/${this.matrix.studyVersion}`;
            this.http.get<any[]>(checkUrl + url).subscribe(res => {

                if (res != null && res.length > 0 && !(this.override)) {
                    let commaDomains = [];
                    for (let i = 0; i < res.length; i++) {
                        for (let j = 0; j < this.studyPopDomains.length; j++) {
                            if (res[i] === this.studyPopDomains[j].domain) {
                                commaDomains.push(this.studyPopDomains[j].domainLabel);
                                break;
                            }
                        }
                    }
                    this.opened = true;
                    this.override = true;
                    this.previousLength = this.selectedDomains.length;
                    this.errorMsg = 'You have already begun configuration for the following domains: ' + commaDomains;
                    this.errorMsg2 = 'Clicking confirm will replace the working copy for these domains with the template rules. You will lose any changes made to the working copy. Current or previous baselines will not be impacted. Please de-select any domains for which you do not want to replace the working copy. ';
                } else {
                    this.fetch.emit(this.editBusinessForm.value);
                    this.active = false;
                    this.errorMsg = '';
                    this.defaultMessage = '';
                    this.studyPopDomains = [];
                    this.override = false;
                    this.previousLength = 0;
                }
            });
        }
    }

    public confirm(e) {
        e.preventDefault();
        this.update.emit(this.editBusinessForm.value);
        this.active = false;
    }

    public switchFlag() {
        if (this.editBusinessForm.value.ruleFlag === 'Y') {
            this.editBusinessForm.value.ruleFlag = 'N';
        } else {
            this.editBusinessForm.value.ruleFlag = 'Y';
        }
    }

    public OnRuleFlag(e) {
        e.preventDefault();
        this.ruleFlag.emit(this.editBusinessForm.value);
        this.active = false;
    }

    public OnRuleNote(e) {
        if (this.editBusinessForm.value.notes == null || this.editBusinessForm.value.notes === '') {
            this.opened = true;
            this.errorMsg = 'Please enter notes.';
        } else {
            e.preventDefault();
            this.ruleNote.emit(this.editBusinessForm.value);
            this.active = false;
        }
    }
    public addNewSourceVariable() {
        this.countToAdditionalLoop = this.countToAdditionalLoop + 1;
        if (this.countToAdditionalLoop > 0) {
            this.hideOriginalAddButton = true;
        } else {
            this.hideOriginalAddButton = false;

        }

    }
    public removeSourceVariable() {
        this.countToAdditionalLoop = this.countToAdditionalLoop - 1;
        if (this.countToAdditionalLoop > 0) {
            this.hideOriginalAddButton = true;
        } else {
            this.hideOriginalAddButton = false;

        }
    }

    public filterTemplateStudies(target: any) {
        this.selectedCreateStudy = this.studyList.find(s => s.title === target);

        this.businessEditService.getStudyTitlesByVersion(this.selectedCreateStudy.studyVersion).subscribe(data => {
            this.templateStudyTitles = data;
        });
    }


}
