import { Component, OnInit, Inject } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';

import { ActivatedRoute } from '@angular/router';
import { Matrix, StudyDetails, DomainCategories } from '../../Models';
import { BusinessEditService, UserService } from '../../Services';
import { Router } from '@angular/router';
import { CALENDAR_RANGE_VALIDATORS } from '@progress/kendo-angular-dateinputs/dist/es2015/calendar/calendar.component';


@Component({
    selector: 'business-rule-config',
    templateUrl: './business-rule-config.component.html',
    styleUrls: ['./business-rule-config.component.css']
})
export class BusinessRuleConfigComponent implements OnInit {
    public domainStatuses: any[];
    isAdminUser = false;
    configTypeImage: string;
    configTypeTitle: string;
    configTypeIcons: Object[];
    navBarItems: Object[];
    studyDrpSelected = false;
    studyShowOptions = false;
    domainDropDownSelected = false;
    domainDropShowOptions = false;
    statusDrpSelected = false;
    statusShowOptions = false;
    versionDropSelected = false;
    versionShowOptions = false;
    baselineDropSelected = false;
    baselineShowOptions = false;
    public kendoOneShow = false;
    public kendoTwoShow = true;
    public kendoTwoHeight = 339;
    userName = '';
    results: any[];
    public therapeuticAreas: any[];
    public studyTitles: any[];
    public studyDomains: any[];
    public filterVersions: any[];
    public filterDomains: any[];
    public filterBaselines: any[];
    public studyMatrixDomains: any[];
    public searchBRStudy: any = {};
    public studyTitleSelected;
    public importTemplate: any = {};
    public selectedDomains: any[];
    public templateStudyTitles: any[];
    public changedDomain: any;
    public domainCategories: DomainCategories;
    public gridState: State = {
        sort: [],
        skip: 0,
        take: 10
    };
    public sortable = false;
    public editBizDataItem: Matrix;
    public isNew: any;
    private businessEditService: BusinessEditService;
    view1: Observable<GridDataResult>;
    view2: Observable<GridDataResult>;
    public statusColor: any;
    checkbox = false;
    isCheckboxSelected = false;
    selectedItemsList = [];
    userRole: string;
    public disableDomainDropDown: boolean = true;
    public disableVersionDropDown: boolean = true;
    public disableBaselineDropDown: boolean = true;
    public gridData: any[];
    public childGrid: any[];

    constructor(private route: ActivatedRoute,
        private userService: UserService,
        @Inject(BusinessEditService) businessEditServiceFactory: any,
        private router: Router) {
        this.businessEditService = businessEditServiceFactory();
    }
    public ngOnInit(): void {
        const userDetails = this.userService.getUser();

        if (userDetails !== undefined && userDetails.userRole === 'manager') {
            this.isAdminUser = true;
        }
        this.configTypeIcons = [
            { "icontitle": "Go to job execution for this study", "iconImageSrc": "assets/images/JobExeGrey.png", "action": "job", "inputParam": this.searchBRStudy }
        ];

        this.configTypeImage = '../../../assets/images/BussRules.png';
        this.configTypeTitle = 'Business Rule Configuration';

        this.businessEditService.fetchStudyTitles().subscribe(data => {
            this.studyTitles = [];
            for (let i = 0; i < data.length; i++) {
                this.studyTitles.push(data[i].title);
            }
            // this.studyTitles = data;
        });
        this.businessEditService.fetchTherapeuticAreas().subscribe(data => {
            this.therapeuticAreas = data;
        });
        this.businessEditService.fetchDomainStatuses().subscribe(data => {
            this.domainStatuses = data;
        });
        this.businessEditService.fetchStudyMatrixDomains().subscribe(data => {
            this.studyMatrixDomains = data;
        });


        this.searchBRStudy.brStudy = this.route.snapshot.paramMap.get('studyTitle');
        this.searchBRStudy.brSdtmDomain = this.route.snapshot.paramMap.get('domain');
        this.searchBRStudy.brVersion = this.route.snapshot.paramMap.get('version');
        // this.searchBRStudy.brBaseline = this.route.snapshot.paramMap.get('baseline');
        this.searchBRStudy.brTherapeuticArea = this.route.snapshot.paramMap.get('therapeuticArea');

        if (this.searchBRStudy.brStudy === null) {
            this.searchBRStudy.brTherapeuticArea = 'undefined';
            this.searchBRStudy.brStudy = 'undefined';
            this.searchBRStudy.brVersion = 'undefined';
            this.searchBRStudy.brSdtmDomain = 'undefined';
            this.searchBRStudy.brBaseline = 'undefined';
            this.studyTitleSelected = '';
            this.disableDomainDropDown = true;
            this.disableVersionDropDown = true;
            this.disableBaselineDropDown = true;
        } else {
            this.getBusinessRules(this.searchBRStudy);
            this.getFilteredVersions(this.searchBRStudy.brStudy); //get version to show on filter dropdown
            this.getFilteredDomains(this.searchBRStudy.brVersion); //get domains to show on filter dropdown
            this.getFilteredBaselines(this.searchBRStudy.brSdtmDomain);
        }

        /*  if (this.searchBRStudy.brSdtmDomain || this.searchBRStudy.brVersion) {
                this.getBusinessRules(this.searchBRStudy);
            }*/

    }

    public enableFilters() {
        this.disableDomainDropDown = false;
        this.disableVersionDropDown = false;
        this.disableBaselineDropDown = false;
    }

    public fetchTemplate(searchBRStudy): void {

        this.sortable = true;
        this.getBusinessRules(searchBRStudy);
    }

    public getBusinessRules(searchBRStudy: any) {

        if (searchBRStudy.brSdtmDomain != null) {

            this.businessEditService.getBusinessRulesByStudyAndDomain(searchBRStudy).
                subscribe(data => {

                    this.gridData = data[1];
                    this.childGrid = data[0];
                    this.searchBRStudy.brDomainLabel = this.gridData[1].domainLabel;

                    this.searchBRStudy.brSdtmDomain = this.gridData[1].domain;
                    this.searchBRStudy.brBaseline = this.gridData[1].baselineName;
                    this.searchBRStudy.brDomainLabel = this.gridData[1].domainLabel;
                    this.searchBRStudy.brdomainStatus = this.gridData[1].domainStatus;

                    this.sortable = true;
                    //  this.enableFilters();

                    //    this.getFilteredVersions(this.searchBRStudy.brStudy); //get version to show on filter dropdown
                    //    this.getFilteredDomains(this.searchBRStudy.brVersion); //get domains to show on filter dropdown
                    //    this.getFilteredBaselines(this.searchBRStudy.brSdtmDomain); //get baselines to show on filter dropdown

                });



        } else {

            this.businessEditService.getBusinessRuleByVersion(searchBRStudy).
                subscribe(data => {
                    this.gridData = data[1];
                    this.childGrid = data[0];
                    this.searchBRStudy.brSdtmDomain = this.gridData[1].domain;
                    this.searchBRStudy.brBaseline = this.gridData[1].baselineName;
                    this.searchBRStudy.brDomainLabel = this.gridData[1].domainLabel;
                    this.searchBRStudy.brdomainStatus = this.gridData[1].domainStatus;

                    this.sortable = true;
                    //  this.enableFilters();

                    //    this.getFilteredVersions(this.searchBRStudy.brStudy); //get version to show on filter dropdown
                    //    this.getFilteredDomains(this.searchBRStudy.brVersion); //get domains to show on filter dropdown
                    //    this.getFilteredBaselines(this.searchBRStudy.brSdtmDomain); //get baselines to show on filter dropdown
                });



        }
        //  this.sortable = true;
        //  this.enableFilters();

        //  this.getFilteredVersions(this.searchBRStudy.brStudy); //get version to show on filter dropdown
        //  this.getFilteredDomains(this.searchBRStudy.brVersion); //get domains to show on filter dropdown
        //  this.getFilteredBaselines(this.searchBRStudy.brSdtmDomain); //get baselines to show on filter dropdown
    }


    addHandlerIconClick(data) {
        if (!data.flag) return;
        else if (data.flag === 'job') {
            this.router.navigate(['/sdtm/jobExecution', this.searchBRStudy.brStudy]);
        } else if (data.flag === 'lineage') {
            window.open("http://ec2-52-90-18-39.compute-1.amazonaws.com:8080/Lineage.html", '_blank');
        } else if (data.flag === 'download') {
            window.open("http://ec2-52-90-18-39.compute-1.amazonaws.com:8080/Tableau.html", '_blank');
        } else {
            this.addHandler(data.flag, this.searchBRStudy);
        }
    }
    public addHandler(flag: any, searchBRStudy: any) {
        this.editBizDataItem = new Matrix();
        // this.editBizDataItem.studyTitle = searchBRStudy.brStudy;
        if (flag === 'add') {
            this.editBizDataItem.ruleFlag = 'N';
        }
        if (flag === 'add' || flag === 'objectLevel' || flag === 'domainStatus'
            || flag === 'AddNote' || flag === 'AddFlag') {
            this.editBizDataItem.domain = searchBRStudy.brSdtmDomain;
        }
        if (flag === 'import') {

            // this.editBizDataItem.study = this.searchBRStudy.selectedFilterStudy;
            this.editBizDataItem.study = this.searchBRStudy.brStudy;
            this.editBizDataItem.studyVersion = this.searchBRStudy.brVersion;
            this.editBizDataItem.action = 'import';
        }
        if (flag === 'domainStatus' || flag === 'add') {
            this.editBizDataItem.domainStatus = searchBRStudy.brdomainStatus;
        }

        this.isNew = flag;
    }

    public deleteWorkingCopyBR() {
        this.businessEditService.deleteWorkingCopyBR(this.searchBRStudy)
            .subscribe(data => {
                JSON.stringify(data);
            });

    }

    public editHandler({ dataItem }) {
        this.editBizDataItem = dataItem;
        this.isNew = 'edit';
    }

    public cancelHandler() {
        this.editBizDataItem = undefined;
        this.importTemplate = {};
    }

    public saveHandler(template: Matrix) {
        this.businessEditService.save(template, this.searchBRStudy, this.isNew);
        this.editBizDataItem = undefined;
    }

    public removeHandler({ dataItem }) {
        this.editBizDataItem = dataItem;
        this.isNew = 'delete';
    }

    public deleteHandler(template: Matrix) {
        this.businessEditService.remove(template, this.searchBRStudy);
        this.gridData = this.gridData.filter(item => item.id !== template.id);
        // let index = this.gridData.findIndex(d => d.id === template.id); //find index in your array
        // this.gridData.splice(index, 1);//remove element from array
        this.editBizDataItem = undefined;
    }

    public fetchHandler(template: Matrix) {
        let domains = [];
        // this.importTemplate.study = template.study;
        this.selectedDomains = template.importDomain;
        this.studyDomains = template.importDomain;

        this.selectedDomains.sort(function (a, b) {
            const nameA = a.domainLabel.toLowerCase();
            const nameB = b.domainLabel.toLowerCase();
            if (nameA < nameB) {
                return -1;
            } else if (nameA > nameB) {
                return 1;
            }
            return 0;
        });

        for (let i = 0; i < this.selectedDomains.length; i++) {
            domains.push(this.selectedDomains[i].domain);
        }
        this.importTemplate.domain = domains;
        // this.importTemplate.matrixStudy = template.matrixStudy;
        // this.importTemplate.brStudy = template.study;
        this.searchBRStudy.brSdtmDomain = domains[0];
        this.searchBRStudy.brStudy = template.study;
        this.searchBRStudy.matrixStudy = template.matrixStudy;
        this.searchBRStudy.domains = domains;
        // this.businessEditService.save(this.importTemplate, this.searchBRStudy, 'import');
        this.getBusinessRulesFetchOrInsert(this.searchBRStudy);
        // this.editBizDataItem = undefined;
        // this.sortable = true;

        //  this.searchBRStudy.brBaseline = 'Working Copy';
    }
    public getBusinessRulesFetchOrInsert(searchBRStudy: any) {
        this.businessEditService.importBusinessRules(searchBRStudy).
            subscribe(data => {
                this.gridData = data;
                // this.childGrid = data[0];
                //this.searchBRStudy.brDomainLabel = this.gridData[1].domainLabel;
                // let businessRule = this.gridData[0];
                this.searchBRStudy.brSdtmDomain = this.gridData[0].domain;
                this.searchBRStudy.brBaseline = this.gridData[0].baselineName;
                this.searchBRStudy.brDomainLabel = this.gridData[0].domainLabel;
                this.searchBRStudy.brdomainStatus = this.gridData[0].domainStatus;
            });
        this.sortable = true;
        this.enableFilters();
        this.getFilteredVersions(this.searchBRStudy.brStudy); //get version to show on filter dropdown
        this.getFilteredDomains(this.searchBRStudy.brVersion); //get domains to show on filter dropdown
        this.getFilteredBaselines(this.searchBRStudy.brSdtmDomain); //get baselines to show on filter dropdown
    }

    getFilterValues(studyTitle: any) {
        this.disableVersionDropDown = false;
        this.disableDomainDropDown = false;
        this.disableBaselineDropDown = false;

        this.businessEditService.getFilteredVersions(this.searchBRStudy).subscribe(data => {

            this.filterVersions = data;
            this.studyTitleSelected = this.searchBRStudy.brStudy;
            this.searchBRStudy.brVersion = data[0];
            this.getFilteredDomains(this.searchBRStudy);

        });

    }

    getFilteredVersions(studyTitle: any) {
        this.disableVersionDropDown = false;
        // this.searchBRStudy.selectedFilterStudy = this.studyTitles.find(s => s.title === studyTitle);
        this.businessEditService.getFilteredVersions(this.searchBRStudy).subscribe(data => {
            this.filterVersions = data;
            this.studyTitleSelected = this.searchBRStudy.brStudy;
            this.searchBRStudy.brVersion = data[0];
        });

    }

    setDefaultVersion() {

        this.searchBRStudy.brVersion = 'undefined';
        this.searchBRStudy.brSdtmDomain = 'undefined';
        this.searchBRStudy.brBaseline = 'undefined';
        this.filterDomains = [];
        this.filterBaselines = [];
        this.gridData = [];
        this.searchBRStudy.brDomainLabel = '';
    }

    setDefaultDomains() {
        this.searchBRStudy.brSdtmDomain = 'undefined';
        this.searchBRStudy.brBaseline = 'undefined';
        this.gridData = [];
        this.searchBRStudy.brDomainLabel = '';
        this.gridData = [];
        this.searchBRStudy.brDomainLabel = '';
    }

    setDefaultBaselines() {
        this.searchBRStudy.brBaseline = 'undefined';
    }

    setDefaultTitle() {
        this.searchBRStudy.brStudy = 'undefined';
        this.searchBRStudy.brVersion = 'undefined';
        this.searchBRStudy.brSdtmDomain = 'undefined';
        this.searchBRStudy.brBaseline = 'undefined';
        this.disableDomainDropDown = true;
        this.disableVersionDropDown = true;
        this.disableBaselineDropDown = true;
        this.filterVersions = [];
        this.filterDomains = [];
        this.filterBaselines = [];
        this.gridData = [];
        this.studyTitleSelected = '';
    }

    getFilteredDomains(version: any) {
        this.disableDomainDropDown = false;
        this.businessEditService.getFilteredDomains(this.searchBRStudy).subscribe(data1 => {
            this.domainCategories = data1;
            this.filterDomains = data1;
            let domainsEmpty = false;
            if (data1.inProgress.length === 0 && data1.readyForReview.length === 0 && data1.rejected.length === 0 &&
                data1.approved.length === 0 && data1.notStarted.length === 0) {
                domainsEmpty = true;
            }
            if (domainsEmpty || this.filterVersions.length === 0) {
                this.disableDomainDropDown = true;
                this.disableVersionDropDown = true;
                this.disableBaselineDropDown = true;
                this.searchBRStudy.brDomainLabel = 'undefined';
                this.searchBRStudy.brSdtmDomain = 'undefined';
                this.searchBRStudy.brBaseline = 'undefined';
                this.gridData = [];
            } else {
                if (data1.inProgress.length !== 0) {
                    this.searchBRStudy.brSdtmDomain = data1.inProgress[0].domain;
                    this.searchBRStudy.brDomainLabel = data1.inProgress[0].domainLabel;
                } else if (data1.readyForReview.length !== 0) {
                    this.searchBRStudy.brSdtmDomain = data1.readyForReview[0].domain;
                    this.searchBRStudy.brDomainLabel = data1.readyForReview[0].domainLabel;
                } else if (data1.rejected.length !== 0) {
                    this.searchBRStudy.brSdtmDomain = data1.rejected[0].domain;
                    this.searchBRStudy.brDomainLabel = data1.rejected[0].domainLabel;
                } else if (data1.approved.length !== 0) {
                    this.searchBRStudy.brSdtmDomain = data1.approved[0].domain;
                    this.searchBRStudy.brDomainLabel = data1.approved[0].domainLabel;
                } else {
                    this.searchBRStudy.brSdtmDomain = data1.notStarted[0].domain;
                    this.searchBRStudy.brDomainLabel = data1.notStarted[0].domainLabel;
                }
                this.getFilteredBaselines(this.searchBRStudy);
            }
        });
    }


    getFilteredBaselines(domain: any) {
        this.disableBaselineDropDown = false;
        this.businessEditService.getFilteredBaselines(this.searchBRStudy).subscribe(data2 => {
            this.filterBaselines = data2;
            this.searchBRStudy.brBaseline = data2[0];
            if (this.searchBRStudy.brBaseline !== undefined) {
                this.fetchTemplate(this.searchBRStudy);
            } else {
                this.disableBaselineDropDown = true;
                this.gridData = [];
                let idx = -1;
                this.searchBRStudy.brDomainLabel = undefined;

                // idx = this.domainCategories.notStarted.findIndex(item => item.domain === domain);


                // if (idx === -1) {
                //     idx = this.domainCategories.inProgress.findIndex(item => item.domain === domain);
                //     if (idx === -1) {
                //         idx = this.domainCategories.approved.findIndex(item => item.domain === domain);
                //         if (idx === -1) {
                //             idx = this.domainCategories.readyForReview.findIndex(item => item.domain === domain);
                //             if (idx === -1) {
                //                 idx = this.domainCategories.rejected.findIndex(item => item.domain === domain);
                //                 this.searchBRStudy.brDomainLabel = this.domainCategories.rejected[idx].domainLabel;
                //                 this.searchBRStudy.brdomainStatus = 'Rejected';
                //             } else {
                //                 this.searchBRStudy.brDomainLabel = this.domainCategories.readyForReview[idx].domainLabel;
                //                 this.searchBRStudy.brdomainStatus = 'Ready for Review';
                //             }
                //         } else {
                //             this.searchBRStudy.brDomainLabel = this.domainCategories.approved[idx].domainLabel;
                //             this.searchBRStudy.brdomainStatus = 'Approved';
                //         }
                //     } else {
                //         this.searchBRStudy.brDomainLabel = this.domainCategories.inProgress[idx].domainLabel;
                //         this.searchBRStudy.brdomainStatus = 'In Progress';
                //     }
                // } else {
                //     this.searchBRStudy.brDomainLabel = this.domainCategories.notStarted[idx].domainLabel;
                //     this.searchBRStudy.brdomainStatus = 'Not Started';
                // }

            }
        });
    }

    public viewBusinessRules() {
        this.isNew = 'view';
    }



    filterStudies(therapeuticArea: any) {
        this.businessEditService.read('clear');
        this.studyDomains = [];
        this.searchBRStudy.brSdtmDomain = undefined;
        this.searchBRStudy.brStudy = 'undefined';
        this.studyTitleSelected = '';
        this.searchBRStudy.brDomainLabel = '';
        if (therapeuticArea === 'undefined') {
            // do nothing
        } else if (therapeuticArea === 'all') {
            this.businessEditService.fetchStudyTitles().subscribe(data => {
                this.studyTitles = [];
                for (let i = 0; i < data.length; i++) {
                    this.studyTitles.push(data[i].title);
                }
                //  this.studyTitles = data;
            });
        } else {
            this.businessEditService.fetchStudiessBytherapeuticArea(therapeuticArea).subscribe(data => {
                this.studyTitles = data;
            });
        }
    }

    public clear() {
        this.businessEditService.fetchStudyTitles().subscribe(data => {
            for (let i = 0; i < data.length; i++) {
                this.studyTitles.push(data[i].title);
            }
            // this.studyTitles = data;
        });
        this.searchBRStudy = {};
        this.importTemplate = {};
        this.studyDomains = [];
        this.studyTitleSelected = '';
        this.studyShowOptions = false;
        this.studyDrpSelected = false;
        this.domainDropShowOptions = false;
        this.domainDropDownSelected = false;
        this.statusShowOptions = false;
        this.statusDrpSelected = false;
        this.versionDropSelected = false;
        this.versionShowOptions = false;
        this.baselineDropSelected = false;
        this.baselineShowOptions = false;
        this.filterVersions = [];
        this.filterDomains = [];
        this.filterBaselines = [];
        this.disableVersionDropDown = true;
        this.disableDomainDropDown = true;
        this.disableBaselineDropDown = true;
        this.businessEditService.read('clear');
        if (this.configTypeIcons.length === 5) {
            this.configTypeIcons.shift();
            this.configTypeIcons.shift();
            // this.configTypeIcons.shift();
        }
        this.sortable = false;
        this.kendoOneShow = false;
        this.kendoTwoShow = true;
        this.kendoTwoHeight = 339;
        this.checkbox = false;
        this.isCheckboxSelected = false;
        this.selectedItemsList = [];
        this.gridData = [];
        this.childGrid = [];
    }

    public getDomain(): String {
        let selectedDomain = '';
        if (this.searchBRStudy != null && this.searchBRStudy.brSdtmDomain != null
            && this.studyMatrixDomains != null && this.studyMatrixDomains.length > 0) {
            for (let i = 0; i < this.studyMatrixDomains.length; i++) {
                if (this.studyMatrixDomains[i].domains === this.searchBRStudy.brSdtmDomain) {
                    selectedDomain = this.studyMatrixDomains[i].description;
                    break;
                }
            }
            this.view2.forEach(o => {
                if ((o.data != null) && (o.data !== undefined) && (o.data.length != 0)) {

                    for (const obj of o.data) {
                        this.searchBRStudy.brdomainStatus = obj.domainStatus;

                        this.getColor(this.searchBRStudy.brdomainStatus);
                        break;
                    }

                } else {
                    this.searchBRStudy.brdomainStatus = 'Not Started';
                    this.getColor(this.searchBRStudy.brdomainStatus);

                }
            });
            return selectedDomain + ' Domain';
        }
        return null;
    }

    public studyDrp(): void {
        if (this.studyDrpSelected === false) {
            this.studyShowOptions = true;
            this.studyDrpSelected = true;
        } else {
            this.studyShowOptions = false;
            this.studyDrpSelected = false;
        }
    }
    public domainDropDown(): void {
        if (this.domainDropDownSelected === false) {
            this.domainDropShowOptions = true;
            this.domainDropDownSelected = true;
        } else {
            this.domainDropShowOptions = false;
            this.domainDropDownSelected = false;
        }
    }

    public versionDrop(): void {
        if (this.versionDropSelected === false) {
            this.versionShowOptions = true;
            this.versionDropSelected = true;
        } else {
            this.versionShowOptions = false;
            this.versionDropSelected = false;
        }
    }

    public baselineDrop(): void {
        if (this.baselineDropSelected === false) {
            this.baselineShowOptions = true;
            this.baselineDropSelected = true;
        } else {
            this.baselineShowOptions = false;
            this.baselineDropSelected = false;
        }
    }


    public statusDrp(): void {
        if (this.statusDrpSelected === false) {
            this.statusShowOptions = true;
            this.statusDrpSelected = true;
        } else {
            this.statusShowOptions = false;
            this.statusDrpSelected = false;
        }
    }

    capitalizeFirstLetter(str) {
        let temp = str;
        if (str != null && str.length > 2) {
            temp = str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
        }
        return temp;
    }

    public getStudy(): String {
        if (this.searchBRStudy != null && this.searchBRStudy.brStudy !== 'undefined' && this.searchBRStudy.brSdtmDomain != null) {
            // return this.capitalizeFirstLetter(this.searchBRStudy.brStudy) + ' Study';
            return this.searchBRStudy.brStudy;
        }
    }

    public KendoGridOne() {
        this.kendoOneShow = !this.kendoOneShow;
        if (this.kendoOneShow) {
            this.kendoTwoHeight = 339;
        } else {
            this.kendoTwoHeight = 339;
        }
    }

    public KendoGridTwo() {
        this.kendoTwoShow = !this.kendoTwoShow;
    }

    public confirmDomainStaus(value: any) {
        // if ((value === 'Approved' || value === 'Rejected') && !this.isAdminUser) {
        //return false;
        // }
        const statusBeforeChange = this.searchBRStudy.brdomainStatus;
        if (this.searchBRStudy.brdomainStatus === 'Not Started' && value === 'In Progress') {
            this.editBizDataItem = new Matrix();
            // this.editBizDataItem.study = this.searchBRStudy.brStudy;
            this.editBizDataItem.domain = this.searchBRStudy.brSdtmDomain;
            this.editBizDataItem.domainStatus = value;
            this.updateDomainStatus(this.editBizDataItem);

        } else {
            this.searchBRStudy.brdomainStatus = value;
            this.addHandler('domainStatus', this.searchBRStudy);
        }

        //  this.refreshFilters(this.searchBRStudy, statusBeforeChange, value );
        this.getFilteredDomainsAfterRefresh(this.searchBRStudy, value);
    }

    getFilteredDomainsAfterRefresh(version: any, statusAfterChange) {
        const refreshDomains = Object.assign({}, version);
        refreshDomains.brdomainStatus = statusAfterChange;
        this.disableDomainDropDown = false;
        console.log(this.searchBRStudy);
        console.log(refreshDomains);
        this.businessEditService.getFilteredDomains(refreshDomains).subscribe(data1 => {
            console.log(data1);
            this.filterDomains = [];
            this.domainCategories = data1;
            this.filterDomains = data1;
            this.searchBRStudy.brSdtmDomain = refreshDomains.brSdtmDomain;
            this.searchBRStudy.brDomainLabel = refreshDomains.brDomainLabel;
            console.log(this.searchBRStudy);
        });
    }

    /*  refreshFilters(searchBRStudy , statusBeforeChange, statusAfterChange) {
  
          const status = searchBRStudy.brdomainStatus;
          const domain = searchBRStudy.brSdtmDomain;
          // domainCategories =
  
          if (statusBeforeChange === 'Not Started') {
          const idx = this.domainCategories.notStarted.findIndex(item => item.domain === domain);
  
          this.changedDomain  = this.domainCategories.notStarted[idx];
          this.domainCategories.notStarted.splice(idx , 1);
  
          }
  
          if (statusAfterChange === 'In Progress') {
              this.changedDomain.domainStatus = statusAfterChange;
              this.domainCategories.inProgress.push(this.changedDomain);
          }
  
      } */

    public getColor(status: any) {
        switch (status) {
            case 'Not Started': this.statusColor = 'assets/images/approved_circle.png'; break;
            case 'In Progress': this.statusColor = 'assets/images/inprogress_circle.png'; break;
            case 'Ready for Review': this.statusColor = 'assets/images/rejected_circle.png'; break;
            case 'Approved': this.statusColor = 'assets/images/submitreview_circle.png'; break;
            case 'Rejected': this.statusColor = 'assets/images/approved_circle.png'; break;
            default: this.statusColor = 'Blue'; break;
        }

    }

    public updateDomainStatus(template: Matrix) {

        template.userRole = this.userRole;
        if (this.searchBRStudy.brdomainStatus == 'Approved') {

            this.businessEditService.domainStatusUpdate(this.searchBRStudy)
                .subscribe(data => {
                    this.gridData = data;
                    this.searchBRStudy.brBaseline = this.gridData[0].baselineName;
                });


        } else {
            this.businessEditService.domainStatusUpdate(this.searchBRStudy)
                .subscribe(data => {
                    //  this.gridData = data;
                });
        }
        this.getFilteredDomains(this.searchBRStudy.brVersion); //get domains to show on filter dropdown
        this.searchBRStudy.domainStatus = this.searchBRStudy.brdomainStatus;
        this.editBizDataItem = undefined;
    }


    public switchRuleFlag(dataItem, flag) {
        dataItem.ruleFlag = flag;
        this.businessEditService.updateBusinessRuleFlag(dataItem, this.searchBRStudy);
    }

    public updateNotes(template: Matrix) {
        this.businessEditService.updateNotes(template, this.selectedItemsList, this.checkbox, this.searchBRStudy);
        this.editBizDataItem = undefined;
        for (let i = 0; i < this.selectedItemsList.length; i++) {
            this.gridData.find(br => br.id == this.selectedItemsList[i]).notes = template.notes;
        }
        this.checkbox = false;
        this.isCheckboxSelected = false;
        this.selectedItemsList = [];
    }

    public updateFlags(template: Matrix) {
        this.businessEditService.updateFlags(template, this.selectedItemsList, this.checkbox, this.searchBRStudy);
        this.editBizDataItem = undefined;
        for (let i = 0; i < this.selectedItemsList.length; i++) {
            this.gridData.find(br => br.id == this.selectedItemsList[i]).ruleFlag = 'Y';
        }
        this.checkbox = false;
        this.isCheckboxSelected = false;
        this.selectedItemsList = [];
    }

    onItemSelect(item: any, event) {

        if (event.target.checked == true) {
            this.selectedItemsList.push(item.id);

        } else {
            this.selectedItemsList.splice(this.selectedItemsList.indexOf(item), 1);

        }
    }

    public removeBusinessRules() {
        this.businessEditService.deleteWorkingCopyBR(this.searchBRStudy)
            .subscribe(data => {
                this.gridData = [];

            });

        this.filterVersions = [];
        this.filterDomains = [];
        this.filterBaselines = [];
        this.searchBRStudy.brBaseline = 'undefined';
        this.searchBRStudy.brSdtmDomain === 'undefined'
    }

    public removeHandlerBR() {
        this.isNew = 'delete';
    }




}

