import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-confirmation-box',
  templateUrl: './confirmation-box.component.html',
  styleUrls: ['./confirmation-box.component.css']
})
export class ConfirmationBoxComponent implements OnInit {
  public active = false;
  public opened = false;
  public errorMsg: string;
  @Input() public popupType;
  @Input() public status;
  @Input() public set model(item) {
    console.log(this.popupType);
    this.active = item !== undefined  && this.popupType === 'success';
  }
  @Output() cancel: EventEmitter<any> = new EventEmitter();
    constructor() { }
    public close() {
      this.opened = false;
    }
    public onClose(e): void {
      e.preventDefault();
      this.closeForm();
    }
    private closeForm(): void {
      this.active = false;
      this.cancel.emit();
    }
    ngOnInit() {
    }
}
