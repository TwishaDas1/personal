import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-lineage',
  templateUrl: './data-lineage.component.html',
  styleUrls: ['./data-lineage.component.css']
})
export class DataLineageComponent implements OnInit {

 

  constructor() { }

  ngOnInit() {

    
  }

}
