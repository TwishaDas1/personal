import { Component, OnInit , Inject} from '@angular/core';
import { EditService } from '../../Services';
@Component({
  selector: 'app-directory',
  templateUrl: './directory.component.html',
  styleUrls: ['./directory.component.css']
})
export class DirectoryComponent implements OnInit {
  public arrowState = [];
  public subarrowState = [];
  public panelState = [];
  public subpanelState = [];
  configTypeIcons: Object[];
  navBarItems: Object[];
  private editService: EditService;
  public directory = {};
  public popupType: any;
  public status: string;
  public item: any = undefined;
  public cancelHandler() {
    this.item = undefined;
    this.popupType = '';
    for (let i = 0 ; i < 2 ; i++) {
      console.log('heyyyyyy');
      this.arrowState[i] = 'assets/images/headerdwn.png';
      this.panelState[i] = true;
      const arr1 = [];
      const arr2 = [];
      for (let j = 0 ; j < 3; j++) {
          arr1[j] = false;
          arr2[j] = 'assets/images/subheaderryt.png';
      }
      this.subarrowState[i] = arr2;
      this.subpanelState[i] = arr1;
    }
  }
  constructor(@Inject(EditService) editServiceFactory: any) {
    this.editService = editServiceFactory();
   }
  public changeArrow(MainId) {
    this.panelState[MainId] = !this.panelState[MainId];
   // this.panelState[MainId + 1] = !this.panelState[MainId + 1];
   // this.panelState[MainId + 2] = !this.panelState[MainId + 2];
    if (this.arrowState[MainId] === 'assets/images/headerryt.png') {
       this.arrowState[MainId] = 'assets/images/headerdwn.png';
    } else {
      this.arrowState[MainId] = 'assets/images/headerryt.png';
      for (let j = 0 ; j < 3 ; j ++) {
        this.subpanelState[MainId][j] = false;
        this.subarrowState[MainId][j] = 'assets/images/subheaderryt.png';
     }
    }
  }
  public changesubArrow(MainId, subId) {
   this.subpanelState[MainId][subId] = !this.subpanelState[MainId][subId];
   if (this.subarrowState[MainId][subId] === 'assets/images/subheaderryt.png') {
    this.subarrowState[MainId][subId] = 'assets/images/subheaderdwn.png';
 } else {
   this.subarrowState[MainId][subId] = 'assets/images/subheaderryt.png';
 }
  }
  public save(form) {
    console.log(form.value.awsrootdirectory);
    this.directory = {
      'serverEnvironmentDTO': {
        'serverName': 'S3',
        'description': 'S3 data',
        'serverEnvironmentDetailDTOs': [
          {
            'environmentType': 'Dev',
            'rootDirectoryName': form.value.devawsrootdirectory,
            'sourceFileDirectoryName': form.value.devsourcedirectory,
            'regionName': form.value.devsourcedirectory,
            'sourceFileLandingLocation': form.value.devlandinglocation,
            'sdtmDirectoryName': form.value.devsdtmdirectory
          },
          {
            'environmentType': 'Prod',
            'rootDirectoryName': form.value.prodawsrootdirectory,
            'sourceFileDirectoryName': form.value.prodsourcedirectory,
            'regionName': form.value.prodsourcedirectory,
            'sourceFileLandingLocation': form.value.prodlandinglocation,
            'sdtmDirectoryName': form.value.prodsdtmdirectory
          },
          {
            'environmentType': 'QA',
            'rootDirectoryName': form.value.qaawsrootdirectory,
            'sourceFileDirectoryName': form.value.qasourcedirectory,
            'regionName': form.value.qasourcedirectory,
            'sourceFileLandingLocation': form.value.qalandinglocation,
            'sdtmDirectoryName': form.value.qasdtmdirectory
          }

          ]
      },
      'databaseEnvironmentDTO': {
        'dbServerName': 'RDS',
        'description': 'this is rds',
        'databaseEnvironmentDetailDTOs': [
          {
            'environmentType': 'Dev',
            'databaseName': form.value.devdatabase,
            'portName': form.value.devport,
            'hostName': form.value.devhost,
            'schemaName': form.value.devschema
          },
          {
            'environmentType': 'Prod',
            'databaseName': form.value.proddatabase,
            'portName': form.value.prodport,
            'hostName': form.value.prodhost,
            'schemaName': form.value.prodschema
          },
          {
            'environmentType': 'QA',
            'databaseName': form.value.qadatabase,
            'portName': form.value.qaport,
            'hostName': form.value.qahost,
            'schemaName': form.value.qaschema
          }

          ]
      }
    };

    console.log(this.directory);
    this.editService.saveDirectoryData(this.directory).subscribe((res) => {
      console.log('first');
      this.popupType = 'success';
      this.item = 'Successfully Saved the Environment Details';
      this.status = 'Successfully Saved the Environment Details';
     // console.log(res.text());
    });

  }
  ngOnInit() {
    this.navBarItems = [
      { "navBarTitle": "Directory", "navBarLink": "/sdtm/metadata" },
      { "navBarTitle": "Source Metadata", "navBarLink": "sourcemetadata" },
      { "navBarTitle": "SDTM Target Metadata", "navBarLink": "sdtmmetadata" },
      { "navBarTitle": "Transformation Template", "navBarLink": "transformation" }


    ];
  
    for (let i = 0 ; i < 2 ; i++) {
      this.arrowState[i] = 'assets/images/headerdwn.png';
      this.panelState[i] = true;
      const arr1 = [];
      const arr2 = [];
      for (let j = 0 ; j < 3; j++) {
          arr1[j] = false;
          arr2[j] = 'assets/images/subheaderryt.png';
      }
      this.subarrowState[i] = arr2;
      this.subpanelState[i] = arr1;
    }
  }

}
