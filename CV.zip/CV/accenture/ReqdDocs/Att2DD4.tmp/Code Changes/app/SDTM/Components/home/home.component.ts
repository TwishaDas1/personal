import { Component, OnInit } from '@angular/core';
import { UserService } from '../../Services';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userName = '';
  isSdtmUser = false;
  isAdminUser = false;
  isDqUser = false;
  firstName: string;
  appName: string;
  constructor(private userService: UserService) { }
  ngOnInit() {
    this.appName = " - SDTM Conversion";
    const userDetails = this.userService.getUser();
    this.firstName = userDetails.firstName;
    if (userDetails.userRole === 'manager') {
      this.isAdminUser = true;
    } else if (userDetails.userRole === 'analyst') {
      this.isSdtmUser = true;
    } else if (userDetails.userRole === 'analyst') {
      this.isDqUser = true;
    }
  }
}