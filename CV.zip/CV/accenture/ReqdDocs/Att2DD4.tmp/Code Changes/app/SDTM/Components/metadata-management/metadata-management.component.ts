import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-metadata-management',
  templateUrl: './metadata-management.component.html',
  styleUrls: ['./metadata-management.component.css']
})
export class MetadataManagementComponent implements OnInit {
  configTypeIcons: Object[];
  configTypeImage: string;
  configTypeTitle: string;
  configTypeLinks: Object[];
  navBarItems: Object[];
  heading: string;
  constructor() { }

  ngOnInit() {
    this.configTypeImage = 'assets/images/meta.png';
    this.heading = 'Metadata Management';
  }

}
