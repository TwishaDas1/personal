import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { SeriesLabels } from '@progress/kendo-angular-charts';
import { LegendLabels } from '@progress/kendo-angular-charts';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { UserService } from '../../Services';
import { DashboardResultItem } from '../../Models';
import { NotificationItem } from '../../Models/notification';

@Component({
  selector: 'sdtm-home',
  templateUrl: './sdtm-home.component.html',
  styleUrls: ['./sdtm-home.component.css']
})
export class SdtmHomeComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private userService: UserService
  ) { }
  boxSize = 970;

  dashboardResults: any[] = [];
  listStudyIds = [];
  //dashboardResultItems : dashboardResultItem[]=[];
  dashBoardData: any[] = [];
  //pieDataItem	=[];
  //pieDataItemTwo =[];
  public valuePlotBands: any[] = [];
  navBarItems: Object[];
  appName: string;
  firstName: string;
  public isCollapsed = false;
  dashboardResultItemMap = new Map();
  dashboardNotificationsMap = new Map();
  dashboardNotificationsOpenMap = new Map();
  dashboardNotificationsNewMap = new Map();
  dashboardUpcomingTasksMap = new Map();
  dashboardOverdueTasksMap = new Map();
  notifications: NotificationItem[] = [];
  listOfNotificationsIds: any[] = [];
  public seriesData: any[] = [];
  userRole: string;



  public seriesLabels: SeriesLabels = {
    visible: true, // Note that visible defaults to false
    padding: 3,
    font: 'bold 12px Open Sans',
  };

  public seriesPieLabels: SeriesLabels = {
    visible: true, // Note that visible defaults to false
    font: 'bold 10px Open Sans',
    color: 'white',
    position: 'center',
  };

  public legendLabels: LegendLabels = {
    font: '10px Open Sans',
    color: 'black'
  };

  public hidden: any = { visible: false };


  ngOnInit() {

    this.appName = " - Path to SDTM";
    this.navBarItems = [
      { "navBarTitle": "Home", "navBarLink": "/sdtmHome" },
      { "navBarTitle": "Study Configuration", "navBarLink": "studySetup" },
      { "navBarTitle": "Business Rule Configuration", "navBarLink": "businessRules" },
      { "navBarTitle": "Job Execution", "navBarLink": "jobExecution" }];

    this.http.get<any[]>(`/api/CDR/pathToSdtmDashBoard`).subscribe(data => {
      this.dashboardResults = data;
      this.dashBoardData = data.reduce((item, x) =>
        item.concat(item.find(y => y.studyID === x.studyID) ? [] : [x])
        , []);
      this.populateGraphs();
      //populate the notifications with the help of list of study ids
      this.populateNotifications();
      this.boxSize = (this.boxSize * this.dashBoardData.length) + 100;
      this.setDataForAccordion();
      this.updateDbNewNotificationsFlag();
    });

    const userDetails = this.userService.getUser();
    this.firstName = userDetails.firstName;
    this.userRole = userDetails.userRole;
  }

  public populateGraphs() {
    let domains = {};

    for (let item of this.dashboardResults) {
      if (!(this.dashboardResultItemMap.has(item.studyID))) {
        domains = {};
        this.listStudyIds.push(item.studyID);// all unique ids in this list
        //let pieDataItem=[];
        //let pieDataItemTwo=[];
        let pieDataItem = [
          { category: 'In Progress', value: 0 },
          { category: 'Ready for Review', value: 0 },
          { category: 'Approved', value: 0 },
          { category: 'Rejected', value: 0 },
          { category: 'Not Started', value: 0 }
        ];
        let pieDataItemTwo = [
          { category: 'Enabled', value: 0 },
          { category: 'Disabled', value: 0 }
        ];

        pieDataItem = this.incrementCount(pieDataItem, item.domainStatus);
        pieDataItemTwo = this.incrementCount(pieDataItemTwo, item.jobEnablementStatus);

        let dashboardResultItems = new DashboardResultItem();
        dashboardResultItems.studyID = item.studyID;
        dashboardResultItems.countOfAllDomains = 1;
        dashboardResultItems.pieData = pieDataItem;
        dashboardResultItems.pieDataTwo = pieDataItemTwo;
        let jobstatus = "";
        if (item.jobStatus == null || item.jobStatus.length == 0 || item.jobStatus == "") {
          jobstatus = 'Not started';
        }
        else {
          jobstatus = item.jobStatus;
        }
        domains =
          {
            category: item.jobDomainName,
            code: item.domainName,
            businessRuleConfigStatus: item.domainStatus,
            jobExecutionStatus: jobstatus,
            jobDisabledStatus: item.jobEnablementStatus
          };

        if (item.jobDomainName) {
          dashboardResultItems.jobExecutionDomainDetails.push(domains);
        }

        this.dashboardResultItemMap.set(item.studyID, dashboardResultItems);


      }//if
      else {
        let pieDataItem = [];
        let pieDataItemTwo = [];
        domains = {};

        let dashboardResultItems = this.dashboardResultItemMap.get(item.studyID);
        pieDataItem = this.incrementCount(dashboardResultItems.pieData, item.domainStatus);
        pieDataItemTwo = this.incrementCount(dashboardResultItems.pieDataTwo, item.jobEnablementStatus);

        dashboardResultItems.pieData = pieDataItem;
        dashboardResultItems.pieDataTwo = pieDataItemTwo;
        dashboardResultItems.countOfAllDomains = (dashboardResultItems.countOfAllDomains) + 1;

        domains =
          {
            category: item.jobDomainName,
            code: item.domainName,
            businessRuleConfigStatus: item.domainStatus,
            jobExecutionStatus: item.jobStatus,
            jobDisabledStatus: item.jobEnablementStatus
          }
          ;
        if (item.jobDomainName) {
          dashboardResultItems.jobExecutionDomainDetails.push(domains);
        }
        //delete old entry and insert updated values in map
        this.dashboardResultItemMap.delete(item.studyID);
        this.dashboardResultItemMap.set(item.studyID, dashboardResultItems);

      }

    }//end of for

    //loop over the map and add to list which will be used to display on screen
  	/*for (let value of this.dashboardResultItemMap.values()) {
      this.dashBoardData.push(value);
	}*/

  }

  public incrementCount(list, categoryToFind) {
    let indexInList = 0;
    for (let item of list) {
      if (item.category == categoryToFind) {
        item.value = item.value + 1;
        indexInList = list.indexOf(item);
        list[indexInList] = item;
        break;
      }
    }
    return list;
  }

  public getPieData(studyID) {
    return this.dashboardResultItemMap.get(studyID).pieData;
  }

  public getPieDataTwo(studyID) {
    return this.dashboardResultItemMap.get(studyID).pieDataTwo;
  }

  public setDataForAccordion() {
    let index = 0;
    for (const study of this.dashBoardData) {
      index = this.dashBoardData.indexOf(study);
      if (index === 0) {
        this.dashBoardData[index].isSectionCollapsed = true;
      } else {
        this.dashBoardData[index].isSectionCollapsed = false;
      }
      //this.dashBoardData[index].isStudySectionCollapsed = false;
    }
  }


  /*
  export interface dashboardResultItemMap {
  [key: string]: dashboardResultItem;
}*/

  //countOfDomains,
  public getValuePlotBands() {
    this.valuePlotBands = [{
      from: 9,
      to: 9 + 0.25,
      //countOfAllDomains
      color: '#074982',
      opacity: 0.6
    }];
    return this.valuePlotBands;
  }

  public getSeriesData(countOfAllDomains) {
    this.seriesData = [{
      study: 'This Study',
      domains: countOfAllDomains
    }];
    return this.seriesData;

  }

  public navigateToBusinessRules(dataItem: any, item: any) {
    this.router.navigate([`/sdtm/businessRulesFromJob/${dataItem.studyTitle}/${item.code}`]);


  }
  public navigateToJobExecution(dataItem: any) {

    this.router.navigate([`/sdtm/jobExecution/${dataItem.studyTitle}`]);
  }

  public populateNotifications() {
    return this.http.get<any[]>(`/api/CDR/notifications/find/studyIds/${this.listStudyIds}/${this.userRole}`)
      .subscribe(data => { this.parseDataforNotifications(data) });
  }

  public getNotifications(studyID) {
    return this.dashboardNotificationsMap.get(studyID);
  }

  public parseDataforNotifications(results) {
    var d = new Date();//todays date
    var year = d.getFullYear();
    var month = d.getMonth() + 1;
    var day = d.getDate();
    var today = year + "-" + month + "-" + day;

    var thresholdOverdueTaskDate = 7;
    for (let studyId of this.listStudyIds) {
      let notificationsList: NotificationItem[] = [];
      let notificationNewCount = 0;
      let notificationOpenCount = 0;
      let upcomingTaskCount = 0;
      let overdueTaskCount = 0;

      this.listOfNotificationsIds = [];

      for (let item of results) {

        if (item.studyID == studyId) {
          let notification = new NotificationItem();
          notification.studyID = item.studyID;
          notification.id = item.id;
          this.listOfNotificationsIds.push(item.id);
          var appendMessage = "";
          if (item.task_due_date) {
            if (this.getDuration(today, item.task_due_date) < 0) {
              //Task is overdue
              appendMessage = "The following task is overdue: ";
              overdueTaskCount = overdueTaskCount + 1;

            } else if (this.getDuration(today, item.task_due_date) <= thresholdOverdueTaskDate) {
              //Task due in 7 days
              appendMessage = "The following task is due in 7 days: ";
              upcomingTaskCount = upcomingTaskCount + 1;

            }
            item.notification_desc = appendMessage + item.notification_desc;

          }
          notification.notification_desc = item.notification_desc;
          notification.create_dt = item.create_dt;
          notification.notification_delete = item.notification_delete;
          notification.notification_stop = item.notification_stop;
          notification.task_desc = item.task_desc;
          notification.task_due_date = item.task_due_date;
          //notification.notification_new=item.notification_new;
          notification.task_complete = item.task_complete;

          if (notification.notification_stop == 'N') {
            notificationNewCount = notificationNewCount + 1;
            notification.removeRedFlag = false;
            notification.removeStopWatch = false;
          } else {
            notificationOpenCount = notificationOpenCount + 1;
            notification.removeRedFlag = true;
            notification.removeStopWatch = true;
          }

          notificationsList.push(notification);
        }

      }
      this.dashboardNotificationsNewMap.set(studyId, notificationNewCount);
      this.dashboardNotificationsOpenMap.set(studyId, notificationOpenCount);
      this.dashboardOverdueTasksMap.set(studyId, overdueTaskCount);
      this.dashboardUpcomingTasksMap.set(studyId, upcomingTaskCount);
      this.dashboardNotificationsMap.set(studyId, notificationsList);
      console.log("studyId " + studyId + " count of noti " + notificationsList.length);
    }
  }

  public getNewNotifications(studyId) {
    return this.dashboardNotificationsNewMap.get(studyId);

  }
  public getOpenNotifications(studyId) {

    return this.dashboardNotificationsOpenMap.get(studyId);

  }

  public deleteNotification(item) {
    let currentList = this.dashboardNotificationsMap.get(item.studyID);
    for (let notification of currentList) {
      if (item.id == notification.id) {
        const index: number = currentList.indexOf(notification);
        if (index !== -1) {
          currentList.splice(index, 1);
        }
      }
    }
    this.dashboardNotificationsMap.delete(item.studyId);
    this.dashboardNotificationsMap.set(item.studyId, currentList);
    let openCount = 0;
    let newCount = 0;
    if (item.removeStopWatch == true) {
      //notification is read/ stopwatch already clicked
      openCount = (this.dashboardNotificationsOpenMap.get(item.studyID)) - 1;
    } else {
      newCount = (this.dashboardNotificationsNewMap.get(item.studyID)) - 1;
    }
    this.dashboardNotificationsNewMap.delete(item.studyID);
    this.dashboardNotificationsNewMap.set(item.studyID, newCount);
    this.dashboardNotificationsOpenMap.delete(item.studyID);
    this.dashboardNotificationsOpenMap.set(item.studyID, openCount);
    const searchUrl = '/api/CDR/notifications/delete/id';
    const url = `${searchUrl}/${item.id}`;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put(url, item, { headers: headers }).subscribe(data => {
    });
  }


  public stopNotification(item) {
    item.removeRedFlag = true;
    item.removeStopWatch = true;
    let newCount = (this.dashboardNotificationsNewMap.get(item.studyID)) - 1;
    let openCount = (this.dashboardNotificationsOpenMap.get(item.studyID)) + 1;
    this.dashboardNotificationsNewMap.delete(item.studyID);
    this.dashboardNotificationsNewMap.set(item.studyID, newCount);
    this.dashboardNotificationsOpenMap.delete(item.studyID);
    this.dashboardNotificationsOpenMap.set(item.studyID, openCount);

    const searchUrl = '/api/CDR/notifications/updateStopStatus/id';
    const url = `${searchUrl}/${item.id}`;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put(url, null, { headers: headers }).subscribe(data => {
    });

  }


  public updateDbNewNotificationsFlag() {
    const searchUrl = '/api/CDR/notifications/updateStatus/ids';
    const url = `${searchUrl}/${this.listOfNotificationsIds}`;
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.put(url, null, { headers: headers }).subscribe(data => {
    });
  }

  public getDuration(startTime, endTime) {
    var eventStartTime = new Date(startTime);
    var eventEndTime = new Date(endTime);
    var duration = eventEndTime.valueOf() - eventStartTime.valueOf();
    //var diff = Math.abs(eventEndTime.getTime() - eventEndTime.getTime());
    //var diffDays = Math.ceil(diff / (1000 * 3600 * 24));
    var duration = eventEndTime.getTime() - eventStartTime.getTime();
    var diffDays = duration / (60 * 60 * 24 * 1000);

    return diffDays;
  }

  public getSeriesDataTwo(studyId) {
    let overdueTasks = this.dashboardOverdueTasksMap.get(studyId);
    let upcomingTasks = this.dashboardUpcomingTasksMap.get(studyId);
    let seriesDataTwo = [
      {
        type: 'Overdue',
        countOfTasks: overdueTasks,
        color: 'red'
      },
      {
        type: 'Due in 7 Days',
        countOfTasks: upcomingTasks,
        color: 'brown'
      }];
    return seriesDataTwo;
  }
  tooltip: {
    visible: true;
  }
}