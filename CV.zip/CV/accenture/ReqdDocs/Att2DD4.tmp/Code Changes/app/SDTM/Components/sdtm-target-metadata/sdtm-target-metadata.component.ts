import { Component, OnInit, Inject  } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { ActivatedRoute, Router } from '@angular/router';
import { EditService, UserService, BusinessEditService } from '../../Services';
import { SdtmTargetMetaData } from '../../Models';

@Component({
  selector: 'app-sdtm-target-metadata',
  templateUrl: './sdtm-target-metadata.component.html',
  styleUrls: ['./sdtm-target-metadata.component.css']
})
export class SdtmTargetMetadataComponent implements OnInit {

  private editService: EditService;
  sdtmversionDrpSelected = false;
  sdtmversionShowOptions = false;
  domainDrpSelected = false;
  domainShowOptions = false;
  public arrowState = [];
  public panelState = [];
  public data;
  public mainData;
  public sdtmTargetMetadata;
  public sdtmVersions = [];
  public sdtmDomains = [];
  public searchObject: any = {};
  public searchTargetMetadata: SdtmTargetMetaData;
  navBarItems: Object[];
  configTypeIcons: Object[];
  public popupType: any;
  public item = [];
  public title: any = undefined;
  public downloaddata = [];
  public domain = [];
  public versions = [];
  public headerCells: any = {
    background: '#CDE4FE',
    fontWeight: '700',
    fontFamily: 'Open Sans',
    color: '#333333',
    fontSize: '13px',
  };
  public domains = "undefined";
  public subheaderCells: any = {
    fontWeight: 'Bold',
    fontFamily: 'Open Sans',
    color: '#000000'
  };
  public selected = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9'
  };
  public default = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9'
  };
  public addHandler(data) {
    this.item = [];
    this.downloaddata = [];
    this.popupType = data;
  //  console.log(this.item);
  //  console.log(this.data.sourceMetadataDTO.length);
  for (let i = 0 ; i < this.data.sdtmTargerMetadataDTOs.length ; i++) {
    const source = this.data.sdtmTargerMetadataDTOs[i];
    if (this.data.sdtmTargerMetadataDTOs[i].sdtmDomainMetadataDTOs !== null) {
    for (let j = 0 ; j < this.data.sdtmTargerMetadataDTOs[i].sdtmDomainMetadataDTOs.length ; j++) {
            const form = source.sdtmDomainMetadataDTOs[j];
            if (this.data.sdtmTargerMetadataDTOs[i].sdtmDomainMetadataDTOs[j].sdtmVariableMetadataDTOs !== null) {
            for (let k = 0 ; k < this.data.sdtmTargerMetadataDTOs[i].sdtmDomainMetadataDTOs[j].sdtmVariableMetadataDTOs.length ; k++) {
             // const template = new SourceMetadatatemplate();
              const variable =  form.sdtmVariableMetadataDTOs[k];
            //  console.log(variable.formVariableName);
            let sdtm = {
              'domainsName': form.domainName,
              'description': form.description,
              'clazz': form.clazz,
              'structure': form.structure,
              'purpose': form.purpose,
              'keys': form.keys,
              'location': form.location,
              'version': form.version,
              'sdtmVariableName': variable.sdtmVariableName,
              'sdtmVariableDescription': variable.sdtmVariableDescription,
              'type': variable.type,
              'controlledTermsCodelistFormat': variable.controlledTermsCodelistFormat,
              'role': variable.role,
              'cdsicNotes': variable.cdsicNotes,
              'core': variable.core,
            };
              this.item.push(sdtm);
            }
          } else {
            let sdtm = {
              'domainsName': form.domainName,
              'description': form.description,
              'clazz': form.clazz,
              'structure': form.structure,
              'purpose': form.purpose,
              'keys': form.keys,
              'location': form.location,
              'version': form.version,
              'sdtmVariableName': '',
              'sdtmVariableDescription': '',
              'type': '',
              'controlledTermsCodelistFormat': '',
              'role': '',
              'cdsicNotes': '',
              'core': '',
            };
              this.item.push(sdtm);
          }

    }
  }
}


    console.log(this.item);
    this.title = 'SDTM Target MetaData';
    this.downloaddata = this.item;
    console.log(this.downloaddata);

  }
  public downloadHandler(item) {
    console.log(item);
    this.item = [];
    this.title = undefined;
    this.downloaddata = [];
    this.popupType = '';
  }
  public cancelHandler() {
    this.item = [];
    this.title = undefined;
    this.downloaddata = [];
    this.popupType = '';
  }

  constructor(@Inject(EditService) editServiceFactory: any) {
      this.editService = editServiceFactory();
     }

  ngOnInit() {
    this.navBarItems = [
      { "navBarTitle": "Directory", "navBarLink": "/sdtm/metadata" },
      { "navBarTitle": "Source Metadata", "navBarLink": "/sdtm/metadata/sourcemetadata" },
      { "navBarTitle": "SDTM Target Metadata", "navBarLink": "/sdtm/metadata/sdtmmetadata" },
      { "navBarTitle": "Transformation Template", "navBarLink": "/sdtm/metadata/transformation" }


    ];
    this.configTypeIcons =  [
      { 'icontitle':  'Upload',  'iconImageSrc':  'assets/images/NewNote.png',  'action':  'upload',  'inputParam':  '' },
      { 'icontitle':  'Download',  'iconImageSrc':  'assets/images/studyDownload.png',  'action':  'download',  'inputParam':  '' },
      ];
    console.log('In OnInit');

      this.editService.fetchSdtmVersions().subscribe( (res: Response)  => {
      this.data = res;
      this.mainData = res;
      console.log(this.data);
      console.log(this.data.sdtmVersionDomainDTOs);
      this.sdtmVersions = this.data.sdtmVersionDomainDTOs;
      this.sdtmTargetMetadata = this.data.sdtmTargerMetadataDTOs;
      console.log(this.sdtmVersions);
      console.log(this.sdtmTargetMetadata);

      for (let c = 0 ; c < this.sdtmTargetMetadata.length ; c++) {
        this.arrowState[c] = 'assets/images/headerryt.png';
        this.panelState[c] = false;
      }
      for (let c = 0 ; c < this.sdtmVersions.length ; c++) {
        for (let b = 0 ; b < this.sdtmVersions[c].domainDTO.length ; b++) {
             this.sdtmDomains.push(this.sdtmVersions[c].domainDTO[b]);
        }
       }
      console.log(this.sdtmTargetMetadata);
    });

  /*  for (let c = 0 ; c < this.sdtmTargetMetadata.length ; c++) {
      console.log('in for ' + this.sdtmTargetMetadata.length + ' = ' + c);
      this.arrowState[c] = 'assets/images/arrow-right.png';
      this.panelState[c] = false;
    }*/
  }

  public changeArrow(MainId) {
    this.panelState[MainId] = !this.panelState[MainId];
    if (this.arrowState[MainId] === 'assets/images/headerryt.png') {
       this.arrowState[MainId] = 'assets/images/headerdwn.png';
    } else {
      this.arrowState[MainId] = 'assets/images/headerryt.png';
    }
  }

  public clear() {
    this.searchTargetMetadata = null;
    this.sdtmversionDrpSelected = false;
   // this.sdtmversionShowOptions = false;
    this.domainDrpSelected = false;
  //  this.domainShowOptions = false;
    this.searchObject = {};
    this.filterStudies('all');
    this.selected = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9'
    };
    this.default = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9'
    };
  }

  public filterStudies(sdtmVersion: any) {
    console.log(sdtmVersion);
    this.selected = {
      color: '#3B3838',
    border: '1px solid #A5A5A5'
  };
    if (sdtmVersion === 'undefined') {
      // do nothing
    } else if (sdtmVersion === 'all') {
      // do for all
     this.default = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9'
     };
        this.domains = 'undefined';
        this.editService.fetchSdtmVersions().subscribe( (res: Response)  => {
        this.data = res;
        this.sdtmVersions = this.data.sdtmVersionDomainDTOs;
        this.sdtmTargetMetadata = this.data.sdtmTargerMetadataDTOs;
        this.sdtmDomains = [];
        for (let c = 0 ; c < this.sdtmTargetMetadata.length ; c++) {
          this.arrowState[c] = 'assets/images/headerryt.png';
          this.panelState[c] = false;
        }
        for (let c = 0 ; c < this.sdtmVersions.length ; c++) {
          for (let b = 0 ; b < this.sdtmVersions[c].domainDTO.length ; b++) {
               this.sdtmDomains.push(this.sdtmVersions[c].domainDTO[b]);
          }
         }
       });
    } else {
      this.default = {
        color: '#7C7C7C',
        border: '1px solid #C9C9C9'
       };
      const idx = this.sdtmVersions.findIndex(record => record.version[0] === sdtmVersion);
      this.domains = 'undefined';
      console.log(idx);
      console.log(this.sdtmVersions[idx].domainDTO);
      this.sdtmDomains = Object.assign([], this.sdtmVersions[idx].domainDTO);
      console.log(this.sdtmDomains);
     // console.log(this.searchObject.domains);
    }
  }

/*  public sdtmVersionDrp(): void {
    if (this.sdtmversionDrpSelected === false) {
      this.sdtmversionShowOptions = true;
      this.sdtmversionDrpSelected = true;
    } else {
      this.sdtmversionShowOptions = false;
      this.sdtmversionDrpSelected = false;
    }
  }
  public domainDrp(): void {
    if (this.domainDrpSelected === false) {
      this.domainShowOptions = true;
      this.domainDrpSelected = true;
    } else {
      this.domainShowOptions = false;
      this.domainDrpSelected = false;
    }
  }*/

  public filterSdtmTargetMetadata(searchObject) {
    this.default = {
      color: '#3B3838',
    border: '1px solid #A5A5A5'
    };
    console.log(searchObject);
    console.log(searchObject.sdtmVersion);
    console.log(searchObject.domains);
    this.versions = [];
    for (let c = 0 ; c < this.sdtmVersions.length ; c++) {
      for (let b = 0 ; b < this.sdtmVersions[c].domainDTO.length ; b++) {
           if (this.domains === this.sdtmVersions[c].domainDTO[b].domain) {
             this.versions.push(this.sdtmVersions[c].version[0]);
           }
      }
     }
    if (searchObject.sdtmVersion !== 'all' && searchObject.sdtmVersion !== undefined  ) {
     this.searchTargetMetadata = {
       version: [searchObject.sdtmVersion],
       domainDTO: [
      {
        domain: this.domains,
      }
      ]
     };
    console.log(this.searchTargetMetadata);

    this.editService.getSdtmTargetMetadata(this.searchTargetMetadata).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      this.sdtmTargetMetadata = this.data.sdtmTargerMetadataDTOs;
      console.log(this.sdtmTargetMetadata);
      for (let c = 0 ; c < this.sdtmTargetMetadata.length ; c++) {
        this.arrowState[c] = 'assets/images/headerdwn.png';
        this.panelState[c] = true;
      }

    });
  } else  {
    this.searchTargetMetadata = {
      version: this.versions,
      domainDTO: [
     {
       domain: this.domains,
     }
     ]
    };
   console.log(this.searchTargetMetadata);

   this.editService.getSdtmTargetMetadata(this.searchTargetMetadata).subscribe((res: Response) => {
     console.log(res);
     this.data = res;
     this.sdtmTargetMetadata = this.data.sdtmTargerMetadataDTOs;
     console.log(this.sdtmTargetMetadata);
     for (let c = 0 ; c < this.sdtmTargetMetadata.length ; c++) {
       this.arrowState[c] = 'assets/images/headerdwn.png';
       this.panelState[c] = true;
     }

   });
 }
 }
  }

