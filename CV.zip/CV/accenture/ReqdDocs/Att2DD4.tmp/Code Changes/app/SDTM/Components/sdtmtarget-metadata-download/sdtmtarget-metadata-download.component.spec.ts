import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SdtmtargetMetadataDownloadComponent } from './sdtmtarget-metadata-download.component';

describe('SdtmtargetMetadataDownloadComponent', () => {
  let component: SdtmtargetMetadataDownloadComponent;
  let fixture: ComponentFixture<SdtmtargetMetadataDownloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SdtmtargetMetadataDownloadComponent ]
    })
    .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(SdtmtargetMetadataDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
