import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-sdtmtarget-metadata-download',
  templateUrl: './sdtmtarget-metadata-download.component.html',
  styleUrls: ['./sdtmtarget-metadata-download.component.css']
})
export class SdtmtargetMetadataDownloadComponent implements OnInit {

  public active = false;
  public opened = false;
  public errorMsg: string;
  public headerCells: any = {
    background: '#0000CD',
    textAlign: 'center'
};
public headerCell: any = {
  background: '#008000',
  textAlign: 'center'
};
public subheader: any = {
  background: '#FFFF33',
  textAlign: 'center',
  color: '#000000',
  bold: true
};

public subheader1: any = {
  background: '#C3D4E5',
  textAlign: 'center',
  color: '#000000',
  bold: true
};
public subheader2: any = {
  background: '#D0EFDF',
  textAlign: 'center',
  color: '#000000',
  bold: true
};

@Input() public popupType;
@Input() public downloaddata;
@Input() public set model(item) {
  console.log(this.popupType);
  this.active = this.downloaddata !== []  && this.popupType === 'download';
}
@Output() cancel: EventEmitter<any> = new EventEmitter();
@Output() download: EventEmitter<any> = new EventEmitter();
  constructor() { }
  public close() {
    this.opened = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
  }

  private closeForm(): void {
    this.errorMsg = '';
    this.active = false;
    this.cancel.emit();
  }

  public onDownload(e): void {
    e.preventDefault();
    console.log(this.downloaddata);
    this.active = false;
    this.download.emit();
  }
  ngOnInit() {
  }

}
