import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SourceMetadataDownloadComponent } from './source-metadata-download.component';

describe('SourceMetadataDownloadComponent', () => {
  let component: SourceMetadataDownloadComponent;
  let fixture: ComponentFixture<SourceMetadataDownloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SourceMetadataDownloadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SourceMetadataDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
