import { Component, OnInit, Inject  } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators/map';
import { EditService, UserService, BusinessEditService } from '../../Services';
import { SourceMetaData } from '../../Models';

@Component({
  selector: 'app-source-metadata',
  templateUrl: './source-metadata.component.html',
  styleUrls: ['./source-metadata.component.css']
})
export class SourceMetadataComponent implements OnInit {

  private editService: EditService;
  public sourceNameShowOptions: boolean;
  public sourceNameSelected: boolean;
  public sourceTypeShowOptions: boolean;
  public sourceTypeSelected: boolean;
  public searchSource: SourceMetaData;
  public searchObject: any = {};
  public data;
  public mainData;
  public sourceMetadata;
  public sourcename = "undefined";
  public arrowState = [];
  public panelState = [];
  public sourceTypes = [];
  public sourceNames = [];
  public srctypes = [];
  public SrceNames = [];
  navBarItems: Object[];
  configTypeIcons: Object[];
  public popupType: any;
  public item = [];
  public title: any = undefined;
  public downloaddata = [];
  public selected = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
  };
  public default = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
  };
  public headerCells: any = {
    background: '#CDE4FE',
    fontWeight: '700',
    fontFamily: 'Open Sans',
    color: '#333333',
    fontSize: '13px',
  };
  public subheaderCells: any = {
    fontWeight: 'Bold',
    fontFamily: 'Open Sans',
    color: '#000000'
  };
  public addHandler(data) {
    this.item = [];
    this.downloaddata = [];
    this.popupType = data;
  //  console.log(this.item);
  //  console.log(this.data.sourceMetadataDTO.length);
  /*  for (let i = 0 ; i < this.data.sourceMetadataDTO.length ; i++) {
        const source = this.data.sourceMetadataDTO[i];
        for (let j = 0 ; j < source.formMetaDataDTOs.length ; j++) {
                const form = this.data.sourceMetadataDTO[i].formMetaDataDTOs[j];
                for (let k = 0 ; k < form.formVariableMetaDataDTOs.length ; k++) {
                 // const template = new SourceMetadatatemplate();
                  const variable =  this.data.sourceMetadataDTO[i].formMetaDataDTOs[j].formVariableMetaDataDTOs[k];
                  console.log(variable.formVariableName);
                  this.item.push(variable);
                }
        }
    }*/
    console.log(this.item);
    this.title = 'Source MetaData';
    this.downloaddata = this.item;
    console.log(this.downloaddata);

  }
  public downloadHandler(item) {
    console.log(item);
    this.item = [];
    this.title = undefined;
    this.downloaddata = [];
    this.popupType = '';
  }
  public cancelHandler() {
    this.item = [];
    this.title = undefined;
    this.downloaddata = [];
    this.popupType = '';
  }
  constructor(private userService: UserService,
    private router: Router,
    private route: ActivatedRoute, @Inject(EditService) editServiceFactory: any) {
      this.editService = editServiceFactory();
    }

  ngOnInit() {
    this.navBarItems = [
      { "navBarTitle": "Directory", "navBarLink": "/sdtm/metadata" },
      { "navBarTitle": "Source Metadata", "navBarLink": "/sdtm/metadata/sourcemetadata" },
      { "navBarTitle": "SDTM Target Metadata", "navBarLink": "/sdtm/metadata/sdtmmetadata" },
      { "navBarTitle": "Transformation Template", "navBarLink": "/sdtm/metadata/transformation" }


    ];
    this.configTypeIcons =  [
      { 'icontitle':  'Upload',  'iconImageSrc':  'assets/images/NewNote.png',  'action':  'upload',  'inputParam':  '' },
      { 'icontitle':  'Download',  'iconImageSrc':  'assets/images/studyDownload.png',  'action':  'download',  'inputParam':  '' },
      ];
    console.log('In OnInit');


      this.editService.fetchSourceTypes().subscribe( (res: Response)  => {
        this.data = res;
        this.mainData = res;
        console.log(this.data);
        console.log(this.data.sourceTypeFilterDTOs);
        this.sourceTypes = this.data.sourceTypeFilterDTOs;
        this.sourceMetadata = this.data.sourceMetadataDTO;
        console.log(this.sourceTypes);
        console.log(this.sourceMetadata);

        for (let c = 0 ; c < this.sourceMetadata.length ; c++) {
          this.arrowState[c] = 'assets/images/headerryt.png';
          this.panelState[c] = false;
        }
        for (let c = 0 ; c < this.sourceTypes.length ; c++) {
         for (let b = 0 ; b < this.sourceTypes[c].sourceFilterNameDTO.length ; b++) {
              this.sourceNames.push(this.sourceTypes[c].sourceFilterNameDTO[b]);
         }
        }
        console.log(this.sourceMetadata);
      });
  }

  public changeArrow(MainId) {
    this.panelState[MainId] = !this.panelState[MainId];
    if (this.arrowState[MainId] === 'assets/images/headerryt.png') {
       this.arrowState[MainId] = 'assets/images/headerdwn.png';
    } else {
      this.arrowState[MainId] = 'assets/images/headerryt.png';
    }
  }

 /* public sourceNameDropDown(): void {
    if (this.sourceNameSelected === false) {
      this.sourceNameShowOptions = true;
      this.sourceNameSelected = true;
    } else {
      this.sourceNameShowOptions = false;
      this.sourceNameSelected = false;
    }
  }*/

 /* public sourceTypeDrp(): void {
    if (this.sourceTypeSelected === false) {
      this.sourceTypeShowOptions = true;
      this.sourceTypeSelected = true;
    } else {
      this.sourceTypeShowOptions = false;
      this.sourceTypeSelected = false;
    }
  }*/

  public clear() {
    this.default = {
      color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
    };
    this.searchSource = null;
   // this.sourceNameShowOptions = false;
    this.sourceNameSelected = false;
   // this.sourceTypeShowOptions = false;
    this.sourceTypeSelected = false;
    this.searchObject = {};
  //  this.searchObject.sourceType = null;
   // this.sourceTypes = this.mainData.sourceTypeFilterDTOs;
  //  this.searchObject.sourceNames = null;
    this.filterStudies('all');
    this.selected = {
      color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
    };
   // this.filterStudies('all');
  }

  public filterStudies(sourceType: any) {
    console.log(sourceType);
    this.selected = {
      color: '#3B3838',
      border: '1px solid #A5A5A5',
      fontsize: '11px'
    } ;
    if (sourceType === 'undefined') {
      // do nothing
    } else if (sourceType === 'all') {
      // do for all
      this.default = {
        color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
      };
        this.sourcename = 'undefined';
        this.editService.fetchSourceTypes().subscribe( (res: Response)  => {
        this.data = res;
        this.sourceTypes = this.data.sourceTypeFilterDTOs;
        this.sourceMetadata = this.data.sourceMetadataDTO;
        this.sourceNames = [];
        for (let c = 0 ; c < this.sourceMetadata.length ; c++) {
          this.arrowState[c] = 'assets/images/headerryt.png';
          this.panelState[c] = false;
        }
        for (let c = 0 ; c < this.sourceTypes.length ; c++) {
          for (let b = 0 ; b < this.sourceTypes[c].sourceFilterNameDTO.length ; b++) {
               this.sourceNames.push(this.sourceTypes[c].sourceFilterNameDTO[b]);
          }
         }
       });
    } else {
      this.default = {
        color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
      };
      const idx = this.sourceTypes.findIndex(record => record.sourceType[0] === sourceType);
      this.sourcename = 'undefined';
      console.log(idx);
      console.log(this.sourceTypes[idx].sourceFilterNameDTO);
      this.sourceNames = Object.assign([], this.sourceTypes[idx].sourceFilterNameDTO);
      console.log(this.sourceNames);
      console.log(this.searchObject.sourceName);
    }
  }

  public filterSourceMetadata(searchObject) {
    this.default = {
      color: '#3B3838',
      border: '1px solid #A5A5A5',
      fontsize: '11px'
    };
    console.log(searchObject);
    console.log(searchObject.sourceType);
    console.log(searchObject.sourceName);
    console.log(this.sourcename);
    this.srctypes = [];
    for (let c = 0 ; c < this.sourceTypes.length ; c++) {
      for (let b = 0 ; b < this.sourceTypes[c].sourceFilterNameDTO.length ; b++) {
           if (this.sourcename === this.sourceTypes[c].sourceFilterNameDTO[b].sourceName) {
             this.srctypes.push(this.sourceTypes[c].sourceType[0]);
           }
      }
     }

     console.log(this.srctypes.length);
     console.log(searchObject.sourceType);
    if (searchObject.sourceType !== undefined && searchObject.sourceType !== 'all' ) {
     this.searchSource = {
        sourceType: [searchObject.sourceType],
        sourceFilterNameDTO: [
         {
          sourceName : this.sourcename,
         }
         ]
     };
    console.log(this.searchSource);

    this.editService.getSourceMetadata(this.searchSource).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      this.sourceMetadata = this.data.sourceMetadataDTO;
      console.log(this.sourceMetadata);
      for (let c = 0 ; c < this.sourceMetadata.length ; c++) {
        this.arrowState[c] = 'assets/images/headerdwn.png';
        this.panelState[c] = true;
      }

    });
  } else  {
    this.searchSource = {
       sourceType: this.srctypes,
       sourceFilterNameDTO: [
        {
         sourceName : this.sourcename,
        }
        ]
    };
   console.log(this.searchSource);

   this.editService.getSourceMetadata(this.searchSource).subscribe((res: Response) => {
     console.log(res);
     this.data = res;
     this.sourceMetadata = this.data.sourceMetadataDTO;
     console.log(this.sourceMetadata);
     for (let c = 0 ; c < this.sourceMetadata.length ; c++) {
       this.arrowState[c] = 'assets/images/headerdwn.png';
       this.panelState[c] = true;
     }

   });
 }
}

}

