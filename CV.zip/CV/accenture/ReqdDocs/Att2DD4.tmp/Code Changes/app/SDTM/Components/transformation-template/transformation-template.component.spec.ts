import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransformationTemplateComponent } from './transformation-template.component';

describe('TransformationTemplateComponent', () => {
  let component: TransformationTemplateComponent;
  let fixture: ComponentFixture<TransformationTemplateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransformationTemplateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransformationTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
