import { Component, OnInit, Inject } from '@angular/core';
import { UserService, EditService } from '../../Services';
import { Router, ActivatedRoute } from '@angular/router';
import { TransformationTemplate } from '../../Models/transformationtemplate';

@Component({
  selector: 'app-transformation-template',
  templateUrl: './transformation-template.component.html',
  styleUrls: ['./transformation-template.component.css']
})
export class TransformationTemplateComponent implements OnInit {

  paramId: string;
  public thereuticArea = 'undefined';
  public study = 'undefined';
  public domain = 'undefined';
  public version = 'undefined';
  public template = 'undefined';
  public searchStudy: any = {};
  therapeuticAreaDrpSelected = false;
  therapeuticAreasShowOptions = false;
  studySourceDrpSelected = false;
  studySourceShowOptions = false;
  templateNameDrpSelected = false;
  templateNameShowOptions = false;
  sdtmVersionDrpSelected = false;
  sdtmVersionShowOptions = false;
  domainDrpSelected = false;
  domainShowOptions = false;
  public appliedfilters: TransformationTemplate = {
    'therapeuticAreas': [],
    'studySources': [],
    'templateNames': [],
    'domainNames': [],
   'versions':  []
  };
  public filters;
  private editService: EditService;
  public transformationTemplate;
  public sdtmTargetMetadata;
  public arrowState = [];
  public panelState = [];
  public arrowState1 = [];
  public panelState1 = [];
  public arrowState2 = [];
  public panelState2 = [];
  public arrowState3 = [];
  public panelState3 = [];
  public therapeuticselect = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
  };
  public sourceselect = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
  };
  public templateselect = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
  };
  public versionselect = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
  };
  public domainselect = {
    color: '#7C7C7C',
    border: '1px solid #C9C9C9',
    fontsize: '11px'
  };
  navBarItems: Object[];
  public data;
  configTypeIcons: Object[];
  public headerCells: any = {
    background: '#DEEBF7',
    fontWeight: 'Bold',
    fontFamily: 'Open Sans',
    color: '#000000'
  };
  public subheaderCells: any = {
    fontWeight: 'Bold',
    fontFamily: 'Open Sans',
    color: '#000000'
  };
  constructor(private userService: UserService,
    private router: Router,
    private route: ActivatedRoute, @Inject(EditService) editServiceFactory: any) {
      this.editService = editServiceFactory();
    }

  ngOnInit() {
    console.log(this.appliedfilters);
    this.editService.getTransformationtempalte(this.appliedfilters).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      console.log(this.data.taTransformationTemplateDTOs);
      this.transformationTemplate = this.data.taTransformationTemplateDTOs;
      this.filters = this.data.transformationTemplateFilterParams;
      console.log(this.filters);
      console.log(this.transformationTemplate);
    //  this.sourceMetadata = this.data.sourceMetadataDTO;
    //  console.log(this.sourceMetadata);
    this.closediv();

    });
    this.navBarItems = [
      { "navBarTitle": "Directory", "navBarLink": "/sdtm/metadata" },
      { "navBarTitle": "Source Metadata", "navBarLink": "/sdtm/metadata/sourcemetadata" },
      { "navBarTitle": "SDTM Target Metadata", "navBarLink": "/sdtm/metadata/sdtmmetadata" },
      { "navBarTitle": "Transformation Template", "navBarLink": "/sdtm/metadata/transformation" }


    ];
    this.configTypeIcons = [
      { 'icontitle': 'Upload', 'iconImageSrc': 'assets/images/NewNote.png', 'action': 'upload',  'inputParam': '' },
      { 'icontitle': 'Download', 'iconImageSrc': 'assets/images/studyDownload.png', 'action': 'download', 'inputParam': '' },
      ];
console.log(this.transformationTemplate.length);
}

public closediv() {
  for (let c = 0 ; c < this.transformationTemplate.length ; c++) {
    this.arrowState1[c] = 'assets/images/headerryt.png';
    this.panelState1[c] = false;
    const arr1 = [];
    const arr2 = [];
    for (let d = 0 ;  d < this.transformationTemplate[c].templateNmTransformationTemplateDTOs.length; d++) {
      arr1[d] =  'assets/images/subsubheaderryt.png';
      arr2[d] = false;
      const arr3 = [];
      const arr4 = [];
      // tslint:disable-next-line:max-line-length
      for (let e = 0 ;  e < this.transformationTemplate[c].templateNmTransformationTemplateDTOs[d].versionTransformationTemplateDTO.length; e++) {
        arr3[e] = 'assets/images/subheaderryt.png';
        arr4[e] = false;
      }
      this.arrowState[d] = Object.assign([], arr3);
      this.panelState[d] = Object.assign([], arr4);
    }
    this.arrowState2[c] = Object.assign([], arr1);
    this.panelState2[c] = Object.assign([], arr2);
    this.arrowState3[c] = Object.assign([], this.arrowState);
    this.panelState3[c] = Object.assign([], this.panelState);
  }
}

  public changeArrow(rowId1, rowId2 , rowId3,  selectedDiv) {
  //  console.log(rowId1 + ' ' + rowId2 + ' ' + rowId3 + ' ' + selectedDiv);
    if (selectedDiv === 'div1') {
      this.panelState1[rowId1] = !this.panelState1[rowId1];
      if (this.arrowState1[rowId1] === 'assets/images/headerryt.png') {
        this.arrowState1[rowId1] = 'assets/images/headerdwn.png';
      } else {
       this.arrowState1[rowId1] = 'assets/images/headerryt.png';
       for (let d = 0 ;  d < this.transformationTemplate[rowId1].templateNmTransformationTemplateDTOs.length; d++) {
        // tslint:disable-next-line:max-line-length
        for (let e = 0 ;  e < this.transformationTemplate[rowId1].templateNmTransformationTemplateDTOs[d].versionTransformationTemplateDTO.length; e++) {
          this.arrowState3[rowId1][d][e] = 'assets/images/subsubheaderryt.png';
          this.panelState3[rowId1][d][e] = false;
        }
        this.arrowState2[rowId1][d] = 'assets/images/subheaderryt.png';
        this.panelState2[rowId1][d] = false;
      }
      }
    } else if ( selectedDiv === 'div2') {
      this.panelState2[rowId1][rowId2] = !this.panelState2[rowId1][rowId2];
      if (this.arrowState2[rowId1][rowId2] === 'assets/images/subsubheaderryt.png') {
        this.arrowState2[rowId1][rowId2] = 'assets/images/subsubheaderdwn.png';
      } else {
       this.arrowState2[rowId1][rowId2] = 'assets/images/subsubheaderryt.png';
       // tslint:disable-next-line:max-line-length
       for (let e = 0 ;  e < this.transformationTemplate[rowId1].templateNmTransformationTemplateDTOs[rowId2].versionTransformationTemplateDTO.length; e++) {
        this.arrowState3[rowId1][rowId2][e] = 'assets/images/subheaderrytt.png';
        this.panelState3[rowId1][rowId2][e] = false;
      }
      }
     } else if (selectedDiv === 'div3') {
      this.panelState3[rowId1][rowId2][rowId3] = !this.panelState3[rowId1][rowId2][rowId3];
      if (this.arrowState3[rowId1][rowId2][rowId3] === 'assets/images/subheaderryt.png') {
        this.arrowState3[rowId1][rowId2][rowId3] = 'assets/images/subheaderdwn.png';
      } else {
       this.arrowState3[rowId1][rowId2][rowId3] = 'assets/images/subheaderryt.png';
      }
    }
  }

/*  public domainDrp(): void {
    if (this.domainDrpSelected === false) {
      this.domainShowOptions = true;
      this.domainDrpSelected = true;
    } else {
      this.domainShowOptions = false;
      this.domainDrpSelected = false;
    }
  }

  public sdtmVersionDrp(): void {
    if (this.sdtmVersionDrpSelected === false) {
      this.sdtmVersionShowOptions = true;
      this.sdtmVersionDrpSelected = true;
    } else {
      this.sdtmVersionShowOptions = false;
      this.sdtmVersionDrpSelected = false;
    }
  }

  public templateNameDrp(): void {
    if (this.templateNameDrpSelected === false) {
      this.templateNameShowOptions = true;
      this.templateNameDrpSelected = true;
    } else {
      this.templateNameShowOptions = false;
    this.templateNameDrpSelected = false;
    }
  }

  public studySourceDrp(): void {
    if (this.studySourceDrpSelected === false) {
      this.studySourceShowOptions = true;
      this.studySourceDrpSelected = true;
    } else {
      this.studySourceShowOptions = false;
      this.studySourceDrpSelected = false;
    }
  }

  public therapeuticAreaDrp(): void {
    if (this.therapeuticAreaDrpSelected === false) {
      this.therapeuticAreasShowOptions = true;
      this.therapeuticAreaDrpSelected = true;
    } else {
      this.therapeuticAreasShowOptions = false;
      this.therapeuticAreaDrpSelected = false;
    }
  }*/

  public filterByTa(ta: any) {
    this.therapeuticselect = {
      color: '#3B3838',
      border: '1px solid #A5A5A5',
      fontsize: '11px'
    };
    console.log(ta);
    if (ta === 'all') {
      this.appliedfilters.therapeuticAreas = [];
    } else {
    this.appliedfilters.therapeuticAreas = [ta];
    }
    console.log(this.appliedfilters);
    this.editService.getTransformationtempalte(this.appliedfilters).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      console.log(this.data.taTransformationTemplateDTOs);
      this.transformationTemplate = this.data.taTransformationTemplateDTOs;
      console.log(this.transformationTemplate);
    });
  }
  public filterByStudy(study: any) {
    this.sourceselect = {
      color: '#3B3838',
      border: '1px solid #A5A5A5',
      fontsize: '11px'
    };
    console.log(study);
    if (study === 'all') {
      this.appliedfilters.studySources = [];
    } else {
    this.appliedfilters.studySources = [study];
    }
    console.log(this.appliedfilters);
    this.editService.getTransformationtempalte(this.appliedfilters).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      console.log(this.data.taTransformationTemplateDTOs);
      this.transformationTemplate = this.data.taTransformationTemplateDTOs;
      console.log(this.transformationTemplate);
    });
  }
  public filterByTemplate(template: any) {
    this.templateselect = {
      color: '#3B3838',
      border: '1px solid #A5A5A5',
      fontsize: '11px'
    };
    console.log(template);
    if (template === 'all') {
      this.appliedfilters.templateNames = [];
    } else {
    this.appliedfilters.templateNames = [template];
    }
    console.log(this.appliedfilters);
    this.editService.getTransformationtempalte(this.appliedfilters).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      console.log(this.data.taTransformationTemplateDTOs);
      this.transformationTemplate = this.data.taTransformationTemplateDTOs;
      console.log(this.transformationTemplate);
      for (let c = 0 ; c < this.transformationTemplate.length ; c++) {
        this.arrowState1[c] = 'assets/images/headerdwn.png';
        this.panelState1[c] = true;
      }
    });
  }
  public filterByVersion(version: any) {
    this.versionselect = {
      color: '#3B3838',
      border: '1px solid #A5A5A5',
      fontsize: '11px'
    };
    console.log(version);
    if (version === 'all') {
      this.appliedfilters.versions = [];
    } else {
    this.appliedfilters.versions = [version];
    }
    console.log(this.appliedfilters);
    this.editService.getTransformationtempalte(this.appliedfilters).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      console.log(this.data.taTransformationTemplateDTOs);
      this.transformationTemplate = this.data.taTransformationTemplateDTOs;
      console.log(this.transformationTemplate);
      for (let c = 0 ; c < this.transformationTemplate.length ; c++) {
        this.arrowState1[c] = 'assets/images/headerdwn.png';
        this.panelState1[c] = true;
        const arr1 = [];
        const arr2 = [];
        for (let d = 0 ;  d < this.transformationTemplate[c].templateNmTransformationTemplateDTOs.length; d++) {
          arr1[d] =  'assets/images/subsubheaderdwn.png';
          arr2[d] = true;
          const arr3 = [];
          const arr4 = [];
        }
        this.arrowState2[c] = Object.assign([], arr1);
        this.panelState2[c] = Object.assign([], arr2);
      }
    });
  }
  public filterByDomain(domain: any) {
    this.domainselect = {
      color: '#3B3838',
      border: '1px solid #A5A5A5',
      fontsize: '11px'
    };
    console.log(domain);
    if (domain === 'all') {
      this.appliedfilters.domainNames = [];
    } else {
    this.appliedfilters.domainNames = [domain];
    }
    console.log(this.appliedfilters);
    this.editService.getTransformationtempalte(this.appliedfilters).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      console.log(this.data.taTransformationTemplateDTOs);
      this.transformationTemplate = this.data.taTransformationTemplateDTOs;
      console.log(this.transformationTemplate);
      for (let c = 0 ; c < this.transformationTemplate.length ; c++) {
        this.arrowState1[c] = 'assets/images/headerdwn.png';
        this.panelState1[c] = true;
        const arr1 = [];
        const arr2 = [];
        for (let d = 0 ;  d < this.transformationTemplate[c].templateNmTransformationTemplateDTOs.length; d++) {
          arr1[d] =  'assets/images/subsubheaderdwn.png';
          arr2[d] = true;
          const arr3 = [];
          const arr4 = [];
          // tslint:disable-next-line:max-line-length
          for (let e = 0 ;  e < this.transformationTemplate[c].templateNmTransformationTemplateDTOs[d].versionTransformationTemplateDTO.length; e++) {
            arr3[e] = 'assets/images/subheaderdwn.png';
            arr4[e] = true;
          }
          this.arrowState[d] = Object.assign([], arr3);
          this.panelState[d] = Object.assign([], arr4);
        }
        this.arrowState2[c] = Object.assign([], arr1);
        this.panelState2[c] = Object.assign([], arr2);
        this.arrowState3[c] = Object.assign([], this.arrowState);
        this.panelState3[c] = Object.assign([], this.panelState);
      }
    });
  }

  public clear() {
    this.appliedfilters.templateNames = [];
    this.appliedfilters.studySources = [];
    this.appliedfilters.domainNames = [];
    this.appliedfilters.versions = [];
    this.appliedfilters .therapeuticAreas = [];
    this.version = 'undefined';
    this.thereuticArea = 'undefined';
    this.study = 'undefined';
    this.template = 'undefined';
    this.domain = 'undefined';
    this.editService.getTransformationtempalte(this.appliedfilters).subscribe((res: Response) => {
      console.log(res);
      this.data = res;
      console.log(this.data.taTransformationTemplateDTOs);
      this.transformationTemplate = this.data.taTransformationTemplateDTOs;
      console.log(this.transformationTemplate);
    });
   this.closediv();
    this.therapeuticselect = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9',
      fontsize: '11px'
    };
    this.sourceselect = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9',
      fontsize: '11px'
    };
   this.templateselect = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9',
      fontsize: '11px'
    };
    this.versionselect = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9',
      fontsize: '11px'
    };
    this.domainselect = {
      color: '#7C7C7C',
      border: '1px solid #C9C9C9',
      fontsize: '11px'
    };
   // this.filterStudies('all');
   // this.editService.read('onLoad');
  }

}
