import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { EditService } from '../../Services';
import { HttpResponse, HttpEventType , HttpErrorResponse, HttpInterceptor,
  HttpRequest,  HttpHandler,  HttpEvent } from '@angular/common/http';
import { map, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';


@Component({
  selector: 'app-upload-data',
  templateUrl: './upload-data.component.html',
  styleUrls: ['./upload-data.component.css']
})
export class UploadDataComponent implements OnInit {

  private editService: EditService;
  public active = false;
  public opened = false;
  public errorMsg: string;
  public heading: any;
  public msg: string;
  public checkError = false;
  public upactive: boolean;
  public downactive: boolean;
  public currentFileUpload: File;
  public selectedFiles: FileList;

  @Input() public popupType;
  @Input() public set type(title) {
    this.heading = title;
    this.active = title !== undefined  && this.popupType === 'upload';
    console.log(this.active);
  }
  @Output() cancel: EventEmitter<any> = new EventEmitter();

  constructor(@Inject(EditService) editServiceFactory: any) {
    this.editService = editServiceFactory();
  }
  public close() {
    this.opened = false;
    this.msg = '';
    this.checkError = false;
  }

  public onCancel(e): void {
    e.preventDefault();
    this.closeForm();
    this.msg = '';
    this.checkError = false;
  }

  private closeForm(): void {
    this.errorMsg = '';
    this.active = false;
    this.cancel.emit();
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  public onUpload(): void {
    console.log('in upload func');
    this.currentFileUpload = this.selectedFiles.item(0);
    this.msg = 'Upload in progress';
    this.upactive = false;
    this.downactive = true;
    console.log(this.currentFileUpload);
    console.log(this.active);
    console.log(this.popupType);
    if (this.heading === 'Source MetaData') {
      this.editService.uploadFile(this.currentFileUpload).subscribe((result) => {
      console.log('Upload Response');
      console.log(result);
     // debugger;
     if (result !== null && result.body !== null && result.body !== undefined) {
      console.log(result.body.message);
      this.msg = result.body.message;
      this.checkError = true;
      this.upactive = true;
      this.downactive = false ;
      } else if (result !== null && result.body === null) {
        this.msg = 'Upload Successfull';
        this.upactive = true;
        this.downactive = false ;
        this.checkError = false;
        console.log('nooo');
      }
      });
    } else if ( this.heading === 'SDTM Target MetaData' ) {
        this.editService.uploadTargetFile(this.currentFileUpload).subscribe((result) => {
        console.log('Upload Response');
        console.log(result);
        if (result !== null && result.body !== null && result.body !== undefined) {
          this.msg = result.body.message;
          this.upactive = true;
          this.downactive = false ;
          this.checkError = true;
          console.log(result.body.message);
        } else if (result !== null && result.body === null) {
          this.msg = 'Upload Successfull';
          this.upactive = true;
          this.downactive = false ;
          this.checkError = false;
          console.log('nooo');
        }
        });
    }
this.checkError = false;
   // this.msg = '';
  }

  ngOnInit() {
    this.msg = '';
    this.upactive = true;
    this.downactive = false;
    this.checkError = false;
  }

}
