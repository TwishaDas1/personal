export class ConfigIcons {
    public icontitle: string;
    public iconImageSrc: string
    public action: string;
    public inputParam: any;
}

