export class LookupTable {

	public  formName: string;
	public formDescription: string;
	public formId: string;
	public fieldName: string;
	public fieldDesc: string;
}
