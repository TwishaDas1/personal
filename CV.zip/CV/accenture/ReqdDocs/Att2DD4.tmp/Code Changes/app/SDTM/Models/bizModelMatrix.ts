import { StudyDetails } from "./model";

export class Matrix {
    public sourceFile: string;
    public sourceField: string;
    public joinLogic: string;
    public target_File: string;
    public target_Field: string;
    public domain: string;
    public importDomain: string[];
    public subDomain: string;
    public studyTitle: string;
      public study: string;
      public templateStudyTitles: any[];

    public studyVersion: string;
    public action: string;

    public matrixStudy: string;
    public transformation_type: string;
    public transformation_logic: string;
    public back_transformation_logic: string;
    public id: number;
    public defaultMessage: string;
    public formName: string;
    public formLable: string;
    public domainStatus: string;
    public notes: string;
    public ruleFlag: string;
    public customCode: string;
    public dateForComputation: string;
    public operation: string;
    public concatLogic: string;
    public sourceFilePlus: string;
    public formNamePlus: string;
    public sourceFile1: string;
    public formName1: string;
    public sourceFile2: string;
    public formName2: string;
    public sourceFile3: string;
    public formName3: string;
    public sourceFile4: string;
    public formName4: string;
    public sourceFile5: string;
    public formName5: string;
    public sourceFieldPlus: string;
    public sourceField1: string;
    public sourceField2: string;
    public sourceField3: string;
    public sourceField4: string;
    public sourceField5: string;
    public addVar: string;
    public userRole: string;
}
