export class Template {
    public target_File: string;
    public target_field: string;
    public domain: string;
    public id: number; 
}
