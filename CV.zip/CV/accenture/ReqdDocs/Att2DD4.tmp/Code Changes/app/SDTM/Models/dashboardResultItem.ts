 export class DashboardResultItem {
 
  studyID: string;
  countOfAllDomains: number;
  pieData: any[]=[];
  pieDataTwo: any[]=[];
  jobExecutionDomainDetails: any[]=[];
  notifications: any[]=[];
  
}