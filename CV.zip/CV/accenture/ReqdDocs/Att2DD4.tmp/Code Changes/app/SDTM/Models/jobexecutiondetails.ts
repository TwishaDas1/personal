export class JobExecutionDetails {

    public domain: string;
    public job_end_timestamp: string;
    public job_status: string;
    public message: string;
    public jobDisabled: string;
    public isLive: boolean;
    public isJobAborted: boolean;
    public study: string;
    public job_id: number;
    public domainCode: string;
    public domainStatus: string;
    public version: string;
    public baseline: string;

}
