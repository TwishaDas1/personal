export class StudyDetails {
    public studyID: string;
    public title: string;
    public phase: string;
    public status: string;
    public therapeuticArea: string;
    public source: string;
    public analyst: string;
    public manager: string;
    public dbLockDate: Date;
    public studyVersion: string;
    public isVersionChanged: boolean;
}

export class SourceMetaData {
    public sourceType: any;
    public sourceFilterNameDTO: any;
}

export class SdtmTargetMetaData {
    public version: any;
    public domainDTO: any;
}

export class DomainCategories {
    public inProgress: string [];
    public readyForReview: string [];
    public rejected: string [];
    public approved: string [];
    public notStarted: string [];
}
