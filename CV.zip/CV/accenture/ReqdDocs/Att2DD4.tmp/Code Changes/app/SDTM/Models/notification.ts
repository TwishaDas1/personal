export class NotificationItem {
	id: number;
    studyID: string;
    notification_desc: string;
    create_dt: string;
    notification_delete: string;
    notification_stop: string;
    task_desc: string;
    task_due_date: string;
    task_complete:string;
    
    removeRedFlag:boolean;
    removeStopWatch:boolean;
    
}