export class TransformationTemplate {
    public therapeuticAreas: Array<string>;
    public studySources: Array<string>;
    public templateNames: Array<string>;
    public versions: Array<string>;
    public domainNames: Array<string>;

}
