import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Headers, RequestOptions } from '@angular/http';
import { tap } from 'rxjs/operators/tap';
import { map } from 'rxjs/operators/map';
import { Subject } from 'rxjs';

const CREATE_ACTION = 'create';
const UPDATE_ACTION = 'update';
const REMOVE_ACTION = 'delete';
const IMPORT_ACTION = 'import';
const STATUS_ACTION = 'status';
const FLAG_ACTION = 'flag';

@Injectable()
export class BusinessEditService extends BehaviorSubject<any[]> {

    public fetchDomainStatuses(): any {
        return this.http.get<any[]>(`/api/CDR/domain/statuses`);
    }
    constructor(private http: HttpClient) {
        super([]);
    }

    private data: any[] = [];
    public searchBRStudy: any = {};
    private res: any[] = [];

    public read(searchBRStudy) {
        this.fetch(searchBRStudy)
            .pipe(
                tap(data => {
                    this.data = data;
                })
            )
            .subscribe(data => {
                super.next(data);
            });
    }

    public getBusinessRulesByStudyAndDomain(searchBRStudy) {
        return this.http.get<any[]>(`/api/CDR/getBusinessRules/${searchBRStudy.brStudy}/${searchBRStudy.brVersion}/${searchBRStudy.brSdtmDomain}/${searchBRStudy.brBaseline}`);
    }


    public getBusinessRuleByVersion(searchBRStudy) {
        return this.http.get<any[]>(`/api/CDR/getBusinessRulesByVersion/${searchBRStudy.brStudy}/${searchBRStudy.brVersion}`);

    }

    public fetchStudyTitles() {
        return this.http.get<any[]>(`/api/CDR/study/dropdown`);
    }
    public getStudyTitlesByVersion(version: any) {
        return this.http.get<any[]>(`/api/CDR/matrix/importStudy/${version}`);
    }
    public fetchDomainsByStudy(study: any) {
        return this.http.get<any[]>(`/api/CDR/busRules/domains/${study}`);
    }

    public fetchTransformationTypes() {
        return this.http.get<any[]>(`/api/CDR/matrix/transformations`);
    }

    public fetchLookUpData() {
        return this.http.get<any[]>(`/api/CDR/lookup/sourceForms`);
    }

    public fetchLookUpVariables(formName) {
        return this.http.get<any[]>(`/api/CDR/lookup/sourceVariables/${formName}`);
    }

    public fetchSDTMVariables() {
        return this.http.get<any[]>(`/api/CDR/matrix/targetVariables`);
    }

    public fetchTherapeuticAreas() {
        return this.http.get<any[]>(`/api/CDR/matrix/therapeutics`);
    }

    public fetchStudyMatrixDomains() {
        return this.http.get<any[]>(`/api/CDR/studyMatrix/domains`);
    }

    public kendoDataFetch(study: any, domain: any) {
        return this.http.get<any[]>(`/api/CDR/ObjectMatrices/${study}/${domain}`);
    }

    public fetchStudiessBytherapeuticArea(therapeuticArea: any) {
        let params = new HttpParams();
        params = params.set('therapeuticArea', therapeuticArea);
        return this.http.get<any[]>(`/api/CDR/study/ByTherapeuticArea`, { params: params });
    }

    public save(data: any, searchBRStudy, isNew?: any) {
        let action = '';
        if (isNew === 'add') {
            action = CREATE_ACTION;
        } else if (isNew === 'edit') {
            action = UPDATE_ACTION;
        } else if (isNew === 'import') {
            action = IMPORT_ACTION;
        }
        this.reset();
        this.fetch(data, action)
            .subscribe(() => this.read(searchBRStudy), () => this.read(searchBRStudy));
    }

    public remove(data: any, searchBRStudy) {
        this.reset();
        this.fetch(data, REMOVE_ACTION)
            .subscribe(() => this.read(searchBRStudy), () => this.read(searchBRStudy));
    }

    private reset() {
        this.data = [];
    }

    private fetch(searchBRStudy, action: string = '', data?: any): Observable<any> {
        let params = new HttpParams();
        if (action === 'create') {
            const searchUrl = '/api/CDR/matrix/create';
            const url = `${searchUrl}`;
            let headers = new HttpHeaders();
            headers.append('Content-Type', 'application/json');
            return this.http.post(url, searchBRStudy, { headers: headers });
        } else if (action === 'update') {
            const updateUrl = '/api/CDR/matrix/update';
            const url = `${updateUrl}/${searchBRStudy.id}`;
            const body = JSON.stringify(searchBRStudy);
            const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
            return this.http.put(url, searchBRStudy, { headers: headers });
        } else if (action === 'delete') {
            const deleteUrl = '/api/CDR/matrix/delete';
            const url = `${deleteUrl}/${searchBRStudy.id}`;
            const body = JSON.stringify(searchBRStudy);
            const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
            return this.http.delete(url, searchBRStudy);
        } else if (searchBRStudy === 'clear') {
            params = params.set('StudId', 'xxx');
            return this.http.get<any[]>(`/api/CDR/matrix/search`, { params: params })
                .pipe(map(res => <any[]>res));
        } else if (action === 'import') {
            const importUrl = '/api/CDR/matrix/fetchOrInsert';
            return this.http.get<any[]>(`${importUrl}/${searchBRStudy.study.title}/${searchBRStudy.matrixStudy}/${searchBRStudy.domain}`)
                .pipe(map(res => <any[]>res));
        } else if (action === 'status') {
            const updateUrl = '/api/CDR/matrix/updateDomainStatus';
            const url = `${updateUrl}/${searchBRStudy.study}/${searchBRStudy.domain}/${searchBRStudy.domainStatus}/`;
            const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
            return this.http.put(url, searchBRStudy, { headers: headers })
                .pipe(map(res => <any[]>res));
        } else if (action === 'flag') {
            const updateUrl = '/api/CDR/matrix/updateRuleFlag';
            const url = `${updateUrl}/${searchBRStudy.id}/${searchBRStudy.ruleFlag}`;
            const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
            return this.http.put(url, searchBRStudy, { headers: headers })
                .pipe(map(res => <any[]>res));
        } else {

            return this.http.get<any[]>(`/api/CDR/getBusinessRules/${searchBRStudy.brStudy}/${searchBRStudy.brVersion}/${searchBRStudy.brSdtmDomain}/${searchBRStudy.brBaseline}`)
                .pipe(map(res => <any[]>res));
        }
    }

    public importBusinessRules(searchBRStudy: any) {
        //const importUrl = '/api/CDR/matrix/fetchOrInsert';
        return this.http.get<any[]>(`/api/CDR/matrix/fetchOrInsert/${searchBRStudy.brStudy}/${searchBRStudy.matrixStudy}/${searchBRStudy.domains}/${searchBRStudy.brVersion}`);

    }

    public updateDomainStatus(data: any, searchBRStudy) {
        this.fetch(data, STATUS_ACTION)
            .subscribe(() => this.read(searchBRStudy), () => this.read(searchBRStudy));
    }

    public domainStatusUpdate(searchBRStudy) {

        const url = `/api/CDR/matrix/updateDomainStatus/${searchBRStudy.brStudy}/${searchBRStudy.brSdtmDomain}/${searchBRStudy.brdomainStatus}/${searchBRStudy.brVersion}/${searchBRStudy.brBaseline}`;
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        return this.http.put<any[]>(url, searchBRStudy, { headers: headers });
    }


    public updateBusinessRuleFlag(data: any, searchBRStudy) {
        this.fetch(data, FLAG_ACTION)
            .subscribe(() => this.read(searchBRStudy), () => this.read(searchBRStudy));
    }

    public updateNotes(data, selectedRules, isAllRulesSelected, searchBRStudy) {
        let params = new HttpParams();
        if (data.study) {
            params = params.set('study', data.study);
        }
        if (data.domain) {
            params = params.set('domain', data.domain);
        }
        if (selectedRules) {
            params = params.set('selectedRules', selectedRules);
        }
        if (isAllRulesSelected) {
            params = params.set('isAllRulesSelected', isAllRulesSelected);
        }
        if (data.notes) {
            params = params.set('notes', data.notes);
        }
        const updateUrl = '/api/CDR/matrix/updateNotesForRules';
        const url = `${updateUrl}`;
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        return this.http.put(url, searchBRStudy, { params: params })
            .pipe(map(res => <any[]>res))
            .subscribe(() => this.read(searchBRStudy), () => this.read(searchBRStudy));
    }

    public updateFlags(data, selectedRules, isAllRulesSelected, searchBRStudy) {
        let params = new HttpParams();
        if (data.study) {
            params = params.set('study', data.study);
        }
        if (data.domain) {
            params = params.set('domain', data.domain);
        }
        if (selectedRules) {
            params = params.set('selectedRules', selectedRules);
        }
        if (isAllRulesSelected) {
            params = params.set('isAllRulesSelected', isAllRulesSelected);
        }
        if (data.notes) {
            params = params.set('notes', data.notes);
        }
        const updateUrl = '/api/CDR/matrix/updateFlagsForRules';
        const url = `${updateUrl}`;
        const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        return this.http.put(url, searchBRStudy, { params: params })
            .pipe(map(res => <any[]>res))
            .subscribe(() => this.read(searchBRStudy), () => this.read(searchBRStudy));
    }


    public getFilteredVersions(searchBRStudy: any) {
        return this.http.get<any[]>(`/api/CDR/brMatrix/getVersions/${searchBRStudy.brStudy}`);
    }

    public getFilteredDomains(searchBRStudy: any) {
        return this.http.get<any>(`/api/CDR/brMatrix/getDomains/${searchBRStudy.brStudy}/${searchBRStudy.brVersion}`);
    }

    public getFilteredBaselines(searchBRStudy: any) {
        return this.http.get<any[]>(`/api/CDR/brMatrix/getBaselines/${searchBRStudy.brStudy}/${searchBRStudy.brVersion}/${searchBRStudy.brSdtmDomain}`);
    }


    public deleteWorkingCopyBR(searchBRStudy: any) {
        let headers = new HttpHeaders();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`/api/CDR/brMatrix/deleteWorkingCopyBR`, searchBRStudy, { headers: headers });
    }
}
