import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class JobexecutionService {

  constructor(private http: HttpClient) { }


  public runSingleJob(item: any, action: any) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');

    //return this.http.post(`http://10.0.1.198/?study_name=${item.study}&domain_array=${item.domainCode}&version=${item.version}&baseline=${item.baseline}&action=${action}`, { headers: headers });

    //return this.http.post(`http://10.0.2.156?Study_name=${item.study}&domain_array=${item.domainCode}&Action=${action}`, { headers: headers });
    return this.http.post(`http://172.16.22.48/?study_name=${item.study}&domain_array=${item.domainCode}&version=${item.version}&baseline=${item.baseline}&action=${action}`, { headers: headers });
  }

  public runMultipleJobs(study: any, selectedItems: any) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');

    return this.http.post(`http://172.16.22.48?Study_name=${study}&domain_array=${selectedItems}&Action=Run`, { headers: headers });

  }

  public searchJobsForStudy(study: any) {
    return this.http.get<any[]>(`/api/CDR/jobsForStudy/${study}`);

  }


}