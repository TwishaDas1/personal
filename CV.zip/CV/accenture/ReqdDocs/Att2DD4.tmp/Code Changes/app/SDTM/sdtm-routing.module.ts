import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { JobExecutionComponent } from './Components/job-execution/job-execution.component';
import { BusinessRuleConfigComponent } from './Components/business-rule-config/business-rule-config.component';
import { StudySetupComponent } from './Components/study-setup/study-setup.component';
import { SdtmHomeComponent } from './Components/sdtm-home/sdtm-home.component';
import { SharedModule } from '../Shared/shared.module';
import { MetadataManagementComponent } from '../SDTM/Components/metadata-management/metadata-management.component';
import { DirectoryComponent } from './Components/directory/directory.component';
import { SourceMetadataComponent } from './Components/source-metadata/source-metadata.component';
import { SdtmTargetMetadataComponent } from './Components/sdtm-target-metadata/sdtm-target-metadata.component';
import { TransformationTemplateComponent } from './Components/transformation-template/transformation-template.component';

const routes: Routes = [
  {
    path: 'sdtmHome',
    component: SdtmHomeComponent,
    children: [
      {
        path: 'sdtmHome',
        component: SdtmHomeComponent
      },
      {
        path: 'metadata',
        component: MetadataManagementComponent,
        children: [
          {
            path: '',
            component: DirectoryComponent
          },
          {
            path: 'sourcemetadata',
            component: SourceMetadataComponent
          },
          {
            path: 'sdtmmetadata',
            component: SdtmTargetMetadataComponent
          },
          {
            path: 'transformation',
            component: TransformationTemplateComponent
          }

        ]
      },
      {
        path: 'studySetup',
        component: StudySetupComponent
      },
      {
        path: 'businessRules',
        component: BusinessRuleConfigComponent
      },
      {
        path: 'businessRules/:studyTitle/:therapeuticArea',
        component: BusinessRuleConfigComponent
     },
     {
        path: 'jobExecution',
        component: JobExecutionComponent
     },
    {
      path: 'jobExecution/:studyTitle',
      component: JobExecutionComponent
    }
    ]
  },

  ];

  @NgModule({
    imports: [
      CommonModule,
      RouterModule,
      SharedModule
     ],

  declarations: []
})
export class SdtmRoutingModule { }
