import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'filter-icon-heading',
  templateUrl: './filter-icon-heading.component.html',
  styleUrls: ['./filter-icon-heading.component.css']
})
export class FilterIconHeadingComponent implements OnInit {
  @Output() clear = new EventEmitter();
  constructor() { }
 public  addHandler() {
  this.clear.emit();
}
  ngOnInit() {
  }

}
