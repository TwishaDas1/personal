import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AnalyticsComponent } from './analytics/analytics.component';
import { LoginComponent } from './Shared/login/login.component';
import { HomeComponent } from './SDTM/Components/home/home.component';
import { JobExecutionComponent } from './SDTM/Components/job-execution/job-execution.component';
import { CheckConfigurationComponent } from './DataQuality/Components/check-configuration/check-configuration.component';
import { BusinessRuleConfigComponent } from './SDTM/Components/business-rule-config/business-rule-config.component';
import { StudySetupComponent } from './SDTM/Components/study-setup/study-setup.component';
import { SharedModule } from './Shared/shared.module';
import { SdtmModule } from './SDTM/sdtm.module';
import { SdtmHomeComponent } from './SDTM/Components/sdtm-home/sdtm-home.component';
import { DataqualityHomeComponent } from './DataQuality/Components/dataquality-home/dataquality-home.component';
import { DataQualityModule } from './DataQuality/data-quality.module';
import { BusinessResolverService } from './SDTM/Services/business-resolver.service';
import { SdtmComponent } from './SDTM/Components/sdtm/sdtm.component';
import { DataLineageComponent } from './SDTM/Components/data-lineage/data-lineage.component';
import { DataqualityComponent } from './DataQuality/Components/dataquality/dataquality.component';
import { MetadataManagementComponent } from './SDTM/Components/metadata-management/metadata-management.component';
import { DirectoryComponent } from './SDTM/Components/directory/directory.component';
import { SourceMetadataComponent } from './SDTM/Components/source-metadata/source-metadata.component';
import { SdtmTargetMetadataComponent } from './SDTM/Components/sdtm-target-metadata/sdtm-target-metadata.component';
import { TransformationTemplateComponent } from './SDTM/Components/transformation-template/transformation-template.component';


const routes: Routes = [
  { path: '', component: LoginComponent },
  {
    path: 'sdtm',
    component: SdtmComponent,
    children: [
      {
        path: '',
        component: SdtmHomeComponent
      },
      {
        path: 'metadata',
        component: MetadataManagementComponent,
        children: [
          {
            path: '',
            component: DirectoryComponent
          },
          {
            path: 'sourcemetadata',
            component: SourceMetadataComponent
          },
          {
            path: 'sdtmmetadata',
            component: SdtmTargetMetadataComponent
          },
          {
            path: 'transformation',
            component: TransformationTemplateComponent
          }
        ]
      },
      {
        path: 'studySetup',
        component: StudySetupComponent

      },
      {
        path: 'businessRules',
        component: BusinessRuleConfigComponent

      },
      {
        path: 'businessRules/:studyTitle/:version/:therapeuticArea',
        component: BusinessRuleConfigComponent,
        resolve: {
          reqDomains: BusinessResolverService
        }

      },
      {
        path: 'businessRulesFromJob/:studyTitle/:domain/:version/:baseline',
        component: BusinessRuleConfigComponent,
        resolve: {
          reqDomains: BusinessResolverService
        }

      },
      {
        path: 'jobExecution',
        component: JobExecutionComponent

      },
      {
        path: 'jobExecution/:studyTitle',
        component: JobExecutionComponent

      },
      {
        path: 'dataLineage',
        component: DataLineageComponent
      }


    ]
  },


  {
    path: 'home',
    component: HomeComponent

  },
  {

    path: 'dataQuality',
    component: DataqualityComponent,
    children: [
      {
        path: '',
        component: DataqualityHomeComponent
      },
      {
        path: 'checkConfig',
        component: CheckConfigurationComponent

      }
    ]
  },

  { path: 'analytics', component: AnalyticsComponent }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes, { useHash: true }),
    SharedModule,
    SdtmModule,
    DataQualityModule
  ],
  exports: [RouterModule],
  declarations: [],
  providers: [BusinessResolverService]
})
export class AppRoutingModule { }
