package com.cdr;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class CdrSdtmApplication extends SpringBootServletInitializer{
	
	public static void main(String[] args) {
		SpringApplication.run(CdrSdtmApplication.class, args);
	}
	
}
