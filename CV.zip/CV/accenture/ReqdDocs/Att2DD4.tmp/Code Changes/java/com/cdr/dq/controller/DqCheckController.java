	package com.cdr.dq.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cdr.dq.model.DataQualityDashboard;
import com.cdr.dq.model.DqJobRunStatistics;
import com.cdr.dq.model.DqJobRunStatisticsDTO;
import com.cdr.dq.model.DqMatrix;
import com.cdr.dq.service.DqCheckService;

@RestController
@RequestMapping("/api/CDR/DQ")
public class DqCheckController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DqCheckController.class);
	
	@Autowired
	DqCheckService dqCheckService;
	
	
	@PostMapping("/customCheck/create")
	public ResponseEntity<String> saveCustomCheck(@RequestBody DqJobRunStatistics dqJobRunStatistics) {
		DqJobRunStatistics dqJobRun = dqCheckService.createCustomCheck(dqJobRunStatistics);
		if(dqJobRun != null) {
			LOGGER.info("Custom Check created successfully.");
			return new ResponseEntity<>("Check has been created", HttpStatus.OK);
		} else {
			LOGGER.info("Error while creating custom check.");
			return new ResponseEntity<>("Error while check creation",HttpStatus.BAD_REQUEST);
		}
	}
	
	@RequestMapping(value = "/customCheck/delete/{uniqueId}", method = RequestMethod.DELETE)
	public int deleteCustomCheck(@PathVariable Integer uniqueId) {
		int isDeleted = dqCheckService.deleteById(uniqueId);
		return isDeleted;
	}
	
	@PostMapping("/customCheck/update")
	public DqJobRunStatistics updateCustomCheck(@RequestBody DqJobRunStatistics dqJobRunStatistics) {
		DqJobRunStatistics dqJobRun = dqCheckService.updateCustomCheck(dqJobRunStatistics);
		return dqJobRun;
//		if(dqJobRun != null) {
//			LOGGER.info("Custom Check updated successfully.");
//			return new ResponseEntity<>("Check has been updated", HttpStatus.OK);
//		} else {
//			LOGGER.info("Error while updating custom check.");
//			return new ResponseEntity<>("Error while check updation",HttpStatus.BAD_REQUEST);
//		}
	}
	
	
	@RequestMapping(value = "/dqMatrix/search", method = RequestMethod.GET)
	public List<DqMatrix> getDqMatrices(@RequestParam(value="form",required=false) String form,
			@RequestParam(value="study",required=false) String study,
			@RequestParam(value="category",required=false) String category,
			@RequestParam(value="check",required=false) String check,
			@RequestParam(value="status",required=false) String status,
			@RequestParam(value="therapeuticArea",required=false) String therapeuticArea) {
		LOGGER.info("DQ  Matrix search method - STARTS");
		List<DqMatrix> dqMatrices = new ArrayList<DqMatrix>();
		dqMatrices = dqCheckService.getDqMatrixDetails();
		LOGGER.info("DQ  Matrix search method - ENDS");
		return dqMatrices;	
	}
	
	
	@RequestMapping(value = "/dqMatrix/jobs", method = RequestMethod.GET)
	public List<DqJobRunStatistics> getDqJobs() {
		LOGGER.info("DQ  Matrix jobs method - STARTS");
		List<DqJobRunStatistics> dqMatrixJobs = new ArrayList<DqJobRunStatistics>();
		dqMatrixJobs = dqCheckService.getDqJobRunDetails();
		LOGGER.info("DQ  Matrix jobs method - ENDS");
		return dqMatrixJobs;	
	}
	
	@RequestMapping(value = "/dqMatrix/filter/jobs", method = RequestMethod.GET)
	public List<DqJobRunStatistics> getDqFilterJobs(@RequestParam(value="form",required=false) String form,
			@RequestParam(value="study",required=false) String study,
			@RequestParam(value="category",required=false) String category,
			@RequestParam(value="check",required=false) String check,
			@RequestParam(value="status",required=false) String status,
			@RequestParam(value="variable",required=false) String variable) {
		LOGGER.info("DQ  Matrix filter jobs method - STARTS");
		List<DqJobRunStatistics> dqMatrixJobs = new ArrayList<DqJobRunStatistics>();
		DqJobRunStatistics jobRunStat = new DqJobRunStatistics();
		jobRunStat.setStudy(study);
		jobRunStat.setForm(form);
		jobRunStat.setCategory(category);
		jobRunStat.setDqCheck(check);
		jobRunStat.setJobStatus(status);
		jobRunStat.setVariable(variable);
		dqMatrixJobs = dqCheckService.getDqJobRunDetails(jobRunStat);
		LOGGER.info("DQ  Matrix filter jobs method - ENDS");
		return dqMatrixJobs;	
	}
	
	@PutMapping("/matrix/updateCheckFlag/{id}/{flag}")
	public ResponseEntity<String> updateCheckFlag(@PathVariable Integer id, @PathVariable String flag) {
		int isUpdated = dqCheckService.updateCheckFlag(id, flag);
		if(isUpdated > 0) {
			LOGGER.info("Check Flag updated successfully.");
			return new ResponseEntity<>("Check has been updated", HttpStatus.OK);
		}
		else {
			LOGGER.info("Error while updating check flag.");
			return new ResponseEntity<>("Check not found", HttpStatus.NOT_FOUND);
		}
	}
	
	
	@PutMapping("/dqChecks/updateNotesForChecks")
	public int updateNotesForChecks(@RequestParam(value="study",required=false) String study,
			@RequestParam(value="form",required=false) String form,
			@RequestParam(value="selectedRules",required=false) List<Integer> selectedRules,
			@RequestParam(value="isAllRulesSelected",required=false) boolean isAllRulesSelected,
			@RequestParam(value="notes",required=false) String notes) {
		int isUpdated = dqCheckService.updateNotesForChecks(study,form,selectedRules,isAllRulesSelected,notes);
		if(isUpdated > 0) {
			//LOGGER.info("DQ check notes updated successfully.");
			return isUpdated;
		}
//		else {
//			LOGGER.info("Error while updating check notes.");
//			return new ResponseEntity<>("Check not found", HttpStatus.NOT_FOUND);
//		}
		return 0;
	}

	@PutMapping("/dqChecks/updateFlagsForChecks")
	public ResponseEntity<String> updateFlagsForChecks(@RequestParam(value="study",required=false) String study,
			@RequestParam(value="form",required=false) String form,
			@RequestParam(value="selectedRules",required=false) List<Integer> selectedRules,
			@RequestParam(value="isAllRulesSelected",required=false) boolean isAllRulesSelected,
			@RequestParam(value="notes",required=false) String notes) {
		int isUpdated = dqCheckService.updateFlagsForChecks(study,form,selectedRules,isAllRulesSelected,notes);
		if(isUpdated > 0) {
			LOGGER.info("DQ check Flags updated successfully.");
			return new ResponseEntity<>("Check has been updated", HttpStatus.OK);
		}
		else {
			LOGGER.info("Error while updating check flags.");
			return new ResponseEntity<>("Check not found", HttpStatus.NOT_FOUND);
		}
	}

	
	@GetMapping("/checkFailReport")
	public List<DqJobRunStatistics> getChecksFailReport() {
	return dqCheckService.getFailedChecks();
	}
	
	
	@GetMapping("/dataQualityDashboard")
	public DataQualityDashboard getDQDashBoardData() {
	return dqCheckService.getDQDashBoardData();
	}
	
	@PutMapping("/updateStatus/{uniqueId}/{status}")
	public ResponseEntity<String> updateStatus(@PathVariable Long uniqueId,@PathVariable String status) {
		LOGGER.info("Jobs to be updated for uniqueId " + uniqueId + " and status "+ status);
		int isUpdated = dqCheckService.updateStatus(uniqueId,status);
		if(isUpdated > 0) {
			LOGGER.info("Job updated successfully.");
			return new ResponseEntity<>("Job has been updated", HttpStatus.OK);
		}
		else {
			LOGGER.info("Error while updating job.");
			return new ResponseEntity<>("Job not found", HttpStatus.NOT_FOUND); 
		}
	}
	
	@PutMapping("/updateFormStatus")
	public  List<DqJobRunStatistics> updateFormStatus(@RequestBody DqJobRunStatistics dbJob) {
		return dqCheckService.updateFormStatus(dbJob);
		
	}
	
	@DeleteMapping("/deleteNotification/{id}")
	public int deleteNotification(@PathVariable("id") Integer id) {
		return dqCheckService.deleteNotification(id);
	}
	
	@PutMapping("/notificationStop/{id}")
	public int notificationStop(@PathVariable("id") Integer id) {
		return dqCheckService.notificationStop(id);
	}
	@PostMapping("/quality/updateDependent")
	public int updateDependent(@RequestBody DqJobRunStatistics dqJobRunStatistics) {
	DqJobRunStatistics dqJobRun = dqCheckService.updateEditDependent(dqJobRunStatistics);
	if(dqJobRun!=null) {	
	return 0;
	}
	else {
	return 1;	
	}
	}
	
	@GetMapping("/dependency")
	public List<DqJobRunStatisticsDTO> getDependency() {
	System.out.println("In dependency");
	List<DqJobRunStatisticsDTO> dqJobRun = dqCheckService.getFormDependency();
		return dqJobRun;
		
	}
}
