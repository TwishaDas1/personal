package com.cdr.dq.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdr.dq.model.CategoryCheckMetadata;
import com.cdr.dq.model.CategoryMetadata;
import com.cdr.dq.model.CheckMetadata;
import com.cdr.dq.model.DqJobRunStatistics;
import com.cdr.dq.model.DqJobStatusMetadata;
import com.cdr.dq.model.DqStatusMetadata;
import com.cdr.dq.service.DqMetaDataService;
import com.cdr.sdtm.model.FormMetaData;
import com.cdr.sdtm.model.FormMetaDataDTO;
import com.cdr.sdtm.model.FormVariableMetaDataDTO;
import com.cdr.sdtm.model.SourceMetadataTabDTO;
import com.cdr.sdtm.model.SourceTypeFilterDTO; 


@RestController
@RequestMapping("/api/CDR/DQ")
public class DqMetaDataController { 

	@Autowired
	DqMetaDataService dqMetaDataService;

	/**
	 * Method fetches data quality categories metadata
	 * @return
	 */
	@GetMapping("/quality/categories")
	public List<CategoryMetadata> getCategoryMetaData() {
		List<CategoryMetadata> categories = new ArrayList<CategoryMetadata>();
		categories = dqMetaDataService.getCategoryMetadata();
		return categories;
	}


	/**
	 * Method fetches data quality checks metadata
	 * @return
	 */
	@GetMapping("/quality/checks")
	public List<CheckMetadata> getCheckMetaData() {
		List<CheckMetadata> checks = new ArrayList<CheckMetadata>();
		checks = dqMetaDataService.getCheckMetadata();
		return checks;
	}

	/**
	 * Method fetches data quality checks metadata
	 * @return
	 */
	@GetMapping("/quality/categoryChecks")
	public List<CategoryCheckMetadata> getCategoryCheckMetaData() {
		List<CategoryCheckMetadata> categoryChecks = new ArrayList<CategoryCheckMetadata>();
		categoryChecks = dqMetaDataService.getCategoryCheckMetadata();
		return categoryChecks;
	} 


	/**
	 * Method fetches data quality job status metadata
	 * @return
	 */
	@GetMapping("/quality/dqJobStatuses")
	public List<DqJobStatusMetadata> getDqJobStatusMetadata() {
		List<DqJobStatusMetadata> dqJobStatuses = new ArrayList<DqJobStatusMetadata>();
		dqJobStatuses = dqMetaDataService.getDqJobStatusMetadata();
		return dqJobStatuses;
	}

	/**
	 * Method fetches data quality status metadata
	 * @return
	 */
	@GetMapping("/quality/dqStatuses")
	public List<DqStatusMetadata> getDqStatusMetadata() {
		List<DqStatusMetadata> dqStatuses = new ArrayList<DqStatusMetadata>();
		dqStatuses = dqMetaDataService.getDqStatusMetadata();
		return dqStatuses;
	}


	//	@GetMapping("/sendEmail")
	//	public String sendEmail() {
	//	
	//		dqMetaDataService.sendEmail();
	//		return "EmailSent";
	//		
	//	}

	/**
	 * Method fetches data quality libraries
	 * @return
	 */
	@GetMapping("/quality/libraries")
	public List <String> getDqLibrary() {
		List<String> dqlibrary = new ArrayList<String>();
		dqlibrary = dqMetaDataService.getDqLibrary();
		return dqlibrary;
	}
	@GetMapping("/quality/fetch/{form}/{library}/{study}")
	public List<DqJobRunStatistics> importDataLibrary(@PathVariable("form") String form,@PathVariable("library") String library,@PathVariable("study") String study) {
		System.out.println("In the controller");
		List<DqJobRunStatistics> matrices = new ArrayList<DqJobRunStatistics>();
		matrices = dqMetaDataService.importLibrary(form,library,study);
		return matrices;
	}
	@GetMapping("/quality/check/{form}/{library}/{study}")
	public List<DqJobRunStatistics> getDataLibrary(@PathVariable("form") String form,@PathVariable("library") String library,@PathVariable("study") String study) {
		
		//List<DqJobRunStatistics> matrices = new ArrayList<DqJobRunStatistics>();
		List<DqJobRunStatistics> matrices = dqMetaDataService.getCheck(form,library,study);
	    return matrices;
	}
	@GetMapping("/quality/formVariable")
	public Set<FormVariableMetaDataDTO>formVariableMetadata() {
		return dqMetaDataService.formVariableMetadata();
	}
	
	
	@GetMapping("/quality/form")
	public List<FormMetaDataDTO> formMetadata(){
		return dqMetaDataService.formMetadata();
	}	
	 
}
	