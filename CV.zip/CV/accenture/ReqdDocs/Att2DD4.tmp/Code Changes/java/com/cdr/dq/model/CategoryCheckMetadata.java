package com.cdr.dq.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="category_check_metadata")
@Table(name="category_check_metadata")
public class CategoryCheckMetadata {
	
	@Id
	@Column(name="check")
	private String check;
	
	@Column(name="category") 
	private String category;
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getCheck() {
		return check;
	}

	public void setCheck(String check) {
		this.check = check;
	}
	
	
	
}
