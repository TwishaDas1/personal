package com.cdr.dq.model;

import java.util.List;

public class CheckConfigStatusGraph {
	
	private List<String> labels;
	private List<GraphCategory> category;
	
	
	public List<String> getLabels() {
		return labels;
	}
	public List<GraphCategory> getCategory() {
		return category;
	}
	public void setLabels(List<String> labels) {
		this.labels = labels;
	}
	public void setCategory(List<GraphCategory> category) {
		this.category = category;
	}

}
