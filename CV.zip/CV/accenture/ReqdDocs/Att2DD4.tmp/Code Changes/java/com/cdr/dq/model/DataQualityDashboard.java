package com.cdr.dq.model;

import java.util.List;

public class DataQualityDashboard {
	
	private List<Study> studies;

	public List<Study> getStudies() {
		return studies;
	}

	public void setStudies(List<Study> studies) {
		this.studies = studies;
	}
	
}
