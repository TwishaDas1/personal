package com.cdr.dq.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;




@Entity
@Table(name="dq_job_run_statistics")
public class DqJobRunStatistics {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="unique_id")
	private int uniqueId;
	
	@Column(name="study")
	private String study;
	
	@Column(name="form")
	private String form;
	
	@Column(name="category")
	private String category;
	
	@Column(name="dq_check")
	private String dqCheck;

	@Column(name="variable")
	private String variable;
	
	@Column(name="input")
	private String input; 
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@Column(name="input2")
	private String input2;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@Column(name="job_status")
	private String jobStatus;
	
	@Column(name="job_start_timestamp")
	private String jobStartTimestamp;
	
	@Column(name="job_end_timestamp")
	private String jobEndTimestamp;
	
	@Column(name="message")
	private String message;
	
	@Column(name="check_flag")
	private String checkFlag;
	
	@Column(name="notes")
	private String notes;
	
	@Column(name="checkEnable")
	private String checkEnable;
	
	@Column(name="checkLogic")
	private String checkLogic;
	
	@Column(name="form_status")
	private String formStatus;
	
	
	
	@Transient
	private String checkLength;
	
	@Transient
	private String sourceVariable;
	
	@Transient
	private String independentVariable;
	
	@Transient
	private String dependentVariable;
	
	@Transient
	private String dependency;
	
	@Transient
	private String upperRange;
	
	@Transient
	private String lowerRange;
	
	@Transient
	private String initialDate;
	
	@Transient
	private String secondaryDate;
	
	
	
	public DqJobRunStatistics() {
		
	}
	
	public DqJobRunStatistics(String study, String form, String category, String check, String variable,
			String jobStatus) {
		super();
		this.study = study;
		this.form = form;
		this.category = category;
		this.dqCheck = check;
		this.variable = variable;
		this.jobStatus = jobStatus;
	}

	public int getUniqueId() {
		return uniqueId;
	}

	public void setUniqueId(int uniqueId) {
		this.uniqueId = uniqueId;
	}

	public String getStudy() {
		return study;
	}

	public void setStudy(String study) {
		this.study = study;
	}

	public String getForm() {
		return form;
	}

	public void setForm(String form) {
		this.form = form;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDqCheck() {
		return dqCheck;
	}

	public void setDqCheck(String dqCheck) {
		this.dqCheck = dqCheck;
	}

	public String getVariable() {
		return variable;
	}

	public void setVariable(String variable) {
		this.variable = variable;
	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}
	public String getInput2() {
		return input2;
	}

	public void setInput2(String input2) {
		this.input2 = input2;
	}
	
	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getJobStartTimestamp() {
		return jobStartTimestamp;
	}

	public void setJobStartTimestamp(String jobStartTimestamp) {
		this.jobStartTimestamp = jobStartTimestamp;
	}

	public String getJobEndTimestamp() {
		return jobEndTimestamp;
	}

	public void setJobEndTimestamp(String jobEndTimestamp) {
		this.jobEndTimestamp = jobEndTimestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCheckFlag() {
		return checkFlag;
	}

	public void setCheckFlag(String checkFlag) {
		this.checkFlag = checkFlag;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getCheckEnable() {
		return checkEnable;
	}

	public void setCheckEnable(String checkEnable) {
		this.checkEnable = checkEnable;
	}

	public String getCheckLogic() {
		return checkLogic;
	}

	public void setCheckLogic(String checkLogic) {
		this.checkLogic = checkLogic;
	}

	@Transient
	public String getSourceVariable() {
		return sourceVariable;
	}

	public void setSourceVariable(String sourceVariable) {
		this.sourceVariable = sourceVariable;
	}

	@Transient
	public String getIndependentVariable() {
		return independentVariable;
	}

	public void setIndependentVariable(String independentVariable) {
		this.independentVariable = independentVariable;
	}

	@Transient
	public String getDependentVariable() {
		return dependentVariable;
	}

	public void setDependentVariable(String dependentVariable) {
		this.dependentVariable = dependentVariable;
	}

	@Transient
	public String getDependency() {
		return dependency;
	}

	public void setDependency(String dependency) {
		this.dependency = dependency;
	}

	@Transient
	public String getUpperRange() {
		return upperRange;
	}

	public void setUpperRange(String upperRange) {
		this.upperRange = upperRange;
	}

	@Transient
	public String getLowerRange() {
		return lowerRange;
	}

	public void setLowerRange(String lowerRange) {
		this.lowerRange = lowerRange;
	}

	@Transient
	public String getInitialDate() {
		return initialDate;
	}

	public void setInitialDate(String initialDate) {
		this.initialDate = initialDate;
	}

	@Transient
	public String getSecondaryDate() {
		return secondaryDate;
	}

	public void setSecondaryDate(String secondaryDate) {
		this.secondaryDate = secondaryDate;
	}

	@Transient
	public String getCheckLength() {
		return checkLength;
	}

	public void setCheckLength(String checkLength) {
		this.checkLength = checkLength;
	}

	public String getFormStatus() {
		return formStatus;
	}
	
	@Transient
	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}

		

}