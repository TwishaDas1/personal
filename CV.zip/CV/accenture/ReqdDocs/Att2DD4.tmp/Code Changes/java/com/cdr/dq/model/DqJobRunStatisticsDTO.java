package com.cdr.dq.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DqJobRunStatisticsDTO {

	private int uniqueId;

	private String study;

	private String form;

	private String category;

	private String dqCheck;

	private String variable;

	private String input; 

	private String input2;

	private String jobStatus;

	private String jobStartTimestamp;

	private String jobEndTimestamp;

	private String message;

	private String checkFlag;

	private String notes;

	private String checkEnable;

	private String checkLogic;

	private String formStatus;

	private String checkLength;

	private String sourceVariable;

	private String independentVariable;

	private String dependentVariable;

	private String dependency;

	private String upperRange;

	private String lowerRange;

	private String initialDate;

	private String secondaryDate;

	public DqJobRunStatisticsDTO() {

	}

	public DqJobRunStatisticsDTO(String form, String input, String input2) {
		this.form=form;
		this.input=input;
		this.input2=input2;
	}

}
