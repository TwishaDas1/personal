package com.cdr.dq.model;

public class FormDetail {
	
	public String getFormName() {
		return formName;
	}
	public String getFormStatus() {
		return formStatus;
	}
	public String getJobExecutionStatus() {
		return jobExecutionStatus;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public void setFormStatus(String formStatus) {
		this.formStatus = formStatus;
	}
	public void setJobExecutionStatus(String jobExecutionStatus) {
		this.jobExecutionStatus = jobExecutionStatus;
	}
	private String formName;
	private String formStatus;
	private String jobExecutionStatus;

}
