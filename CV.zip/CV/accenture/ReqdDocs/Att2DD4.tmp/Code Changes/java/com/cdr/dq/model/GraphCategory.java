package com.cdr.dq.model;

public class GraphCategory {
	
	private String category;
	private int value;
	
	public GraphCategory() {
		
	}
	public GraphCategory(String category, int value) {
		super();
		this.category = category;
		this.value = value;
	}
	
	
	public String getCategory() {
		return category;
	}
	public int getValue() {
		return value;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
	 @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GraphCategory other = (GraphCategory) obj;
		if(this.category.equals(other.category))
		return true;
		else 
			return false;
	}
	

}
