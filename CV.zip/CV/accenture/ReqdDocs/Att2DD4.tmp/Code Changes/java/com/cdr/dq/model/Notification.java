/**
 * 
 */
package com.cdr.dq.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="dq_notification")
@Table(name="dq_notification")
public class Notification {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	private int id;
	
	@Column(name="STUDY")
	private String study;
	
	@Column(name="NOTIFICATION_DESC")
	private String notificationDesc;
	
	public String getNotificationDesc() {
		return notificationDesc;
	}

	public void setNotificationDesc(String notificationDesc) {
		this.notificationDesc = notificationDesc;
	}

	@Column(name="CREATE_DT")
	private String create_dt;
	
	@Column(name="NOTIFICATION_DELETE")
	private String notificationDelete;
	
	@Column(name="NOTIFICATION_STOP")
	private String notificationStop;
	
	@Column(name="TASK_DESC")
	private String taskDesc;
	
	@Column(name="TASK_DUE_DT")
	private String taskDueDate;
	
	public int getId() {
		return id;
	}

	public String getStudy() {
		return study;
	}

	public String getCreate_dt() {
		return create_dt;
	}

	public String getNotificationDelete() {
		return notificationDelete;
	}

	public String getNotificationStop() {
		return notificationStop;
	}

	public String getTaskDesc() {
		return taskDesc;
	}

	public String getTaskDueDate() {
		return taskDueDate;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setStudy(String study) {
		this.study = study;
	}

	public void setCreate_dt(String create_dt) {
		this.create_dt = create_dt;
	}

	public void setNotificationDelete(String notificationDelete) {
		this.notificationDelete = notificationDelete;
	}

	public void setNotificationStop(String notificationStop) {
		this.notificationStop = notificationStop;
	}

	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}

	public void setTaskDueDate(String taskDueDate) {
		this.taskDueDate = taskDueDate;
	}

	
	
	
	
}
