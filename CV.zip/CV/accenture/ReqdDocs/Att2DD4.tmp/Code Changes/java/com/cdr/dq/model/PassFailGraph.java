package com.cdr.dq.model;

public class PassFailGraph {

}
