package com.cdr.dq.model;

import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Study {
	
	private String studyId;
	private String studyTitle;
	private String studyDescription;
	private String studyPhase;
	private String studyStatus;
	private String studyAnalyst;
	private String studyManager;
	private int itemsRequireAttention;
	private int newNotifications;
	private int openNotifications;
	private List<Notification> notifications;
	private String studyName;
	private String studySetupDate;
	private List<GraphCategory> formConigGraphCategories;
	private List<GraphCategory> failedCheckGraphCategories;
	private List<GraphCategory> formActiveStatusGraphCategories;
	private int numberOfForms;
	private List<Task> tasks;
	private List<FormDetail> formDetailList;
	private int totalCheckCount;
	private int totalFormCount;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Timestamp lastJobRunDate;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	private Timestamp dbLockDate;
	
	
	public Timestamp getDbLockDate() {
		return dbLockDate;
	}
	public void setDbLockDate(Timestamp dbLockDate) {
		this.dbLockDate = dbLockDate;
	}
	
	
	public int getNewNotifications() {
		return newNotifications;
	}
	public int getOpenNotifications() {
		return openNotifications;
	}
	public void setNewNotifications(int newNotifications) {
		this.newNotifications = newNotifications;
	}
	public void setOpenNotifications(int openNotifications) {
		this.openNotifications = openNotifications;
	}
	public int getTotalCheckCount() {
		return totalCheckCount;
	}
	public int getTotalFormCount() {
		return totalFormCount;
	}
	public void setTotalCheckCount(int totalCheckCount) {
		this.totalCheckCount = totalCheckCount;
	}
	public void setTotalFormCount(int totalFormCount) {
		this.totalFormCount = totalFormCount;
	}
	
	
	public Study() {
		
	}
	public Study(String studyId
			, String studyTitle, String studyDescription, String studyPhase, String studyStatus,
			String studyAnalyst, String studyManager//, Timestamp dbLockDate, Timestamp studySetupDate
			) {
		super();
		this.studyId = studyId;
		this.studyTitle = studyTitle;
		this.studyDescription = studyDescription;
		this.studyPhase = studyPhase;
		this.studyStatus = studyStatus;
		this.studyAnalyst = studyAnalyst;
		this.studyManager = studyManager;
		this.dbLockDate = dbLockDate;
		//this.studySetupDate = studySetupDate;
	}
	
	public String getStudyId() {
		return studyId;
	}
	public String getStudyTitle() {
		return studyTitle;
	}
	public String getStudyDescription() {
		return studyDescription;
	}
	public String getStudyPhase() {
		return studyPhase;
	}
	public String getStudyStatus() {
		return studyStatus;
	}
	public String getStudyAnalyst() {
		return studyAnalyst;
	}
	public String getStudyManager() {
		return studyManager;
	}
	public int getItemsRequireAttention() {
		return itemsRequireAttention;
	}
	public List<Notification> getNotifications() {
		return notifications;
	}
	public String getStudyName() {
		return studyName;
	}
	public String getStudySetupDate() {
		return studySetupDate;
	}
	public List<GraphCategory> getFormConigGraphCategories() {
		return formConigGraphCategories;
	}
	public List<GraphCategory> getFailedCheckGraphCategories() {
		return failedCheckGraphCategories;
	}
	public List<GraphCategory> getFormActiveStatusGraphCategories() {
		return formActiveStatusGraphCategories;
	}
	public int getNumberOfForms() {
		return numberOfForms;
	}
	public List<Task> getTasks() {
		return tasks;
	}
	public List<FormDetail> getFormDetailList() {
		return formDetailList;
	}
	public void setStudyId(String studyId) {
		this.studyId = studyId;
	}
	public void setStudyTitle(String studyTitle) {
		this.studyTitle = studyTitle;
	}
	public void setStudyDescription(String studyDescription) {
		this.studyDescription = studyDescription;
	}
	public void setStudyPhase(String studyPhase) {
		this.studyPhase = studyPhase;
	}
	public void setStudyStatus(String studyStatus) {
		this.studyStatus = studyStatus;
	}
	public void setStudyAnalyst(String studyAnalyst) {
		this.studyAnalyst = studyAnalyst;
	}
	public void setStudyManager(String studyManager) {
		this.studyManager = studyManager;
	}
	public void setItemsRequireAttention(int itemsRequireAttention) {
		this.itemsRequireAttention = itemsRequireAttention;
	}
	public void setNotifications(List<Notification> notifications) {
		this.notifications = notifications;
	}
	public void setStudyName(String studyName) {
		this.studyName = studyName;
	}
	public void setStudySetupDate(String studySetupDate) {
		this.studySetupDate = studySetupDate;
	}
	public void setFormConigGraphCategories(List<GraphCategory> formConigGraphCategories) {
		this.formConigGraphCategories = formConigGraphCategories;
	}
	public void setFailedCheckGraphCategories(List<GraphCategory> failedCheckGraphCategories) {
		this.failedCheckGraphCategories = failedCheckGraphCategories;
	}
	public void setFormActiveStatusGraphCategories(List<GraphCategory> formActiveStatusGraphCategories) {
		this.formActiveStatusGraphCategories = formActiveStatusGraphCategories;
	}
	public void setNumberOfForms(int numberOfForms) {
		this.numberOfForms = numberOfForms;
	}
	public void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}
	public void setFormDetailList(List<FormDetail> formDetailList) {
		this.formDetailList = formDetailList;
	}

}
