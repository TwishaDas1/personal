package com.cdr.dq.model;

public class Task {

}
