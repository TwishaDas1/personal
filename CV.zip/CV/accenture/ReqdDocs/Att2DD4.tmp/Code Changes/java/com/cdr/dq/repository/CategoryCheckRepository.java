package com.cdr.dq.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdr.dq.model.CategoryCheckMetadata;

public interface CategoryCheckRepository extends JpaRepository<CategoryCheckMetadata, String>{
 
	
}  
