package com.cdr.dq.repository;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdr.dq.model.GraphCategory;
import com.cdr.dq.model.Study;

@Repository
public class CustomRepository {

	@Autowired
	@Qualifier("dqJdbcTemplate")
	JdbcTemplate dqJdbcTemplate;
	 
	public List<GraphCategory> findGraphData(String study){
		
		String sql="select form_status as category, count(distinct(form)) as value from DQ.dq_job_run_statistics where study='"+study+"' group by (form_status)";
		List<GraphCategory> graphList=  dqJdbcTemplate.query(sql,
				new BeanPropertyRowMapper<>(GraphCategory.class));
		Set<GraphCategory> graphSet = new HashSet<>(graphList);
		Set<GraphCategory> completeSet = new HashSet<>(graphList);
		completeSet.add(new GraphCategory("Not Started", 0));
		completeSet.add(new GraphCategory("In Progress", 0));
		completeSet.add(new GraphCategory("Ready for Review", 0));
		completeSet.add(new GraphCategory("Approved", 0));
		completeSet.add(new GraphCategory("Rejected", 0));
		completeSet.addAll(graphSet);
		
		
		return new ArrayList<>(completeSet);
	}
	
	
public List<GraphCategory> getFailedChecksGraphData(String study){
		
		String sql="select dq_check as category, count(dq_check) as value from DQ.dq_job_run_statistics where study='"+study+"' and job_status =\'In Progress\' group by (dq_check)";
		List<GraphCategory> graphList=  dqJdbcTemplate.query(sql,
				new BeanPropertyRowMapper<>(GraphCategory.class));
		
		Set<GraphCategory> graphSet = new HashSet<>(graphList);
		Set<GraphCategory> completeSet = new HashSet<>(graphList);
		completeSet.add(new GraphCategory("Not Null", 0));
		completeSet.add(new GraphCategory("Dependency", 0));
		completeSet.add(new GraphCategory("Data Length", 0));
		completeSet.add(new GraphCategory("Chronological", 0));
		completeSet.add(new GraphCategory("Range", 0));
		completeSet.add(new GraphCategory("Uniqueness", 0));
		completeSet.addAll(graphSet);
		
		
		return new ArrayList<>(completeSet);
	}

public List<GraphCategory> getActiveFormGraphData(String study){
	
	String sql="select checkEnable as category, count(checkEnable) as value from DQ.dq_job_run_statistics where study='"+study+"' group by (checkEnable);";
	List<GraphCategory> graphList=  dqJdbcTemplate.query(sql,
			new BeanPropertyRowMapper<>(GraphCategory.class));
	
	Set<GraphCategory> graphSet = new HashSet<>(graphList);
	Set<GraphCategory> completeSet = new HashSet<>(graphList);
	completeSet.add(new GraphCategory("Disabled", 0));
	completeSet.add(new GraphCategory("Enabled", 0));
	completeSet.addAll(graphSet);
	
	return new ArrayList<>(completeSet);
}

public Study getFormAndCheckCount(String studyName){
	
	String sql="select count(dq_check) as totalCheckCount, count(distinct(form)) as totalFormCount, max(job_start_timestamp) as lastJobRun from DQ.dq_job_run_statistics where study='"+studyName+"'";
	List<Study> study=  dqJdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Study.class));
	return study.get(0);
}
}
