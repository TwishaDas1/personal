package com.cdr.dq.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cdr.dq.model.DqJobRunStatistics;
import com.cdr.dq.model.DqJobRunStatisticsDTO;

@Repository
public interface DqJobRunRepository extends JpaRepository<DqJobRunStatistics, Integer>  {
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_job_run_statistics set check_flag=:flag where unique_id=:id")
	int updateCheckFlag(Integer id, String flag);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_job_run_statistics set notes=:notes where study=:study and form=:form")
	int updateNotesForChecks(String study, String form, String notes);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_job_run_statistics set notes=:notes where unique_id in (:selectedRules)")
	int updateNotesForSelectedChecks(List<Integer> selectedRules, String notes);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_job_run_statistics set notes=:notes, check_flag='Y' where study=:study and form=:form")
	int updateFlagsForChecks(String study, String form, String notes);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_job_run_statistics set notes=:notes, check_flag='Y' where unique_id in (:selectedRules)")
	int updateFlagsForSelectedChecks(List<Integer> selectedRules, String notes);
	
	List<DqJobRunStatistics> findFailedDqChecksByStudy(String study);
	
	List<DqJobRunStatistics> findByJobStatus(String jobStatus);
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_job_run_statistics set job_status=:status where unique_id=:uniqueId")
	int updateStatus(@Param("uniqueId") Long uniqueId,@Param("status") String status);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_job_run_statistics set form_status=:formStatus where form=:form and study=:study")
	int updateFormStatus(String formStatus, String form, String study); 
	
	List<DqJobRunStatistics> findByFormAndStudy(String form, String study);
	DqJobRunStatistics findByUniqueId(int uniqueId );
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="DELETE FROM dq_job_run_statistics where study=:study and form=:form") 
	int deleteByFormAndStudy(@Param("form")String form, @Param("study")String study);

//	@Query(nativeQuery=true,value="select distinct input, input2 from DQ.dq_job_run_statistics where form=:form and dq_check=:dqCheck") 
//	List <DqJobRunStatistics> findByForm(String form, String dqCheck);

	
	@Query("select new com.cdr.dq.model.DqJobRunStatisticsDTO(djrs.form,djrs.input, djrs.input2)"
			+ "from DqJobRunStatistics djrs "
			+ "where djrs.dqCheck='Dependency' and djrs.input is not null and djrs.input2 is not null") 
	List<DqJobRunStatisticsDTO>findByForm();

}
