package com.cdr.dq.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cdr.dq.model.DqMatrix;

@Repository
public interface DqMatrixRepository extends JpaRepository<DqMatrix, String> {

	List<DqMatrix>findByFormAndLibrary(String form,String library);

	@Query(nativeQuery=true,value="select distinct library from dq_matrix where library is not null") 
	List<String> findDistinctLibraries();
}
