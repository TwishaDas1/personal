package com.cdr.dq.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cdr.dq.model.Notification;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, String>{
	
	@Query(nativeQuery=true,value="select * FROM notifications where study_id in (:studyIds) and notification_delete ='N' and user_role=:userRole  order by create_dt desc")
	List<Notification> findByStudyIds(@Param("studyIds") List<String> studyIds, @Param("userRole") String userRole);
	
	List<Notification> findByStudyAndNotificationDelete(String study, String deleteSw);
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_notification set notification_delete='Y' where id=:id")
	int deleteNotification(Integer id); 
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update dq_notification set notification_stop='Y' where id=:id")
	int notificationStop(Integer id);

}
