package com.cdr.dq.service;

import java.util.List;

import com.cdr.dq.model.DataQualityDashboard;
import com.cdr.dq.model.DqJobRunStatistics;
import com.cdr.dq.model.DqJobRunStatisticsDTO;
import com.cdr.dq.model.DqMatrix;

public interface DqCheckService {
	
	List<DqMatrix> getDqMatrixDetails();
	
	List<DqJobRunStatistics> getDqJobRunDetails();

	List<DqJobRunStatistics> getDqJobRunDetails(DqJobRunStatistics jobRunStat);
	
	int updateCheckFlag(Integer id, String flag);


	int updateNotesForChecks(String study, String form, List<Integer> selectedRules, boolean isAllRulesSelected,
			String notes);

	int updateFlagsForChecks(String study, String form, List<Integer> selectedRules, boolean isAllRulesSelected,
			String notes);

	DqJobRunStatistics createCustomCheck(DqJobRunStatistics dqJobRunStatistics);

	int deleteById(Integer uniqueId);
 
	DqJobRunStatistics updateCustomCheck(DqJobRunStatistics dqJobRunStatistics);
	
	 
public DqJobRunStatistics getInputLogic(DqJobRunStatistics dqJobRunStatistics,DqJobRunStatistics _checkData);

	public List<DqJobRunStatistics> getFailedChecks();
	
	public DataQualityDashboard getDQDashBoardData();

	int updateStatus(Long uniqueId, String status);

	 List<DqJobRunStatistics> updateFormStatus(DqJobRunStatistics dqJob);
	
	int deleteNotification(Integer id);
	
	int notificationStop(Integer id);

	DqJobRunStatistics updateEditDependent(DqJobRunStatistics dqJobRunStatistics);

	List<DqJobRunStatisticsDTO> getFormDependency();
}
