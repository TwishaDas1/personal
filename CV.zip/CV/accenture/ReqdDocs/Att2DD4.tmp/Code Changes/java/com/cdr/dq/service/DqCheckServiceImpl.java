package com.cdr.dq.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.CollectionUtils;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.stereotype.Service;

import com.cdr.dq.model.CheckConfigStatusGraph;
import com.cdr.dq.model.DataQualityDashboard;
import com.cdr.dq.model.DqJobRunStatistics;
import com.cdr.dq.model.DqJobRunStatisticsDTO;
import com.cdr.dq.model.DqMatrix;
import com.cdr.dq.model.GraphCategory;
import com.cdr.dq.model.Notification;
import com.cdr.dq.model.Study;
import com.cdr.dq.repository.CustomRepository;
import com.cdr.dq.repository.DqJobRunRepository;
import com.cdr.dq.repository.DqMatrixRepository;
import com.cdr.dq.repository.NotificationRepository;
import com.cdr.sdtm.repository.StudyRepository;

@Service
public class DqCheckServiceImpl implements DqCheckService {
	
	public static final String ALL = "all";
	
	@Autowired
	DqMatrixRepository dqMatrixRepository;
	
	@Autowired
	DqJobRunRepository dqJobRunRepository;
	
	@Autowired
	StudyRepository studyRepository;

	@Autowired
	NotificationRepository notificationRepository;
	
	@Autowired
	CustomRepository customRepository;


	@Override
	public List<DqMatrix> getDqMatrixDetails() {
		return dqMatrixRepository.findAll();
	}

	@Override
	public List<DqJobRunStatistics> getDqJobRunDetails() {
		return dqJobRunRepository.findAll();
	}

	@Override
	public List<DqJobRunStatistics> getDqJobRunDetails(DqJobRunStatistics jobRunStat) {
		if(ALL.equalsIgnoreCase(jobRunStat.getStudy())) {
			jobRunStat.setStudy(null);
		}
		if(ALL.equalsIgnoreCase(jobRunStat.getForm())) {
			jobRunStat.setForm(null);
		}
		if(ALL.equalsIgnoreCase(jobRunStat.getCategory())) {
			jobRunStat.setCategory(null);
		}

		if(ALL.equalsIgnoreCase(jobRunStat.getDqCheck())) {
			jobRunStat.setDqCheck(null);

		}
		if(ALL.equalsIgnoreCase(jobRunStat.getVariable())) {
			jobRunStat.setVariable(null);
		}
		if(ALL.equalsIgnoreCase(jobRunStat.getJobStatus())) {
			jobRunStat.setJobStatus(null);
		}
		
		ExampleMatcher matcher = ExampleMatcher.matching()
											   .withIgnoreNullValues()
											   .withStringMatcher(StringMatcher.CONTAINING)
											   .withIgnorePaths("uniqueId")
											   .withIgnorePaths("checkLength")
											   .withIgnorePaths("sourceVariable")
											   .withIgnorePaths("independentVariable")
											   .withIgnorePaths("dependentVariable")
											   .withIgnorePaths("dependency")
											   .withIgnorePaths("upperRange")
											   .withIgnorePaths("lowerRange")
											   .withIgnorePaths("initialDate")
											   .withIgnorePaths("secondaryDate");
		
		
		Example<DqJobRunStatistics> example = Example.of(jobRunStat, matcher);
		
		List<DqJobRunStatistics> jobList = dqJobRunRepository.findAll(example);
		jobList.stream().forEach(job -> {
			if(job.getDqCheck().equals("Chronological")) {
				job.setInitialDate(job.getInput());
				job.setSecondaryDate(job.getInput2());
			}
		});
		return jobList;
	}

	
	@Override
	public int updateCheckFlag(Integer id, String flag) {
		return dqJobRunRepository.updateCheckFlag(id, flag);
	}

	@Override
	public int updateNotesForChecks(String study, String form, List<Integer> selectedRules, boolean isAllRulesSelected,
			String notes) {
		if(isAllRulesSelected) {
			return dqJobRunRepository.updateNotesForChecks(study,form,notes);
		} else {
			return dqJobRunRepository.updateNotesForSelectedChecks(selectedRules,notes);
		}
	}

	@Override
	public int updateFlagsForChecks(String study, String form, List<Integer> selectedRules, boolean isAllRulesSelected,
			String notes) {
		if(isAllRulesSelected) {
			return dqJobRunRepository.updateFlagsForChecks(study,form,notes);
		} else {
			return dqJobRunRepository.updateFlagsForSelectedChecks(selectedRules,notes);
		}
	}

	@Override
	public DqJobRunStatistics createCustomCheck(DqJobRunStatistics dqJobRunStatistics) {
		dqJobRunStatistics.setJobStatus("Not started");
		dqJobRunStatistics.setCheckFlag("N");
		return dqJobRunRepository.save(dqJobRunStatistics);
	}

	@Override
	public int deleteById(Integer uniqueId) {
		DqJobRunStatistics _checkData = dqJobRunRepository.findByUniqueId(uniqueId);
		if(_checkData!=null) {
			dqJobRunRepository.deleteById(uniqueId);
			//return _checkData;
			return 1;
		} 
		return 0;
	}

	@Override
	public DqJobRunStatistics updateCustomCheck(DqJobRunStatistics dqJobRunStatistics) {
		//Optional<DqJobRunStatistics> _checkData = dqJobRunRepository.findById(dqJobRunStatistics.getUniqueId());
		DqJobRunStatistics _checkData = dqJobRunRepository.findByUniqueId(dqJobRunStatistics.getUniqueId());
		if(_checkData!=null) {
			//.isPresent()
			//dqJobRunStatistics.setCheckLogic(getCheckLogic(dqJobRunStatistics));
			getInputLogic(dqJobRunStatistics,_checkData);
			dqJobRunRepository.save(_checkData);
			return _checkData;
		}
		return null;
	}

	
	
	public List<DqJobRunStatistics> getFailedChecks(){
		return dqJobRunRepository.findByJobStatus("Not Started");
	}
	
	//This is test data, should read data from tables
		public DataQualityDashboard getDQDashBoardData() {
			DataQualityDashboard dashboard = new DataQualityDashboard();
			
			//find all studys
			
		//	List<com.cdr.sdtm.model.Study> studyList = 
			List<Study> studyList3 =	studyRepository.findAll().stream().map(p -> new Study(p.getStudyID(),p.getTitle(), p.getDescription(), p.getPhase(), p.getStatus()
					, p.getAnalyst(), p.getManager())).collect(Collectors.toList());
			studyList3.stream().forEach(p -> {
				List<Notification> notificationList = new ArrayList<>();
				notificationList = notificationRepository.findByStudyAndNotificationDelete(p.getStudyTitle(), "N");
				p.setNotifications(notificationList);
				
				//Form Config Status Graph
				List<GraphCategory> formConfigCategories = customRepository.findGraphData(p.getStudyTitle());
				p.setFormConigGraphCategories(formConfigCategories);
			
				//Failed checks by check Type graph
				List<GraphCategory> failedCheckCategories = customRepository.getFailedChecksGraphData(p.getStudyTitle());
				p.setFailedCheckGraphCategories(failedCheckCategories);
				
				//Form Active Status Graph
				List<GraphCategory> formActiveStatusGraphCategories = customRepository.getActiveFormGraphData(p.getStudyTitle());
				p.setFormActiveStatusGraphCategories(formActiveStatusGraphCategories);
				
				//Total Form Count and Total Check count
				Study formAndCheckcount = customRepository.getFormAndCheckCount(p.getStudyTitle());
				p.setTotalCheckCount(formAndCheckcount.getTotalCheckCount());
				p.setTotalFormCount(formAndCheckcount.getTotalFormCount());
				p.setNewNotifications(6);
				p.setOpenNotifications(3);
				
			});
			
			dashboard.setStudies(studyList3);
			return dashboard;
		}

	
	
	private String getCheckLogic(DqJobRunStatistics dqJobRunStatistics) {
		StringBuffer storedLogic = new StringBuffer();
		switch(dqJobRunStatistics.getDqCheck()) {
		case "Data Length":     storedLogic.append("FV=");
								storedLogic.append(dqJobRunStatistics.getVariable());
								storedLogic.append(";LT=");
								storedLogic.append(dqJobRunStatistics.getCheckLength());
								storedLogic.append(";");
								break;
		case "Variable Present": 
		case "Not Null":
		case "Uniqueness": 	   storedLogic.append("SV=");
							   storedLogic.append(dqJobRunStatistics.getSourceVariable());
							   storedLogic.append(";");
			                   break;
		case "Dependency":     storedLogic.append("DV=");
							   storedLogic.append(dqJobRunStatistics.getDependentVariable());
		                       storedLogic.append(";IV=");
		                       storedLogic.append(dqJobRunStatistics.getIndependentVariable());
		                       storedLogic.append(";DD=");
		                       storedLogic.append(dqJobRunStatistics.getDependency());
		                       storedLogic.append(";");
			                   break;
		case "Range":  		   storedLogic.append("SV=");
		   					   storedLogic.append(dqJobRunStatistics.getSourceVariable());
		   					   storedLogic.append(";");
			                   storedLogic.append("LR=");
					   		   storedLogic.append(dqJobRunStatistics.getLowerRange());
					           storedLogic.append(";UR=");
					           storedLogic.append(dqJobRunStatistics.getUpperRange());
					           storedLogic.append(";");
					           break;
		case "Chronological":  storedLogic.append("ID=");
		   					   storedLogic.append(dqJobRunStatistics.getInitialDate());
		   					   storedLogic.append(";SD=");
		   					   storedLogic.append(dqJobRunStatistics.getSecondaryDate());
		   					   storedLogic.append(";");
		   					   break;
		case "Empty Form":     break; 
		default: // do nothing
		}
		System.out.println("Stored Logic:: "+storedLogic.toString());
		return storedLogic.toString();
	}
	 public DqJobRunStatistics getInputLogic(DqJobRunStatistics dqJobRunStatistics,DqJobRunStatistics _checkData) {
		  
		switch(dqJobRunStatistics.getDqCheck()) {
		case "Data Length":     _checkData.setVariable(dqJobRunStatistics.getSourceVariable());
			                    _checkData.setInput(dqJobRunStatistics.getCheckLength());
			                    _checkData.setDqCheck(dqJobRunStatistics.getDqCheck());
								break;
		
		case "Variable Present": 
		case "Not Null":
		case "Uniqueness": 	   _checkData.setVariable(dqJobRunStatistics.getSourceVariable());
		                       _checkData.setDqCheck(dqJobRunStatistics.getDqCheck());
							   break;
		case "Dependency":     _checkData.setVariable(dqJobRunStatistics.getIndependentVariable());
		                       _checkData.setInput(dqJobRunStatistics.getDependentVariable());
		                       _checkData.setInput2(dqJobRunStatistics.getDependency());
		                       _checkData.setDqCheck(dqJobRunStatistics.getDqCheck());
		                       break;
		case "Range":  		   _checkData.setVariable(dqJobRunStatistics.getSourceVariable());
		                       _checkData.setInput(dqJobRunStatistics.getLowerRange());
		                       _checkData.setInput2(dqJobRunStatistics.getUpperRange());
		                       _checkData.setDqCheck(dqJobRunStatistics.getDqCheck());
					           break;
		case "Chronological":  _checkData.setInput(dqJobRunStatistics.getInitialDate());
		                       _checkData.setInput2(dqJobRunStatistics.getSecondaryDate());
		                       _checkData.setDqCheck(dqJobRunStatistics.getDqCheck());
		                       //what has to be done with the variable coming from the UI
		   					   break;
		case "Empty Form":     break;
		default: // do nothing
		}
		System.out.println("Stored Logic:: "+_checkData.toString());
		return _checkData;
		//dqJobRunRepository.save(_checkData);
	}

	@Override
	public int updateStatus(Long uniqueId, String status) {
		return dqJobRunRepository.updateStatus(uniqueId,status); 
	}

	@Override
	public List<DqJobRunStatistics>  updateFormStatus(DqJobRunStatistics dqJob) {
		dqJobRunRepository.updateFormStatus(dqJob.getFormStatus(),dqJob.getForm(),dqJob.getStudy()); 
		
		//return updated list
		return getDqJobRunDetails(dqJob);

	}
	
	@Override
	public int deleteNotification(Integer id) {
		return notificationRepository.deleteNotification(id); 
	}
	
	@Override
	public int notificationStop(Integer id) {
		return notificationRepository.notificationStop(id); 
	}

	@Override
	public DqJobRunStatistics updateEditDependent(DqJobRunStatistics dqJobRunStatistics) {
	    DqJobRunStatistics matrix;
//	    DqJobRunStatistics template=new DqJobRunStatistics();
//	    DqJobRunStatistics template1=new DqJobRunStatistics();
	    matrix=dqJobRunRepository.findByUniqueId(dqJobRunStatistics.getUniqueId());
	    if(matrix!=null) {
	    	if(dqJobRunStatistics.getDependency()!=null)
	    	matrix.setDependency(dqJobRunStatistics.getDependency());
	    	if(dqJobRunStatistics.getDependentVariable()!=null)
	    	matrix.setDependentVariable(dqJobRunStatistics.getDependentVariable());
			return dqJobRunRepository.save(matrix);
		}
		return matrix;
	    
	}

	@Override
	public List<DqJobRunStatisticsDTO> getFormDependency() {
		return dqJobRunRepository.findByForm();
	}
}
