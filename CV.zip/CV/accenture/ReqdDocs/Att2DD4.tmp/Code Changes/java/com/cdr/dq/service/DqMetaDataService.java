package com.cdr.dq.service;

import java.util.List;
import java.util.Set;

import com.cdr.dq.model.CategoryCheckMetadata;
import com.cdr.dq.model.CategoryMetadata;
import com.cdr.dq.model.CheckMetadata;
import com.cdr.dq.model.DqJobRunStatistics;
import com.cdr.dq.model.DqJobStatusMetadata;
import com.cdr.dq.model.DqStatusMetadata;
import com.cdr.sdtm.model.FormMetaData;
import com.cdr.sdtm.model.FormMetaDataDTO;
import com.cdr.sdtm.model.FormVariableMetaDataDTO; 

public interface DqMetaDataService {
	 
	List<CategoryMetadata> getCategoryMetadata();
	
	List<CheckMetadata> getCheckMetadata(); 
	
	List<DqJobStatusMetadata> getDqJobStatusMetadata();
	
	List<DqStatusMetadata> getDqStatusMetadata();
	

	List<CategoryCheckMetadata> getCategoryCheckMetadata(); 
	
	public void sendEmail();

    List<String> getDqLibrary();

	List<DqJobRunStatistics> importLibrary(String form,String library,String study); 
	//int deleteMatricesByFormandLibrary(String study, String domain); 

	List<DqJobRunStatistics> savingRecords(List<DqJobRunStatistics> insert);

    int deleteMatricesByformAndstudy(String form, String study);
    
    List<FormMetaDataDTO> formMetadata();

	//List<FormVariableMetaData> formVariableMetadata();
	Set<FormVariableMetaDataDTO> formVariableMetadata();

	List<DqJobRunStatistics> getCheck(String form, String library, String study);

}
