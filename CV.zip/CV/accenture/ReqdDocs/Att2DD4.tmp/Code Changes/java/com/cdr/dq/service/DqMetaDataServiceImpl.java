package com.cdr.dq.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.cdr.config.util.ThymeLeafUtil;
import com.cdr.dq.model.CategoryCheckMetadata;
import com.cdr.dq.model.CategoryMetadata;
import com.cdr.dq.model.CheckMetadata;
import com.cdr.dq.model.DqJobRunStatistics;
import com.cdr.dq.model.DqJobStatusMetadata;
import com.cdr.dq.model.DqMatrix;
import com.cdr.dq.model.DqStatusMetadata;
import com.cdr.dq.repository.CategoryCheckRepository;
import com.cdr.dq.repository.CategoryRepository;
import com.cdr.dq.repository.CheckRepository;
import com.cdr.dq.repository.DqJobRunRepository;
import com.cdr.dq.repository.DqJobStatusRepository;
import com.cdr.dq.repository.DqMatrixRepository;
import com.cdr.dq.repository.DqStatusRepository;
import com.cdr.sdtm.model.FormMetaData;
import com.cdr.sdtm.model.FormMetaDataDTO;
import com.cdr.sdtm.model.FormVariableMetaDataDTO;
import com.cdr.sdtm.repository.FormMetadataRepository;
import com.cdr.sdtm.repository.FormVariableMetaDataRepository;

@Service
public class DqMetaDataServiceImpl implements DqMetaDataService {

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private CheckRepository checkRepository;

	@Autowired
	private DqJobStatusRepository dqJobStatusRepository; 

	@Autowired
	private DqStatusRepository dqStatusRepository;

	@Autowired
	private CategoryCheckRepository categoryCheckRepository;

	@Autowired
	private DqJobRunRepository jobRunRepository;

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private SpringTemplateEngine templateEngine;

	@Autowired
	private DqMatrixRepository dqMatrixRepository;

	@Autowired
	private FormMetadataRepository formMetaDataRepository;

	@Autowired
	private FormVariableMetaDataRepository formVariableMetaDataRepository;

	@Override
	public List<CategoryMetadata> getCategoryMetadata() {
		return categoryRepository.findAll();
	}

	@Override
	public List<CheckMetadata> getCheckMetadata() {
		return checkRepository.findAll();
	}

	@Override
	public List<DqJobStatusMetadata> getDqJobStatusMetadata() {
		return dqJobStatusRepository.findAll();
	}

	@Override
	public List<DqStatusMetadata> getDqStatusMetadata() {
		return dqStatusRepository.findAll();
	}

	@Override
	public List<CategoryCheckMetadata> getCategoryCheckMetadata() {
		return categoryCheckRepository.findAll(); 
	}


	@Override
	public void sendEmail() {
		List<DqJobRunStatistics> jobs = jobRunRepository.findFailedDqChecksByStudy("CALERIE");

		// Map model = new HashMap();
		// model.put(key, value)
		try {
			MimeMessage message = emailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message,
					MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			Map<String, Object> model = new HashMap<>();
			List<DqJobRunStatistics> failedCheckList = jobRunRepository.findByJobStatus("Not Started");
			model.put("failedChecks",failedCheckList);

			String html = ThymeLeafUtil.getProcessedHtml(model, "email-template");
			helper.setTo("mallikarjun09@gmail.com");
			helper.setText(html, true);
			helper.setSubject("Check Failed - Report");


			emailSender.send(message);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	@Override
	public List<String> getDqLibrary() {
		//return dqMatrixRepository.findAll(); 
		return dqMatrixRepository.findDistinctLibraries();
	}
	@Override
	public List<DqJobRunStatistics> savingRecords(List<DqJobRunStatistics> insert) {
		return jobRunRepository.saveAll(insert); 
	}

	@Override
	public List<DqJobRunStatistics> importLibrary(String form,String library,String study) {
		//DqMatrix objectm=null;
		DqJobRunStatistics obj=null;
		List<DqJobRunStatistics> insert=new ArrayList<DqJobRunStatistics>();
		List<DqJobRunStatistics> allMatrices=new ArrayList<DqJobRunStatistics>();
		List <DqMatrix> matrix = dqMatrixRepository.findByFormAndLibrary(form,library);
		System.out.println(matrix);
		List<DqJobRunStatistics> matrices = jobRunRepository.findByFormAndStudy(form,study);
		System.out.println(matrices);
		if(matrices != null && matrices.size() > 0) {
			int deleted = deleteMatricesByformAndstudy(form,study);
			System.out.println(deleteMatricesByformAndstudy(form,study));
			matrices = null;
		} 
		for(DqMatrix template :matrix)	
		{
			obj=new DqJobRunStatistics();
			obj.setCategory(template.getCategory());
			obj.setVariable(template.getVariable());
			obj.setDqCheck(template.getCheck());
			obj.setJobStatus(template.getDq_status());
			obj.setStudy(study);
			obj.setForm(template.getForm());
			insert.add(obj);
		}
		
		allMatrices.addAll(savingRecords(insert));
		System.out.println(allMatrices);
		return allMatrices;

	}

	@Override
	public int deleteMatricesByformAndstudy(String form, String study) {
		return jobRunRepository.deleteByFormAndStudy(form,study);
	}


	@Override
	public Set<FormVariableMetaDataDTO> formVariableMetadata(){
		Set<FormVariableMetaDataDTO> formVariableMetaDataDTOSet = null;
		formVariableMetaDataDTOSet = formVariableMetaDataRepository.findAllVariableAndDescription();
		System.out.println(formVariableMetaDataDTOSet.toString()+"9999");
		System.out.println("00000000");
		return formVariableMetaDataDTOSet;
	}  
	@Override
	public List<FormMetaDataDTO> formMetadata(){
//		List<FormMetaDataDTO> array=new ArrayList<FormMetaData>();
//		array=formMetaDataRepository.findFormAndDescription();
//		System.out.println(array);
		System.out.println(9999);
		return formMetaDataRepository.findFormAndDescription();
	}

	@Override
	public List<DqJobRunStatistics> getCheck(String form, String library, String study) {
		List<DqJobRunStatistics> findMatrices = jobRunRepository.findByFormAndStudy(form,study);
		return findMatrices;
	}

	
}
