package com.cdr.sdtm.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cdr.sdtm.model.DirectoryMetadataDTO;
import com.cdr.sdtm.model.SDTMTargerMetadataTabDTO;
import com.cdr.sdtm.model.SDTMVersionDomainDTO;
import com.cdr.sdtm.model.SourceMetadataTabDTO;
import com.cdr.sdtm.model.SourceTypeFilterDTO;
import com.cdr.sdtm.model.TransformationTemplateFilterParams;
import com.cdr.sdtm.model.TransformationTemplateTabDTO;
import com.cdr.sdtm.service.MetadataManagementService;


@CrossOrigin(value="*")
@RestController
@RequestMapping("/api/CDR/MetadataManagement")
public class MetadataManagementController {

	@Autowired
	private MetadataManagementService metadataManagementService;
	
	@PostMapping("/sdtmTargerMetadataTab")
	public SDTMTargerMetadataTabDTO getSDTMTargerMetadataTabDTO(@RequestBody SDTMVersionDomainDTO sdtmVersionDomainDTO) {
		return metadataManagementService.getSDTMTargerMetadataTabDTO(sdtmVersionDomainDTO);
	}
	
	@PostMapping("/sourceMetadataTab")
	public SourceMetadataTabDTO getSourceMetadataTabDTO(@RequestBody SourceTypeFilterDTO sourceTypeFilterDTO){
		return metadataManagementService.getSourceMetadataTabDTO(sourceTypeFilterDTO);
	}
	
	
	@PostMapping("/saveDirectoryTab")
	public void saveDirectory(@RequestBody DirectoryMetadataDTO directoryMetadataDTO) {
		 metadataManagementService.saveDirectory(directoryMetadataDTO);
	}
	
	@PostMapping("/uploadSourceMetadata")
	public void uploadSourceMetadata(@RequestParam("file") MultipartFile file)
			throws IOException{
		if (file.isEmpty()) {
			throw new RuntimeException("Uploaded excel sheet is empty");
		} else {
			File destination = File.createTempFile("sourceMetadata", ".tmp");
			file.transferTo(destination);
			metadataManagementService.saveSourceMetadata(destination.getPath());
			destination.delete();
		}
	}
	
	@PostMapping("/uploadSdtmTargetMetadata")
	public void uploadSdtmTargetMetadata(@RequestParam("file") MultipartFile file)
			throws IOException{
		if (file.isEmpty()) {
			throw new RuntimeException("Uploaded excel sheet is empty");
		} else {
			File destination = File.createTempFile("sourceMetadata", ".tmp");
			file.transferTo(destination);
			metadataManagementService.saveSdtmTargetMetadata(destination.getPath());
			destination.delete();
		}
	}

	@PostMapping("/transformationTemplateTab")
	TransformationTemplateTabDTO getTransformationTemplateTabDTO(@RequestBody TransformationTemplateFilterParams transformationTemplateFilterParams) {
		return metadataManagementService.getTransformationTemplateTabDTO(transformationTemplateFilterParams);
	}
	
}
