/**
 * 
 */
package com.cdr.sdtm.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdr.sdtm.model.Notification;
import com.cdr.sdtm.service.NotificationsService;

/**
 * @author twdas
 *
 */

@RestController
@RequestMapping("/api/CDR")
public class NotificationsController {

private static final Logger LOGGER = LoggerFactory.getLogger(NotificationsController.class);
	
	@Autowired
	NotificationsService notificationsService;
	

	@GetMapping("/notifications/find/studyIds/{studyIds}/{userRole}")
	public List<Notification> findByStudyIds(@PathVariable List<String> studyIds, @PathVariable("userRole") String userRole) {
		return notificationsService.findByStudyIds(studyIds, userRole);
	}

	@PostMapping("/notifications/create/{userRole}")
	public ResponseEntity<String> create(@RequestBody Notification notification,  @PathVariable("userRole") String userRole) {
		Notification newNotification = notificationsService.create(notification);
		if(newNotification != null) {
			LOGGER.info("Notification created successfully.");
			return new ResponseEntity<>("Notification has been created", HttpStatus.OK);
		} else {
			LOGGER.info("Error while creating notification.");
			return new ResponseEntity<>("Error while creation of notifications",HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping("/notifications/delete/id/{id}")
	public ResponseEntity<String> deleteNotifications(@PathVariable Integer id) {
		LOGGER.info("notifications to be removed for uniqueId " + id) ;
		int isUpdated = notificationsService.deleteNotifications(id);
		
		if(isUpdated > 0) {
			LOGGER.info("Notification deleted successfully.");
			return new ResponseEntity<>("Notification has been updated", HttpStatus.OK);
		}
		else {
			LOGGER.info("Error while updating delete details for notifications.");
			return new ResponseEntity<>("Notification not found", HttpStatus.NOT_FOUND); 
		}
	}
	
	@PutMapping("notifications/updateStatus/ids/{ids}")
	public ResponseEntity<String> updateNotificationStatus(@PathVariable List<Integer> ids,@RequestBody Notification notification) {
		LOGGER.info("notifications to be updated for uniqueIds " + ids.toString()) ;
		int isUpdated = notificationsService.updateNotificationStatus(ids);
		if(isUpdated > 0) {
			LOGGER.info("Notification updated successfully.");
			return new ResponseEntity<>("Notification has been updated", HttpStatus.OK);
		}
		else {
			LOGGER.info("Error while updating details for notifications.");
			return new ResponseEntity<>("Notification not found", HttpStatus.NOT_FOUND); 
		}
	}
	
	@PutMapping("notifications/updateStopStatus/id/{id}")
	public ResponseEntity<String> updateStopStatus(@PathVariable Integer id) {
		int isUpdated = notificationsService.updateStopStatus(id);
		if(isUpdated > 0) {
			LOGGER.info("Notification updated successfully.");
			return new ResponseEntity<>("Notification has been updated", HttpStatus.OK);
		}
		else {
			LOGGER.info("Error while updating details for notifications.");
			return new ResponseEntity<>("Notification not found", HttpStatus.NOT_FOUND); 
		}
	}

}
