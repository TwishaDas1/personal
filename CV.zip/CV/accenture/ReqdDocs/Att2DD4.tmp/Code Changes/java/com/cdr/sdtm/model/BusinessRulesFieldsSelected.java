package com.cdr.sdtm.model;

public class BusinessRulesFieldsSelected {
	
	String brStudy;
	String brVersion;
	String brSdtmDomain;
	String brDomainStatus;

	public String getBrStudy() {
		return brStudy;
	}
	public String getBrVersion() {
		return brVersion;
	}
	public String getBrSdtmDomain() {
		return brSdtmDomain;
	}
	public String getBrDomainStatus() {
		return brDomainStatus;
	}
	public void setBrStudy(String brStudy) {
		this.brStudy = brStudy;
	}
	public void setBrVersion(String brVersion) {
		this.brVersion = brVersion;
	}
	public void setBrSdtmDomain(String brSdtmDomain) {
		this.brSdtmDomain = brSdtmDomain;
	}
	public void setBrDomainStatus(String brDomainStatus) {
		this.brDomainStatus = brDomainStatus;
	}
	
}
