package com.cdr.sdtm.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name="database_environment")
@EqualsAndHashCode(of = { "id","dbServerName" }) 
public class DatabaseEnvironment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L; 

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="database_environment_id")
	private Long id; 
	
	@Column(name="db_server_name")
	private String dbServerName;
	
	@Column(name="description")
	private String description;
	
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "databaseEnvironment")
	private Set<DatabaseEnvironmentDetail> databaseEnvironmentDetails;
	
	}
