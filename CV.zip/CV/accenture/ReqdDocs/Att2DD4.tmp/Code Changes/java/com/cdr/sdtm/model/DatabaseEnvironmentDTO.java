package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class DatabaseEnvironmentDTO {

	private Long id; 
	
	private String dbServerName;
	
	private String description;
	
	private List<DatabaseEnvironmentDetailDTO> databaseEnvironmentDetailDTOs;
	
}
