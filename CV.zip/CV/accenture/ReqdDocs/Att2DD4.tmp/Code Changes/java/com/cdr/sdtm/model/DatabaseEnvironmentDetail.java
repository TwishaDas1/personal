package com.cdr.sdtm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name="database_environment_detail")
@EqualsAndHashCode(of = { "id","environmentType" }) 
public class DatabaseEnvironmentDetail implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L; 

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="database_environment_detail_id")
	private Long id; 
	
	@Column(name="environment_type")
	private String environmentType;
	
	@Column(name="database_name")
	private String databaseName;

	@Column(name="port_name")
	private String portName;

	@Column(name="host_name")
	private String hostName;

	@Column(name="schema_name")
	private String schemaName;
	
	@ManyToOne(fetch = FetchType.EAGER, targetEntity = DatabaseEnvironment.class)
    @JoinColumn(name = "database_environment_id", nullable = false)
    @OnDelete(action = OnDeleteAction.CASCADE)
	private DatabaseEnvironment databaseEnvironment;
	
}
