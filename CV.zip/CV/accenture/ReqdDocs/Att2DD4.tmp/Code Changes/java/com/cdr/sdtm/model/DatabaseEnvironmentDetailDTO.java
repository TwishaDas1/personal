package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class DatabaseEnvironmentDetailDTO {

	private Long id; 
	
	private String environmentType;
	
	private String databaseName;

	private String portName;

	private String hostName;

	private String schemaName;
	
}
