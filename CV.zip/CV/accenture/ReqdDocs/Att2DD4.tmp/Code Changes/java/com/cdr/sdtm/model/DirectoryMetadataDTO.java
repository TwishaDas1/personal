package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class DirectoryMetadataDTO {

	private ServerEnvironmentDTO serverEnvironmentDTO;
	
	private DatabaseEnvironmentDTO databaseEnvironmentDTO;
	
}
