package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class DomainFilterDTO implements Comparable<DomainFilterDTO>{
	
	private String domain;
	
	private String domainDescription;

	@Override
	public int compareTo(DomainFilterDTO domainFilterDTO) {
		return this.domainDescription.compareTo(domainFilterDTO.getDomainDescription());
	}
	
	

}
