package com.cdr.sdtm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="SDTM_Domain_Metadata")
@Table(name="SDTM_Domain_Metadata") 
public class DomainMetadata {
	
	@Id
	@Column(name="Domain_Name")
	private String domains;
	
	@Column(name="Domain_Description")
	private String description;
	
	@Column(name="Class")
	private String classVar;

	@Column(name="Structure")
	private String structure;
	
	@Column(name="Purpose")
	private String purpose;
	
	@Column(name="Keys")
	private String keys;
	
	@Column(name="Location")
	private String location;
	
	@Column(name="Version")
	private String version;

	public String getDomains() {
		return domains;
	}

	public void setDomains(String domains) {
		this.domains = domains;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStructure() {
		return structure;
	}

	public void setStructure(String structure) {
		this.structure = structure;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getKeys() {
		return keys;
	}

	public void setKeys(String keys) {
		this.keys = keys;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getClassVar() {
		return classVar;
	}

	public void setClassVar(String classVar) {
		this.classVar = classVar;
	}
}
