package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class DomainTransformationTemplateDTO implements Comparable<DomainTransformationTemplateDTO>{

	private String domain;
	
	private String domainDescription;
	
	private String sourceFiles;
	
	private List<JoinConditionTransformationTemplateDTO> joinConditionTransformationTemplateDTOs;
	
	private List<VarLvlTransformationTemplateDTO> varLvlTransformationTemplateDTOs;

	@Override
	public int compareTo(DomainTransformationTemplateDTO domainTransformationTemplateDTO) {
		return this.domain.compareTo(domainTransformationTemplateDTO.getDomain());
	}
	
}
