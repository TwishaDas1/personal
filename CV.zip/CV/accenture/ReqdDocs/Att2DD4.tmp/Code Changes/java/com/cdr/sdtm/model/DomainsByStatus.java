package com.cdr.sdtm.model;

import java.util.List;

public class DomainsByStatus {
	
	private List<Domain> inProgress;
	private List<Domain> readyForReview;
	private List<Domain> rejected;
	private List<Domain> notStarted;
	private List<Domain> approved;
	
	public List<Domain> getInProgress() {
		return inProgress;
	}
	public List<Domain> getReadyForReview() {
		return readyForReview;
	}
	public List<Domain> getRejected() {
		return rejected;
	}
	public List<Domain> getNotStarted() {
		return notStarted;
	}
	public List<Domain> getApproved() {
		return approved;
	}
	public void setInProgress(List<Domain> inProgress) {
		this.inProgress = inProgress;
	}
	public void setReadyForReview(List<Domain> readyForReview) {
		this.readyForReview = readyForReview;
	}
	public void setRejected(List<Domain> rejected) {
		this.rejected = rejected;
	}
	public void setNotStarted(List<Domain> notStarted) {
		this.notStarted = notStarted;
	}
	public void setApproved(List<Domain> approved) {
		this.approved = approved;
	}

}
