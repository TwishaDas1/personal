package com.cdr.sdtm.model;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="Form_Metadata")
public class FormMetaData {

	
	@EmbeddedId
	public FormMetaDataId id;
	
	
	@Column(name="Form_Description")
	public String formDescription;
	
	public String getFormName() {
		return this.id.formName;
	}

	
	public String getFormSource() {
		return this.id.formSource;
	}

	
}
