package com.cdr.sdtm.model;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FormMetaDataDTO implements Serializable , Comparable<FormMetaDataDTO>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String formName;
	
	private String formDescription;
	
	
	public FormMetaDataDTO() {}
	
	public FormMetaDataDTO(String formName, String formDescription) {
		this.formName=formName;
		this.formDescription=formDescription;
	}
	
	private List<FormVariableMetaDataDTO> formVariableMetaDataDTOs;

	@Override
	public int compareTo(FormMetaDataDTO formMetaDataDTO) {
		return this.formName.compareTo(formMetaDataDTO.getFormName());
	}
	
}
