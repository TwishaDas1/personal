package com.cdr.sdtm.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@AllArgsConstructor 
@EqualsAndHashCode(of = {"formVariableName","formName","formDescription"})
@JsonAutoDetect(fieldVisibility = Visibility.ANY)
public class FormVariableMetaDataDTO implements Comparable<FormVariableMetaDataDTO>{

	/**
	 * 
	 */
 
	 
	private String formType;
	
	private String formName;
	
	private String formDescription;
	
	private String formVariableName;
	
	private String formVariableDescription;
	
	public FormVariableMetaDataDTO() {
		
	}
	public FormVariableMetaDataDTO(String formVariableName,String formName,String formDescription,String formVariableDescription){
		this.formVariableName = formVariableName;
		this.formName = formName;
		this.formDescription = formDescription;
		this.formVariableDescription = formVariableDescription;
	}
	@Override
	public int compareTo(FormVariableMetaDataDTO formVariableMetaDataDTO) {
		return this.formVariableName.compareTo(formVariableMetaDataDTO.getFormVariableName());
	}
	
}
