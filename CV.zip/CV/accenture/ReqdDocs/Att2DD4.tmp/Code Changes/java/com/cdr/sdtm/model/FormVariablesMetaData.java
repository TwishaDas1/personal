//package com.cdr.sdtm.model;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity(name="Form_Variable_Metadata")
//@Table(name="Form_Variable_Metadata")
//public class FormVariablesMetaData {
//	
//	@Id
//	@Column(name="Form_Type")
//	private String formId;
//	
//	@Column(name="Form_Name")
//	private String formName;
//	
//	@Column(name="Form_Description")
//	private String formDesc; 
//	
//	@Column(name="Form_Variable_Name")
//	private String fieldName;
//	
//	@Column(name="Form_Variable_Description")
//	private String fieldDesc;
//	
//
//	public String getFormId() {
//		return formId;
//	}
//
//	public String getFormName() {
//		return formName;
//	}
//
//	public String getFormDesc() {
//		return formDesc;
//	}
//
//	public String getFieldName() {
//		return fieldName;
//	}
//
//	public String getFieldDesc() {
//		return fieldDesc;
//	}
//
//	public void setFormId(String formId) {
//		this.formId = formId;
//	}
//
//	public void setFormName(String formName) {
//		this.formName = formName;
//	}
//
//	public void setFormDesc(String formDesc) {
//		this.formDesc = formDesc;
//	}
//
//	public void setFieldName(String fieldName) {
//		this.fieldName = fieldName;
//	}
//
//	public void setFieldDesc(String fieldDesc) {
//		this.fieldDesc = fieldDesc;
//	}
//
//	
//	
//
//}
package com.cdr.sdtm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name="Form_Variable_Metadata")
@EqualsAndHashCode(of = { "formType","formName","formVariableName" }) 
public class FormVariablesMetaData implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@EmbeddedId
	public FormVariablesMetaDataId id;
	
	@Column(name="Form_Type")
	public String formType;
	
	@Column(name="Form_Description")
	public String formDescription;
	
	@Column(name="Form_Variable_Description")
	public String formVariableDescription;
	
	@Column(name="Form_Variable_Example")
	public String formVariableExample;
	
	public String getFormName() {
		return this.id.formName;
	}
	

}
