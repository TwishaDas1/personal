package com.cdr.sdtm.model;

import java.io.Serializable;

import javax.persistence.Column;

import lombok.Data;

@Data
public class FormVariablesMetaDataId implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name="Form_Name")
    public String formName;
	
	@Column(name="Form_Variable_Name")
	public String formVariableName;
}
