package com.cdr.sdtm.model;

public class GenericMessage {
	
	private String successMessage;
	private String failureMessage;
	
	public String getSuccessMessage() {
		return successMessage;
	}
	public String getFailureMessage() {
		return failureMessage;
	}
	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}
	public void setFailureMessage(String failureMessage) {
		this.failureMessage = failureMessage;
	}

	

}
