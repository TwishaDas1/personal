package com.cdr.sdtm.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity(name="Job_Run_Statistics")
@Table(name="Job_Run_Statistics")
public class JobRunStatus {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Unique_ID")
	private Long job_id;
	
	@Column(name="Study_Title")
	private String study;
	
	@Column(name="Domain_Name")
	private String domain;
	
	@Column(name="Job_Status")
	private String job_status;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name="Job_Start_Timestamp")
	private Timestamp job_start_timestamp;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	@Column(name="Job_End_Timestamp")
	private Timestamp job_end_timestamp;
	
	@Column(name="Message")
	private String message;
	
	@Column(name="Job_Enablement_Status")
	private String jobDisabled;
	
	@Column(name="Version")
	private String jobVersion;
	
	@Column(name="Baseline_Name")
	private String jobBaselineName;
	
	
	public String getJobDisabled() {
		return jobDisabled;
	}

	public void setJobDisabled(String jobDisabled) {
		this.jobDisabled = jobDisabled;
	}

	public Long getJob_id() {
		return job_id;
	}

	public void setJob_id(Long job_id) {
		this.job_id = job_id;
	}

	public String getStudy() {
		return study;
	}

	public void setStudy(String study) {
		this.study = study;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getJob_status() {
		return job_status;
	}

	public void setJob_status(String job_status) {
		this.job_status = job_status;
	}

	public Timestamp getJob_start_timestamp() {
		return job_start_timestamp;
	}

	public void setJob_start_timestamp(Timestamp job_start_timestamp) {
		this.job_start_timestamp = job_start_timestamp;
	}

	public Timestamp getJob_end_timestamp() {
		return job_end_timestamp;
	}

	public void setJob_end_timestamp(Timestamp job_end_timestamp) {
		this.job_end_timestamp = job_end_timestamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getJobVersion() {
		return jobVersion;
	}

	public String getJobBaselineName() {
		return jobBaselineName;
	}

	public void setJobVersion(String jobVersion) {
		this.jobVersion = jobVersion;
	}

	public void setJobBaselineName(String jobBaselineName) {
		this.jobBaselineName = jobBaselineName;
	}

	
	
}
