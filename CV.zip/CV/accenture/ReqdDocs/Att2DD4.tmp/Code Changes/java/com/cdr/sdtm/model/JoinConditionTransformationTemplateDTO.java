package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class JoinConditionTransformationTemplateDTO {

	private String formAName;

	private String formADescription;

	private String formBName;

	private String formBDescription;

	private String joinType;

	private String joinCriteria;
	
}
