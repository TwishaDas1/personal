package com.cdr.sdtm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="SDTM_Join_Matrix")
@Table(name="SDTM_Join_Matrix") 
public class JoinMatrix {
	
	@Id
	@Column(name="Study_Title")
	private String studyTitle;
	
	@Column(name="Domain_Name")
	private String domainName;
	
	@Column(name="Sub_Domain_Description")
	private String subDomainDescription;

	@Column(name="Form_Name_A")
	private String formNameA;
	
	@Column(name="Form_Name_B")
	private String formNameB;
	
	@Column(name="Join_Type")
	private String joinType;
	
	@Column(name="Join_Criteria")
	private String joinCriteria;
	
	@Column(name="Version")
	private String version;
	
	@Column(name="Baseline_Name")
	private String baselineName;

	
	public String getStudyTitle() {
		return studyTitle;
	}

	public String getDomainName() {
		return domainName;
	}

	public String getSubDomainDescription() {
		return subDomainDescription;
	}

	public String getFormNameA() {
		return formNameA;
	}

	public String getFormNameB() {
		return formNameB;
	}

	public String getJoinType() {
		return joinType;
	}

	public String getJoinCriteria() {
		return joinCriteria;
	}

	public String getVersion() {
		return version;
	}

	public String getBaselineName() {
		return baselineName;
	}

	public void setStudyTitle(String studyTitle) {
		this.studyTitle = studyTitle;
	}

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public void setSubDomainDescription(String subDomainDescription) {
		this.subDomainDescription = subDomainDescription;
	}

	public void setFormNameA(String formNameA) {
		this.formNameA = formNameA;
	}

	public void setFormNameB(String formNameB) {
		this.formNameB = formNameB;
	}

	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}

	public void setJoinCriteria(String joinCriteria) {
		this.joinCriteria = joinCriteria;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public void setBaselineName(String baselineName) {
		this.baselineName = baselineName;
	}


	
}
