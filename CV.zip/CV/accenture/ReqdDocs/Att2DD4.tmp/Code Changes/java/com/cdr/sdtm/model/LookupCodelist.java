/**
 * 
 */
package com.cdr.sdtm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author twdas
 *
 */
@Entity(name="Lookup_Codelist")
@Table(name="Lookup_Codelist")
public class LookupCodelist {

	@Column(name="lookup_type")
	private Long lookupType; 
	@Id
	@Column(name="code")
	private String code;
	@Column(name="description")
	private String description;



	public Long getLookupType() {
		return lookupType;
	}

	public void setLookupType(Long lookupType) {
		this.lookupType = lookupType;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


}
