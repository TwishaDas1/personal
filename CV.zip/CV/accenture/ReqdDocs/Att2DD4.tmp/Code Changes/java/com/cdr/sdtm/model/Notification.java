/**
 * 
 */
package com.cdr.sdtm.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * @author twdas
 *
 */

@Entity(name="Notification")
@Table(name="Notification")
public class Notification {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Notification_ID")
	private int id;
	
	@Column(name="Study_ID")
	private String studyID;
	
	@Column(name="Notification_Description")
	private String notification_desc;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@Column(name="Create_Date")
	private LocalDateTime create_dt;

	@Column(name="Delete_Flag")
	private String notification_delete;
	
	@Column(name="Stop_Flag")
	private String notification_stop;
	
	@Column(name="Task_Description")
	private String task_desc;
	
	@Column(name="Task_Due_Date")
	private LocalDateTime task_due_date;
	
	@Column(name="Task_Complete_Flag")
	private String task_complete;
	
	@Column(name="User_Role")
	private String userRole;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@Column(name="Task_Completion_Date")
	private LocalDateTime taskCompletionDate;
	
	
	public int getId() {
		return id;
	}

	public String getStudyID() {
		return studyID;
	}

	public String getNotification_desc() {
		return notification_desc;
	}

	public LocalDateTime getCreate_dt() {
		return create_dt;
	}

	public String getNotification_delete() {
		return notification_delete;
	}

	public String getNotification_stop() {
		return notification_stop;
	}

	public String getTask_desc() {
		return task_desc;
	}

	public LocalDateTime getTask_due_date() {
		return task_due_date;
	}

	public String getTask_complete() {
		return task_complete;
	}

	public String getUserRole() {
		return userRole;
	}

	public LocalDateTime getTaskCompletionDate() {
		return taskCompletionDate;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setStudyID(String studyID) {
		this.studyID = studyID;
	}

	public void setNotification_desc(String notification_desc) {
		this.notification_desc = notification_desc;
	}

	public void setCreate_dt(LocalDateTime create_dt) {
		this.create_dt = create_dt;
	}

	public void setNotification_delete(String notification_delete) {
		this.notification_delete = notification_delete;
	}

	public void setNotification_stop(String notification_stop) {
		this.notification_stop = notification_stop;
	}

	public void setTask_desc(String task_desc) {
		this.task_desc = task_desc;
	}

	public void setTask_due_date(LocalDateTime task_due_date) {
		this.task_due_date = task_due_date;
	}

	public void setTask_complete(String task_complete) {
		this.task_complete = task_complete;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public void setTaskCompletionDate(LocalDateTime taskCompletionDate) {
		this.taskCompletionDate = taskCompletionDate;
	}

}
