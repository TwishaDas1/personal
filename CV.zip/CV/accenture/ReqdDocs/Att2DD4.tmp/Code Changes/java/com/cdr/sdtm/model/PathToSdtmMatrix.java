package com.cdr.sdtm.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@SqlResultSetMapping(
        name = "pathToSdtmMatrixDTOMapping",
        classes = {
                @ConstructorResult(
                        targetClass = PathToSdtmMatrixDTO.class,
                        columns = {
                        		@ColumnResult(name = "pathtosdtm0_.Matrix_ID",type = Long.class),
                        		@ColumnResult(name = "pathtosdtm0_.Study_Title",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Domain_Name",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Domain_Description",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Domain_Name_Extension",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Sub_Domain_Description",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Form_Name",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Form_Description",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Form_Name_Extension",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Form_Variable_Name",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Form_Variable_Description",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.SDTM_Variable_Name",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.SDTM_Variable_Description",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Join_Criteria",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Transformation_Type",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Transformation_Pseudo_Code",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Transformation_Code",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Domain_Status",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Initial_Creation_Date",type = Date.class),
                        		@ColumnResult(name = "pathtosdtm0_.Update_Date",type = Date.class),
                        		@ColumnResult(name = "pathtosdtm0_.Flag",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Notes",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Version",type = String.class),
                        		@ColumnResult(name = "pathtosdtm0_.Baseline_Name",type = String.class),
                        		@ColumnResult(name = "study1_.Therapeutic_Area",type = String.class),
                        		@ColumnResult(name = "study1_.Study_Source",type = String.class)
                            }
		)
        }
)	
@Entity
@Table(name="Path_To_SDTM_Matrix")
public class PathToSdtmMatrix {
	
	public PathToSdtmMatrix() {
		
	}

	public PathToSdtmMatrix(String studyID, String domain) {
		this.study = studyID;
		this.domain = domain;
	}
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Matrix_ID")
	private Long id; 
	
	@Column(name="Study_Title")
	private String study;
	
	@Column(name="Domain_Name")
	private String domain;
	
	@Column(name="Domain_Description")
	private String domainLabel;
	
	@Column(name="Domain_Name_Extension")
	private String domainNameExt;

	@Column(name="Sub_Domain_Description")
	private String subDomain;
	
	@Column(name="Form_Name")
	private String formName;
	
	@Column(name="Form_Description")
	private String formLable;
	
	@Column(name="Form_Name_Extension")
	private String formExt;
	
	@Column(name="Form_Variable_Name")
	private String sourceFile;
	
	@Column(name="Form_Variable_Description")
	private String sourceField;
	
	@Column(name="SDTM_Variable_Name")
	private String targetFile;
	
	@Column(name="SDTM_Variable_Description")
	private String targetField;
	
	@Column(name="Join_Criteria")
	private String joinLogic;
	
	@Column(name="Transformation_Type")
	private String transformation_type;
	
	@Column(name="Transformation_Pseudo_Code")
	private String transformation_logic;
	
	@Column(name="Transformation_Code")
	private String back_transformation_logic;
	
	@Column(name="Domain_Status")
	private String domainStatus;
	
	@Temporal(TemporalType.DATE)
	@Column(name="Initial_Creation_Date", updatable=false)
	private Date initialCreationDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="Update_Date", insertable=false)
	private Date updateDate;
	
	@Column(name="Flag")
	private String ruleFlag;
	
	@Column(name="Notes")
	private String notes;
	
	@Column(name="Version")
	private String businessRuleVersion;
	
	@Column(name="Baseline_Name")
	private String baselineName;
	
/*	@Column(name="CUSTOM_CODE")
	public String customCode;
	
	@Column(name="DATE_FOR_COMPUTATION")
    public String dateForComputation;
	
	@Column(name="OPERATION")
    public String operation;*/
	
/*	@Column(name="CONCAT_LOGIC")
    public String concatLogic;*/
	
	/*@Column(name="ADD_VAR")
    public String addVar;*/
	
	public Long getId() {
		return id;
	}

	public String getStudy() {
		return study;
	}

	public String getDomain() {
		return domain;
	}

	public String getDomainLabel() {
		return domainLabel;
	}

	public String getDomainNameExt() {
		return domainNameExt;
	}

	public String getSubDomain() {
		return subDomain;
	}

	public String getFormName() {
		return formName;
	}

	public String getFormLable() {
		return formLable;
	}

	public String getFormExt() {
		return formExt;
	}

	public String getSourceFile() {
		return sourceFile;
	}

	public String getSourceField() {
		return sourceField;
	}

	public String getTargetFile() {
		return targetFile;
	}

	public String getTargetField() {
		return targetField;
	}

	public String getJoinLogic() {
		return joinLogic;
	}

	public String getTransformation_type() {
		return transformation_type;
	}

	public String getTransformation_logic() {
		return transformation_logic;
	}

	public String getBack_transformation_logic() {
		return back_transformation_logic;
	}

	public String getDomainStatus() {
		return domainStatus;
	}

	public Date getInitialCreationDate() {
		return initialCreationDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public String getRuleFlag() {
		return ruleFlag;
	}

	public String getNotes() {
		return notes;
	}

	public String getBusinessRuleVersion() {
		return businessRuleVersion;
	}

	public String getBaselineName() {
		return baselineName;
	}

/*	public String getCustomCode() {
		return customCode;
	}

	public String getDateForComputation() {
		return dateForComputation;
	}

	public String getOperation() {
		return operation;
	}
*/
	/*public String getConcatLogic() {
		return concatLogic;
	}
*/
	/*public String getAddVar() {
		return addVar;
	}
*/
	public void setId(Long id) {
		this.id = id;
	}

	public void setStudy(String study) {
		this.study = study;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public void setDomainLabel(String domainLabel) {
		this.domainLabel = domainLabel;
	}

	public void setDomainNameExt(String domainNameExt) {
		this.domainNameExt = domainNameExt;
	}

	public void setSubDomain(String subDomain) {
		this.subDomain = subDomain;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public void setFormLable(String formLable) {
		this.formLable = formLable;
	}

	public void setFormExt(String formExt) {
		this.formExt = formExt;
	}

	public void setSourceFile(String sourceFile) {
		this.sourceFile = sourceFile;
	}

	public void setSourceField(String sourceField) {
		this.sourceField = sourceField;
	}

	public void setTargetFile(String targetFile) {
		this.targetFile = targetFile;
	}

	public void setTargetField(String targetField) {
		this.targetField = targetField;
	}

	public void setJoinLogic(String joinLogic) {
		this.joinLogic = joinLogic;
	}

	public void setTransformation_type(String transformation_type) {
		this.transformation_type = transformation_type;
	}

	public void setTransformation_logic(String transformation_logic) {
		this.transformation_logic = transformation_logic;
	}

	public void setBack_transformation_logic(String back_transformation_logic) {
		this.back_transformation_logic = back_transformation_logic;
	}

	public void setDomainStatus(String domainStatus) {
		this.domainStatus = domainStatus;
	}

	public void setInitialCreationDate(Date initialCreationDate) {
		this.initialCreationDate = initialCreationDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public void setRuleFlag(String ruleFlag) {
		this.ruleFlag = ruleFlag;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public void setBusinessRuleVersion(String businessRuleVersion) {
		this.businessRuleVersion = businessRuleVersion;
	}

	public void setBaselineName(String baselineName) {
		this.baselineName = baselineName;
	}

/*	public void setCustomCode(String customCode) {
		this.customCode = customCode;
	}

	public void setDateForComputation(String dateForComputation) {
		this.dateForComputation = dateForComputation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}*/

/*	public void setConcatLogic(String concatLogic) {
		this.concatLogic = concatLogic;
	}*/

	/*public void setAddVar(String addVar) {
		this.addVar = addVar;
	}*/

	
	
	
}
