package com.cdr.sdtm.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PathToSdtmMatrixDTO {
	
	private Long id; 
	
	private String study;
	
	private String domain;
	
	private String domainLabel;
	
	private String domainNameExt;

	private String subDomain;
	
	private String formName;
	
	private String formLable;
	
	private String formExt;
	
	private String sourceFile;
	
	private String sourceField;
	
	private String targetFile;
	
	private String targetField;
	
	private String joinLogic;
	
	private String transformation_type;
	
	private String transformation_logic;
	
	private String back_transformation_logic;
	
	private String domainStatus;
	
	private Date initialCreationDate;
	
	private Date updateDate;
	
	private String ruleFlag;
	
	private String notes;
	
	private String businessRuleVersion;
	
	private String baselineName;
	
	private String therapeuticArea;
	
	private String source;

}
