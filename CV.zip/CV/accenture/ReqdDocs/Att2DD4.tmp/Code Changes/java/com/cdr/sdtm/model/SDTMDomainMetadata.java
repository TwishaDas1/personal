package com.cdr.sdtm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="SDTM_Domain_Metadata") 
public class SDTMDomainMetadata implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private SDTMDomainMetadataId id;

	
	@Column(name="domain_description")
	private String description;
	
	@Column(name="class")
	private String clazz;
	
	@Column(name="structure")
	private String structure;
	
	@Column(name="purpose")
	private String purpose;
	
	@Column(name="domain_key")
	private String keys;
	
	@Column(name="location")
	private String location;
	
	@Column(name="Domain_Name_Extension")
	private String domainNameExtension;
	
}
