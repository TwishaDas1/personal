package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class SDTMDomainMetadataDTO implements Comparable<SDTMDomainMetadataDTO>{

	private String domainName;
	
	private String description;
	
	private String clazz;
	
	private String structure;
	
	private String purpose;
	
	private String keys;
	
	private String location;
	
	private String version;
	
	private String domainNameExtension;
	
	List<SDTMVariableMetadataDTO> sdtmVariableMetadataDTOs;

	@Override
	public int compareTo(SDTMDomainMetadataDTO sDTMDomainMetadataDTO) {
	return this.domainName.compareTo(sDTMDomainMetadataDTO.getDomainName());
	}

}
