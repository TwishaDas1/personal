package com.cdr.sdtm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Embeddable
@EqualsAndHashCode
public class SDTMDomainMetadataId implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Column(name="domain_name")
	private String domainName;
	
	@Column(name="version")
	private String version;
 
}
