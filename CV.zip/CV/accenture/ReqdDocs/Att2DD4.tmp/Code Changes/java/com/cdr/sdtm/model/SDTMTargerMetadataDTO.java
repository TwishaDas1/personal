package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class SDTMTargerMetadataDTO {

	private String version;
	
	private List<SDTMDomainMetadataDTO> sdtmDomainMetadataDTOs;
	
}
