package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class SDTMTargerMetadataTabDTO {
	
	private List<SDTMVersionDomainDTO> sdtmVersionDomainDTOs;

	private List<SDTMTargerMetadataDTO> sdtmTargerMetadataDTOs;
}
