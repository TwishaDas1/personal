package com.cdr.sdtm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name="SDTM_Variable_Metadata")
@EqualsAndHashCode(of = { "id","domainDescription"}) 
public class SDTMVariableMetadata implements Serializable{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private SDTMVariableMetadataId id;
	
	@Column(name="Domain_Description")
	private String domainDescription;
	
	
	@Column(name="SDTM_Variable_Description")
	private String sdtmVariableDescription;
	
	@Column(name="Type")
	private String type;
	
	@Column(name="Controlled_Terms_Codelist_Format")
	private String controlledTermsCodelistFormat;
	
	@Column(name="Role")
	private String role;
	
	@Column(name="CDSIC_Notes")
	private String cdsicNotes;
	
	@Column(name="Core")
	private String core;
	
}
