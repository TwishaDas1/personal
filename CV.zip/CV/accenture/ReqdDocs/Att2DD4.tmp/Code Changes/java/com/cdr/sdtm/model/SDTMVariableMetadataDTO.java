package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class SDTMVariableMetadataDTO implements Comparable<SDTMVariableMetadataDTO> {

	private String domainName;
	
	private String domainDescription;
	
	private String sdtmVariableName; 
	
	private String sdtmVariableDescription;
	
	private String type;
	
	private String controlledTermsCodelistFormat;
	
	private String role;
	
	private String cdsicNotes;
	
	private String core;
	
	private String version;

	@Override
	public int compareTo(SDTMVariableMetadataDTO sDTMVariableMetadataDTO) {
		return this.sdtmVariableName.compareTo(sDTMVariableMetadataDTO.getSdtmVariableName());
	}
	
}
