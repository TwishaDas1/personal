package com.cdr.sdtm.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Embeddable
@EqualsAndHashCode(of = { "domainName","sdtmVariableName","version"}) 
public class SDTMVariableMetadataId implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Column(name="Domain_Name")
	private String domainName;
	
	@Column(name="SDTM_Variable_Name")
	private String sdtmVariableName;
	
	@Column(name="Version")
	private String version;
}
