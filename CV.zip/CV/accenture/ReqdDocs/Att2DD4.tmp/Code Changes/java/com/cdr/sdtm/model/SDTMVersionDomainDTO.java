package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class SDTMVersionDomainDTO {
	
	private List<String> version;
	
	private List<DomainFilterDTO> domainDTO;

}
