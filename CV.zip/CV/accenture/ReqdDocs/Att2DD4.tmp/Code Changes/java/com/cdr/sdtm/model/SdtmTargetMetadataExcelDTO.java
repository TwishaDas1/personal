package com.cdr.sdtm.model;

import java.io.Serializable;

import org.apache.poi.ss.usermodel.Row;

import lombok.Data;

@Data
public class SdtmTargetMetadataExcelDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String sdtmTargetMetadataKey;	
	
	private String domainName;
	
	private String description;
	
	private String version;
	
	private String clazz;
	
	private String structure;
	
	private String purpose;
	
	private String keys;
	
	private String location;
	
	private String domainNameExtension;
	
	private String sdtmVariableName; 
	
	private String sdtmVariableDescription;
	
	private String type;
	
	private String controlledTermsCodelistFormat;
	
	private String role;
	
	private String cdsicNotes;
	
	private String core;
	
	public String getSdtmTargetMetadataKey() {
		this.sdtmTargetMetadataKey = this.domainName + this.version;
		return sdtmTargetMetadataKey;
	}
	
	public void assignSdtmTargetMetadataExcelDTO(Row row) {
		domainName = row.getCell(0).toString();
		description = row.getCell(1).toString();
		version = row.getCell(2).toString();
		clazz = row.getCell(3).toString();
		structure = row.getCell(4).toString();
		purpose = row.getCell(5).toString();
		keys = row.getCell(6).toString();
		location = row.getCell(7).toString();
		sdtmVariableName = row.getCell(8).toString();
		sdtmVariableDescription = row.getCell(9).toString();
		type = row.getCell(10).toString();
		controlledTermsCodelistFormat = row.getCell(11).toString();
		role = row.getCell(12).toString();
		cdsicNotes = row.getCell(13).toString();
		core = row.getCell(14).toString();
	}

}
