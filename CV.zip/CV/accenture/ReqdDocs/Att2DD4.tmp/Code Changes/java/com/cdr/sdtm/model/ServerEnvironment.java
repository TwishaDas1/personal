package com.cdr.sdtm.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@Entity
@Table(name="server_environment")
@EqualsAndHashCode(of = { "id","serverName" }) 
public class ServerEnvironment implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L; 
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="server_environment_id")
	private Long id; 
	
	@Column(name="server_name")
	private String serverName;
	
	@Column(name="description")
	private String description;
	
	@OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "serverEnvironment")
	private Set<ServerEnvironmentDetail> serverEnvironmentDetails;
	
}
