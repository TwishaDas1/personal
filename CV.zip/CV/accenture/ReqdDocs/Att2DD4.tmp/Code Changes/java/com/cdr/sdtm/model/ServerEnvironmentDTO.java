package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class ServerEnvironmentDTO {

	private Long id; 
	
	private String serverName;
	
	private String description;
	
	private List<ServerEnvironmentDetailDTO> serverEnvironmentDetailDTOs;
}
