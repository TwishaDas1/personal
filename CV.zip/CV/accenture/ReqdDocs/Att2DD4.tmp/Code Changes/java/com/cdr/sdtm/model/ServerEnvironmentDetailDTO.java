package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class ServerEnvironmentDetailDTO {

	private Long id; 
	
	private String environmentType;
	
	private String rootDirectoryName;
	
	private String sourceFileDirectoryName;

	private String regionName;
		
	private String sourceFileLandingLocation;
		
	private String sdtmDirectoryName;
	
}
	