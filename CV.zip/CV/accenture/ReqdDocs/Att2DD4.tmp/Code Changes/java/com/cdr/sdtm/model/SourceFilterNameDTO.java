package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class SourceFilterNameDTO implements Comparable<SourceFilterNameDTO> {
	
	private String sourceName;
	
	private String sourceDescription;

	@Override
	public int compareTo(SourceFilterNameDTO sourceFilterNameDTO) {
		return this.sourceDescription.compareTo(sourceFilterNameDTO.getSourceDescription());
	}

}
