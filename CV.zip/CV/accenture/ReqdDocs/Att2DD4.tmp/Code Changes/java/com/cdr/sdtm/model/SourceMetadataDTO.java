package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class SourceMetadataDTO {

	private String sourceType;
	
	private List<FormMetaDataDTO> formMetaDataDTOs; 
}
