package com.cdr.sdtm.model;

import java.io.Serializable;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;

import lombok.Data;

@Data
public class SourceMetadataExcelDTO implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	private String formMetadataKey;
	
	private String formType;

	private String formName;
	
	private String formDescription;

	private String formVariableName;
	
	private String formVariableDescription;
	
	private String formVariableExample;
	
	public String getFormMetadataKey() {
		this.formMetadataKey = this.formName + this.formType;
		return formMetadataKey;
	}
	
	public void assignSourceMetadataExcelDTO(Row row) {
		formType = row.getCell(0).toString();
		formName = row.getCell(1).toString();
		formDescription = row.getCell(2).toString();
		formVariableName = row.getCell(3).toString();
		formVariableDescription = row.getCell(4).toString();
		formVariableExample = row.getCell(5).toString();
	}

}
