package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class SourceMetadataTabDTO {

	private List<SourceTypeFilterDTO> sourceTypeFilterDTOs;
	
	private List<SourceMetadataDTO> sourceMetadataDTO;
	
}
