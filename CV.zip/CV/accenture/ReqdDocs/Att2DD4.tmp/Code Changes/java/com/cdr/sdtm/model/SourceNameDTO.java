package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class SourceNameDTO {

	private String sourceName;
	
	private String sourceDescription;
}
