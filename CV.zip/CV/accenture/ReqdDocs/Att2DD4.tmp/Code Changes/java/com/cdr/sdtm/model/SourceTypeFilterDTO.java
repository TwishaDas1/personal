package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class SourceTypeFilterDTO {

	private List<String> sourceType;
	
	private List<SourceFilterNameDTO> sourceFilterNameDTO;
	
}
