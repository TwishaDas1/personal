package com.cdr.sdtm.model;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="Study_Metadata")
public class Study {
	
	public Study() {
	}

	public Study(String studyID, String title, String phase, String status, String source, String therapeuticArea) {
		this.studyID = studyID;
		this.title = title;
		this.phase = phase;
		this.status = status;
		this.source = source;
		this.therapeuticArea = therapeuticArea;
	}
	

	@Id
	@Column(name="Study_ID")
    private String studyID;
    
    @Column(name="Study_Title")
    private String title;
    
    @Column(name="Study_Description")
    private String description;
    
    @Column(name="Study_Source")
    private String source;
    
    @Column(name="Therapeutic_Area")
    private String therapeuticArea;
    
    @Column(name="Study_Type")
    private String type;
    
    @Column(name="Study_Phase")
    private String phase;
    
    @Column(name="Study_Status")
    private String status;
    
    @Column(name="Study_Analyst")
    private String analyst;
    
    @Column(name="Study_Manager")
    private String manager;
    
    @Column(name="Version")
    private String studyVersion;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @Column(name="Db_Lock_Date")
    private Timestamp dbLockDate;
	
    
    @Basic
    @Column(name="Initial_Creation_Date")
    private LocalDateTime initialCreationDate;
    
    @Basic
    @Column(name="Update_Date")
    private LocalDateTime studyUpdateDate;
    
    @Transient
    @JsonProperty
    private boolean isVersionChanged;
	
	public boolean isVersionChanged() {
		return isVersionChanged;
	}

	public void setVersionChanged(boolean isVersionChanged) {
		this.isVersionChanged = isVersionChanged;
	}

	public String getStudyID() {
		return studyID;
	}

	public String getTitle() {
		return title;
	}

	public String getDescription() {
		return description;
	}

	public String getSource() {
		return source;
	}

	public String getTherapeuticArea() {
		return therapeuticArea;
	}

	public String getType() {
		return type;
	}

	public String getPhase() {
		return phase;
	}

	public String getStatus() {
		return status;
	}

	public String getAnalyst() {
		return analyst;
	}

	public String getManager() {
		return manager;
	}

	public String getStudyVersion() {
		return studyVersion;
	}

	public Timestamp getDbLockDate() {
		return dbLockDate;
	}

	public LocalDateTime getInitialCreationDate() {
		return initialCreationDate;
	}

	public LocalDateTime getStudyUpdateDate() {
		return studyUpdateDate;
	}

	public void setStudyID(String studyID) {
		this.studyID = studyID;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setTherapeuticArea(String therapeuticArea) {
		this.therapeuticArea = therapeuticArea;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setAnalyst(String analyst) {
		this.analyst = analyst;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public void setStudyVersion(String studyVersion) {
		this.studyVersion = studyVersion;
	}

	public void setDbLockDate(Timestamp dbLockDate) {
		this.dbLockDate = dbLockDate;
	}

	public void setInitialCreationDate(LocalDateTime initialCreationDate) {
		this.initialCreationDate = initialCreationDate;
	}

	public void setStudyUpdateDate(LocalDateTime studyUpdateDate) {
		this.studyUpdateDate = studyUpdateDate;
	}

}
