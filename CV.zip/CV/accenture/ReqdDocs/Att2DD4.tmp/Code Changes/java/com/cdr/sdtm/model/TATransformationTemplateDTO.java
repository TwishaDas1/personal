package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class TATransformationTemplateDTO {

	private String therapeuticArea;
	
	private List<TemplateNmTransformationTemplateDTO> templateNmTransformationTemplateDTOs;
	
}
