package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class TemplateNmTransformationTemplateDTO {
	
	private String templateName;
	
	private List<VersionTransformationTemplateDTO> versionTransformationTemplateDTO;
	
}
