package com.cdr.sdtm.model;

import java.util.Set;

import lombok.Data;

@Data
public class TransformationTemplateFilterParams {

	private Set<String> therapeuticAreas;
	
	private Set<String> studySources;
	
	private Set<String>  templateNames;
	
	private Set<String> versions;
	
	private Set<String> domainNames;
}
