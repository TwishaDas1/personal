package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class TransformationTemplateTabDTO {

	List<TATransformationTemplateDTO> taTransformationTemplateDTOs;
	
	TransformationTemplateFilterParams transformationTemplateFilterParams;
	
}
