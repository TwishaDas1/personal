package com.cdr.sdtm.model;

import lombok.Data;

@Data
public class VarLvlTransformationTemplateDTO implements Comparable<VarLvlTransformationTemplateDTO> {

	private String sdtmTargetVariable;

	private String sourceForm;

	private String sourceFormVariable;

	private String transformationType;

	private String transformationCode;

	private String Notes;

	@Override
	public int compareTo(VarLvlTransformationTemplateDTO varLvlTransformationTemplateDTO) {
		 
		return this.sdtmTargetVariable.compareTo(varLvlTransformationTemplateDTO.getSdtmTargetVariable());
	}
	
}
