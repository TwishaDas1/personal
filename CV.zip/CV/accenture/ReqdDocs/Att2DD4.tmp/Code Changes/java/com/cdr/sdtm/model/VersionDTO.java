package com.cdr.sdtm.model;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = { "businessRuleVersion","domainStatus","updateDate"}) 
public class VersionDTO implements Comparable<VersionDTO>{
		
	private String businessRuleVersion;
	
	private String domainStatus;
	
	private Date updateDate;
	
	@Override
	  public int compareTo(VersionDTO u) {
	    if (getUpdateDate() == null || u.getUpdateDate() == null) {
	      return 0;
	    }
	    return getUpdateDate().compareTo(u.getUpdateDate());
	  }
}
