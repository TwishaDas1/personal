package com.cdr.sdtm.model;

import java.util.List;

import lombok.Data;

@Data
public class VersionTransformationTemplateDTO {

	private String version;
	
	private List<DomainTransformationTemplateDTO> domainTransformationTemplateDTO;
	
}
