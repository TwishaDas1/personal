package com.cdr.sdtm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cdr.sdtm.model.DatabaseEnvironment;

@Repository
public interface DatabaseEnvironmentRepository extends JpaRepository<DatabaseEnvironment, String> {

}
