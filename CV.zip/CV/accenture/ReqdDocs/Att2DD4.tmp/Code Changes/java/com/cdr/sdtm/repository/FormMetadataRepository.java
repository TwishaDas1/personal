package com.cdr.sdtm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdr.sdtm.model.FormMetaData;
import com.cdr.sdtm.model.FormMetaDataDTO;
import com.cdr.sdtm.model.FormMetaDataId;

 
@Repository
public interface FormMetadataRepository extends JpaRepository<FormMetaData,FormMetaDataId>{
	
//	@Query(nativeQuery=true,value="select distinct Form_Description,Form_Name from SDTM_Dev.Form_Metadata where Form_Description is not null")
	@Query("Select NEW com.cdr.sdtm.model.FormMetaDataDTO(fmd.id.formName,fmd.formDescription) "
			+ "From FormMetaData fmd "
			+ "Where fmd.formDescription is not null")
	List<FormMetaDataDTO> findFormAndDescription();

	@Query("Select fmd from FormMetaData fmd where fmd.id.formSource in:sourceType and fmd.id.formName in:sourceName ")
	List<FormMetaData> findByFormSourceAndFormNameIn(@Param("sourceType")List<String> sourceType,@Param("sourceName")List<String> sourceName);


	
}
