package com.cdr.sdtm.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdr.sdtm.model.FormVariableMetaDataDTO;
import com.cdr.sdtm.model.FormVariablesMetaData;
import com.cdr.sdtm.model.FormVariablesMetaDataId;

@Repository
public interface FormVariableMetaDataRepository extends JpaRepository<FormVariablesMetaData, FormVariablesMetaDataId> {

	@Query(nativeQuery=true,value="select distinct Form_Name,Form_Variable_Description,Form_Variable_Name from SDTM_Dev.Form_Variable_Metadata where Form_Variable_Description is not null") 
	List<FormVariablesMetaData> findVariableAndDescription();
	
//	@Query("Select NEW com.cdr.sdtm.model.FormVariableMetaDataDTO(fvmd.formVariableName,fvmd.formName,fvmd.formDescription) "
//			+ "From FormVariablesMetaData fvmd "
//			+ "Where fvmd.formVariableDescription is not null")
//	Set<FormVariableMetaDataDTO> findAllVariableAndDescription();
	@Query("Select NEW com.cdr.sdtm.model.FormVariableMetaDataDTO(fvmd.id.formVariableName,fvmd.id.formName,fvmd.formDescription,fvmd.formVariableDescription) "
			+ "From FormVariablesMetaData fvmd "
			+ "Where fvmd.formVariableDescription is not null")
	Set<FormVariableMetaDataDTO> findAllVariableAndDescription();

	List<FormVariablesMetaData> findByFormType(String sourceType);
	
	@Query("Select fvm from FormVariablesMetaData fvm where fvm.id.formName in:formNames")
	List<FormVariablesMetaData> getFormNames(@Param("formNames")List<String> formNames);

	@Query("Select fvm From FormVariablesMetaData fvm")
	List<FormVariablesMetaData> findAllFormVariableMetaData();
	
}
