package com.cdr.sdtm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdr.sdtm.model.FormVariablesMetaData;

@Repository
public interface FormVariableRepository extends JpaRepository<FormVariablesMetaData, String> {

	@Query(nativeQuery=true,value="select * from Form_Variable_Metadata GROUP BY form_name,form_description")
	List<FormVariablesMetaData> findDistinctForms();
	
	@Query(nativeQuery=true,value="select * FROM Form_Variable_Metadata where Form_Name=:formName")
	List<FormVariablesMetaData> findFieldsByForm(@Param("formName") String formName);
	
}
