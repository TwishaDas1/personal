package com.cdr.sdtm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cdr.sdtm.model.JoinMatrix;

public interface JoinMatrixRepository extends JpaRepository<JoinMatrix, String>{

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update SDTM_Join_Matrix set Baseline_Name=:baselineName where Study_Title=:study and Domain_Name=:domain and Version=:businessRuleVersion")
	public void updateJoinMatrixTable(String study, String domain, String businessRuleVersion,String baselineName);
	
	
	@Query(nativeQuery=true,value="select * from SDTM_Join_Matrix where Study_Title=:study and Domain_Name=:domain and Version=:businessRuleVersion")
	public List<JoinMatrix> findByStudyTitleDomainNameVersionIn(String study, String domain, String businessRuleVersion);
	
	
	
}
