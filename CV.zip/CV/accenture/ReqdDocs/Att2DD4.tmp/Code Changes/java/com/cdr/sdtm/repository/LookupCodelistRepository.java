/**
 * 
 */
package com.cdr.sdtm.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cdr.sdtm.model.LookupCodelist;

/**
 * @author twdas
 *
 */
public interface LookupCodelistRepository extends JpaRepository<LookupCodelist, Long> {

}
