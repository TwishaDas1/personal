package com.cdr.sdtm.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.cdr.sdtm.model.Domain;
import com.cdr.sdtm.model.Study;


@Repository
public class MatrixCustomRepository {

	@Autowired
	@Qualifier("sdtmJdbcTemplate")
	JdbcTemplate sdtmJdbcTemplate;
	
	
	public List<Domain> getDomainsByStudyAndVersion(String studyTitle, String version){
		String sqlQuery = "select distinct a.Domain_Name as domain, a.Domain_Description as domainLabel, CASE \n" + 
				"WHEN b.Domain_Status is null THEN 'Not Started' \n" + 
				"ELSE b.Domain_Status end AS domainStatus FROM SDTM_Dev.SDTM_Domain_Metadata a \n" + 
				"left outer join SDTM_Dev.Path_To_SDTM_Matrix b on b.Study_Title='"+studyTitle+"' and b.Version='"+version+"'\n" + 
				" and a.Domain_Name=b.Domain_Name order by Domain_Status asc";
		return sdtmJdbcTemplate.query(sqlQuery,	new BeanPropertyRowMapper<>(Domain.class));
	}
	
	
	
	public List<Study> getStudyTitles(){
		String sqlQuery ="select Study_Title as title, Version as studyVersion from Study_Metadata  order by Study_Title asc";
		return sdtmJdbcTemplate.query(sqlQuery,	new BeanPropertyRowMapper<>(Study.class));
	}
	
}
