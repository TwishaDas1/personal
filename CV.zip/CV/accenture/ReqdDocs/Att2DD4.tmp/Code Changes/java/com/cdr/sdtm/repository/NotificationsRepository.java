/**
 * 
 */
package com.cdr.sdtm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.cdr.sdtm.model.Notification;

/**
 * @author twdas
 *
 */
public interface NotificationsRepository extends JpaRepository<Notification, Integer>{
	
	@Query(nativeQuery=true,value="select * FROM Notification where Study_ID in (:studyIds) and Delete_Flag ='N' and User_Role=:userRole order by Create_Date desc")
	List<Notification> findByStudyIdsAndUserRole(@Param("studyIds") List<String> studyIds, @Param("userRole") String userRole);
	
	@Query(nativeQuery=true,value="select * FROM Notification where Study_ID in (:studyIds) and Delete_Flag ='N' order by Create_Date desc")
	List<Notification> findByStudyIds(@Param("studyIds") List<String> studyIds);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Notification set Delete_Flag='Y' where Notification_ID=:id")
	int deleteNotifications(@Param("id") Integer id); 
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Notification set notification_new='N' where Notification_ID in (:ids)")
	int updateNotificationStatus(@Param("ids") List<Integer> ids);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Notification set Stop_Flag='Y' where Notification_ID=:id")
	int updateStopStatus(@Param("id") Integer id);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Notification set Task_Complete_Flag='Y',Task_Completion_Date=curdate() where Notification_ID=:id")
	void updateTaskAsComplete(@Param("id") Integer id); 


}
