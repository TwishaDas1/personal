package com.cdr.sdtm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cdr.sdtm.model.SDTMDomainMetadata;
import com.cdr.sdtm.model.SDTMDomainMetadataId;


@Repository
public interface SDTMDomainMetadataRepository extends JpaRepository<SDTMDomainMetadata, SDTMDomainMetadataId> {
	
}

