package com.cdr.sdtm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cdr.sdtm.model.SDTMVariableMetadata;
import com.cdr.sdtm.model.SDTMVariableMetadataId;

@Repository
public interface SDTMVariableMetadataRepository extends JpaRepository<SDTMVariableMetadata, SDTMVariableMetadataId>{

	@Query("Select vmd from SDTMVariableMetadata vmd where vmd.id.version=:version and vmd.id.domainName=:domainName")
	List<SDTMVariableMetadata> getByVersionAndDomainsName(@Param("version")List<String> version,@Param("domainName")String domainName);
	
}
