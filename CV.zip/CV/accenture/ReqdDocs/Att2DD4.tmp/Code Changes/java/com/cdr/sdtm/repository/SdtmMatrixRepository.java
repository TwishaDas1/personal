package com.cdr.sdtm.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cdr.sdtm.model.PathToSdtmDashBoard;
import com.cdr.sdtm.model.PathToSdtmMatrix;
import com.cdr.sdtm.model.VersionDTO;

@Repository
public interface SdtmMatrixRepository extends JpaRepository<PathToSdtmMatrix, Long>{
	
	@Query(nativeQuery=true,value="select * from Path_To_SDTM_Matrix where Study_Title=:study and Domain_Name=:domain and Version=:version and Domain_Status= 'Approved' AND Baseline_Name = (select Baseline_Name FROM Path_To_SDTM_Matrix Where Study_Title=:study AND Domain_Name=:domain and Version=:version order by Baseline_Name DESC LIMIT 1)")
	List<PathToSdtmMatrix> findByStudyAndDomainAndBusinessRuleVersionOrderByBaselineNameDesc(String study, String domain, String version);
	
	@Query(nativeQuery=true,value="select count(*) from Path_To_SDTM_Matrix where Study_Title=:study and Domain_Name=:domain and Version=:version and Baseline_Name='Working_Copy'")
	int findWorkingCopyDomains(String study, String domain, String version);
	
	@Query(nativeQuery=true,value="select distinct Study_Title from Path_To_SDTM_Matrix where Version=:version order by Study_Title asc")
	List<String> findDistinctStudies(String version);
	
	@Query(nativeQuery=true,value="select distinct Domain_Name,Domain_Description from Path_To_SDTM_Matrix where Study_Title=:study and Domain_Status= 'Approved' order by Domain_Description asc")
	List<Object[]> findDomainByStudy(@Param("study") String study);
	
	@Query(nativeQuery=true,value="select distinct SDTM_Variable_Description from Path_To_SDTM_Matrix where SDTM_Variable_Description is not null") 
	List<String> findDistinctSDTMVariables();
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="DELETE FROM Path_To_SDTM_Matrix where Study_Title=:study and Domain_Name=:domain and Version=:version and Baseline_Name='Working_Copy'" ) 
	int deleteMatricesByStudyandDomainandVersion(@Param("study") String study,@Param("domain") String domain, @Param("version") String version);
	
	List<PathToSdtmMatrix> findAll(Example exp);
	
	@Query(nativeQuery=true,value="Select distinct " + 
			" Domain_Description,CONCAT(Domain_Description, ' (', Domain_Name, ') ') AS SDTM_DOMAIN, CONCAT(Form_Description, ' (', Form_Name, ') ') AS SOURCE_FORM ,MAX(Join_Criteria) AS JOIN_LOGIC" + 
			" FROM Path_To_SDTM_Matrix a " + 
			" WHERE Form_Description <> ''" + 
			" AND Study_Title=:study and Domain_Name=:domain " + 
			" AND Version=:version and Baseline_Name=:baseline " + 
			" GROUP BY Domain_Description,CONCAT(Form_Description, ' (', Form_Name, ') ')" + 
			" ORDER BY MAX(Join_Criteria)  ASC")
	List<Object[]> fetchObjectLevelByStudyAndDomain(@Param("study") String study, @Param("version") String version,
			@Param("domain") String domain, @Param("baseline") String baseline);
	
	
	@Query(nativeQuery=true,value="Select distinct " + 
			" Domain_Description,CONCAT(Domain_Description, ' (', Domain_Name, ') ') AS SDTM_DOMAIN, CONCAT(Form_Description, ' (', Form_Name, ') ') AS SOURCE_FORM ,MAX(Join_Criteria) AS JOIN_LOGIC" + 
			" FROM Path_To_SDTM_Matrix a " + 
			" WHERE Form_Description <> ''" + 
			" AND Study_Title=:study and Version=:version " + 
			" GROUP BY Domain_Description,CONCAT(Form_Description, ' (', Form_Name, ') ')" + 
			" ORDER BY MAX(Join_Criteria)  ASC")
	List<Object[]> fetchObjectLevelData(@Param("study") String study, @Param("version") String version);
	
	
	
	@Query(nativeQuery=true,value="Select \r\n" + 
			"               DISTINCT\r\n" + 
			"               a.Study_ID AS studyID,a.Study_Title AS studyTitle,a.Study_Description AS studyDescription,a.Study_Phase AS studyPhase, a.Db_Lock_Date AS dbLockDate,a.Study_Analyst AS studyAnalyst,a.Study_Manager as studyManager \r\n" + 
			"               ,a.Initial_Creation_Date AS studySetUpdate, a.Study_Status AS studyStatus,b.Domain_Name as domainName,b.Domain_Status as domainStatus,b.Current_Domain_Version AS currentDomainVersion,f.Latest_Domain_Version AS lastDomainVersion \r\n" + 
			"               , e.Count_Of_Domains AS countOfDomains, f.Count_Of_All_Domains AS countOfAllDomains \r\n" + 
			"               ,CASE WHEN c.Domain_Name is NOT NULL THEN b.Domain_Description END AS jobDomainName,c.Job_Status AS jobStatus\r\n" + 
			"               ,d.Last_job_Run AS lastJobRun \r\n" + 
			"               , CASE WHEN c.Job_Enablement_Status = 'N' THEN 'Enabled' \r\n" + 
			"                       WHEN c.Job_Enablement_Status = 'Y' THEN 'Disabled' \r\n" + 
			"               END AS jobEnablementStatus \r\n" + 
			"\r\n" + 
			"        from Study_Metadata a\r\n" + 
			"\r\n" + 
			"        left outer join\r\n" + 
			"        (\r\n" + 
			"        Select a.Study_Title,a.Domain_Name,a.Domain_Description,a.Domain_Status,MAX(a.Version) AS Current_Domain_Version \r\n" + 
			"        from Path_To_SDTM_Matrix a\r\n" + 
			"        group by a.Study_Title,a.Domain_Name,a.Domain_Description,a.Domain_Status\r\n" + 
			"        )b\r\n" + 
			"        on a.Study_Title =b.Study_Title\r\n" + 
			"\r\n" + 
			"        left outer join\r\n" + 
			"        (\r\n" + 
			"        Select distinct a.Study_Title,a.Domain_Name,a.Job_Status,a.Job_Enablement_Status-- ,a.Job_End_Timestamp as Job_Run_DateTime\r\n" + 
			"        from Job_Run_Statistics a\r\n" + 
			"        )c\r\n" + 
			"        on a.Study_Title = c.Study_Title\r\n" + 
			"        and b.Domain_Name = c.Domain_Name \r\n" + 
			"\r\n" + 
			"        left outer join\r\n" + 
			"        (       \r\n" + 
			"        Select Study_Title , MAX(Job_End_Timestamp) as Last_job_Run from Job_Run_Statistics group by Study_Title       \r\n" + 
			"        )d\r\n" + 
			"        on a.Study_Title = d.Study_Title\r\n" + 
			"\r\n" + 
			"        left outer join\r\n" + 
			"        (\r\n" + 
			"        Select a.Study_Title,count(distinct a.Domain_Name) as Count_Of_Domains\r\n" + 
			"        from Path_To_SDTM_Matrix a\r\n" + 
			"        where Domain_Status = 'Approved'\r\n" + 
			"        group by a.Study_Title\r\n" + 
			"        )e\r\n" + 
			"        on a.Study_Title = e.Study_title\r\n" + 
			"\r\n" + 
			"        inner join\r\n" + 
			"        (\r\n" + 
			"        Select COUNT(DISTINCT Domain_Name) AS Count_Of_All_Domains,MAX(Version) AS Latest_Domain_Version from SDTM_Domain_Metadata\r\n" + 
			"        )f\r\n" + 
			"        on 1=1;\r\n" + 
			"")
	List<PathToSdtmDashBoard> fetchDashBoardData();

	@Transactional
	@Modifying
//	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Domain_Status=:status, Update_Date=CURRENT_DATE where Study_Title=:study and Domain_Name=:domain")
//	int updateDomainStatus(String study, String domain, String status);
	
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Domain_Status=:status, Update_Date=CURRENT_DATE, Baseline_Name=:baselineName where Study_Title=:study and Domain_Name=:domain and Version=:businessRuleVersion and Baseline_Name='Working_Copy'")
	int updateDomainStatus(String study, String domain, String status, String businessRuleVersion,String baselineName);
	
	
	
	
	@Transactional
	@Modifying
	//@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Domain_Status=:status, Update_Date=CURRENT_DATE, Baseline_Name=:baseLine where Study_Title=:study and Domain_Name=:domain")
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix a, Job_Run_Statistics b set a.Domain_Status=:status, a.Update_Date=CURRENT_DATE, \n" + 
			"a.Baseline_Name=:baseLine, b.Baseline_Name=:baseLine where \n" + 
			"a.Study_Title=b.Study_Title and a.Domain_Name=b.Domain_Name and \n" + 
			"a.Study_Title=:study and a.Domain_Name=:domain \n"
			//"a.Version=:businessRuleVersion and b.Version=:businessRuleVersion"
			)
	int updateApprovedDomainStatus(String study, String domain, String status, String baseLine);


	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Flag=:flag, Update_Date=CURRENT_DATE where Matrix_ID=:id")
	int updateRuleFlag(Long id, String flag);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Notes=:notes, Update_Date=CURRENT_DATE where Study_Title=:study and Domain_Name=:domain")
	int updateNotesForRules(String study, String domain, String notes);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Notes=:notes, Update_Date=CURRENT_DATE where Matrix_ID in (:selectedRules)")
	int updateNotesForSelectedRules(List<Long> selectedRules, String notes);

	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Notes=:notes, Flag='Y', Update_Date=CURRENT_DATE where Study_Title=:study and Domain_Name=:domain")
	int updateFlagsForRules(String study, String domain, String notes);
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Flag='Y', Update_Date=CURRENT_DATE where Study_Title=:study and Domain_Name=:domain")
	int updateFlagsForRulesEmptyNotes(String study, String domain);


	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Notes=:notes, Flag='Y' where Matrix_ID in (:selectedRules)")
	int updateFlagsForSelectedRules(List<Long> selectedRules, String notes);
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="update Path_To_SDTM_Matrix set Flag='Y' where Matrix_ID in (:selectedRules)")
	int updateFlagsForSelectedRulesEmptyNotes(List<Long> selectedRules);
	

	@Query(nativeQuery=true,value="select distinct Version from Path_To_SDTM_Matrix where Study_Title=:studyTitle")
	List<String> getVersionsByStudyTitle(String studyTitle);

	@Query("select new com.cdr.sdtm.model.VersionDTO( ptsm.businessRuleVersion, ptsm.domainStatus, ptsm.updateDate) from PathToSdtmMatrix ptsm where ptsm.study =:study and ptsm.domainStatus in:domainStatusList")
	Set<VersionDTO> getApplicableVersionDTOs(@Param("study") String study, @Param("domainStatusList") List<String> domainStatusList);
	
	
/*
	@Query(nativeQuery=true,value="select distinct Domain_Name, Domain_Description from SDTM_Dev.Path_To_SDTM_Matrix where Study_Title=:studyTitle and Version=:version and Domain_Status='Approved'")
	List<Object[]> getDomainsByStudyAndVersion(String studyTitle, String version);*/
	
	@Query(nativeQuery=true,value="select distinct Baseline_Name from Path_To_SDTM_Matrix where Study_Title=:studyTitle and Version=:version and Domain_Name=:domain order by Update_Date desc")
	List<String> getBaselinesByStudyVersionDomain(String studyTitle, String version, String domain);
	
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="delete from Path_To_SDTM_Matrix where Study_Title=:studyTitle and Domain_Name=:domainName and Version=:version and Baseline_Name='Working_Copy'")
	int deleteWorkingCopyBR(String studyTitle, String domainName, String version);
	

}
