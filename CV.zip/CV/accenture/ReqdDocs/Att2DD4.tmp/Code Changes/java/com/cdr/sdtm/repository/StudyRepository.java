package com.cdr.sdtm.repository;

import java.util.List;

import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cdr.sdtm.model.Study;

@Repository
public interface StudyRepository extends JpaRepository<Study, String>, QueryByExampleExecutor <Study>{
	
	
	
	List<Study> findByStudyID(String studyID);
	
	List<Study> findAll(Example exp);
	
	@Query(nativeQuery=true,value="select distinct Study_ID from Study_Metadata where Study_ID is not null")
	List<String> findStudyIds(); 
	
	@Query(nativeQuery=true,value="select distinct Study_Title from Study_Metadata where Therapeutic_Area=:therapeuticArea order by Study_Title asc")
	List<String> findStudiesBytherapeuticArea(@Param("therapeuticArea") String therapeuticArea);
	
	@Query(nativeQuery=true,value="select Study_ID from Study_Metadata where Study_Title=:study")
	String getStudyId(@Param("study")String study);
	
	@Transactional
	@Modifying
	@Query(nativeQuery=true,value="delete from Path_To_SDTM_Matrix where Study_Title =:study and Baseline_Name='Working Copy'")
	void deleteStudyWorkingCopies(@Param("study") String study);
}
