package com.cdr.sdtm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cdr.sdtm.model.StudyType;

public interface StudyTypeRepository extends JpaRepository<StudyType, String>{

}
