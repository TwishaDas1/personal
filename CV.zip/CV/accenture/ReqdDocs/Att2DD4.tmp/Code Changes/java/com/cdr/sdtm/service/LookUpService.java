package com.cdr.sdtm.service;

import java.util.List;

import com.cdr.sdtm.model.LookUp;
import com.cdr.sdtm.model.LookupCodelist;

public interface LookUpService {
	
	List<LookUp> findAll();
	
	List<String> findDistinctTables();
	List<LookupCodelist> findLookUpCodeList();

}
