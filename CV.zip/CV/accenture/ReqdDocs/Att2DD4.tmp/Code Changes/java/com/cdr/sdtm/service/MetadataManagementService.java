package com.cdr.sdtm.service;

import java.io.IOException;

import com.cdr.sdtm.model.DirectoryMetadataDTO;
import com.cdr.sdtm.model.SDTMTargerMetadataTabDTO;
import com.cdr.sdtm.model.SDTMVersionDomainDTO;
import com.cdr.sdtm.model.SourceMetadataTabDTO;
import com.cdr.sdtm.model.SourceTypeFilterDTO;
import com.cdr.sdtm.model.TransformationTemplateFilterParams;
import com.cdr.sdtm.model.TransformationTemplateTabDTO;

public interface MetadataManagementService {

	SDTMTargerMetadataTabDTO getSDTMTargerMetadataTabDTO(SDTMVersionDomainDTO sdtmVersionDomainDTO);

	SourceMetadataTabDTO getSourceMetadataTabDTO(SourceTypeFilterDTO sourceTypeFilterDTO);

	String saveDirectory(DirectoryMetadataDTO directoryMetadataDTO);

	void saveSourceMetadata(String path) throws IOException;

	void saveSdtmTargetMetadata(String path) throws IOException;

	TransformationTemplateTabDTO getTransformationTemplateTabDTO(TransformationTemplateFilterParams transformationTemplateFilterParams);
} 
