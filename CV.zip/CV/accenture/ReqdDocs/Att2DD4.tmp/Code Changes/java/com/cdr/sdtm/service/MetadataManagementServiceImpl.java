package com.cdr.sdtm.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.cdr.sdtm.model.DatabaseEnvironment;
import com.cdr.sdtm.model.DatabaseEnvironmentDTO;
import com.cdr.sdtm.model.DatabaseEnvironmentDetail;
import com.cdr.sdtm.model.DatabaseEnvironmentDetailDTO;
import com.cdr.sdtm.model.DirectoryMetadataDTO;
import com.cdr.sdtm.model.DomainFilterDTO;
import com.cdr.sdtm.model.DomainTransformationTemplateDTO;
import com.cdr.sdtm.model.FormMetaData;
import com.cdr.sdtm.model.FormMetaDataDTO;
import com.cdr.sdtm.model.FormMetaDataId;
import com.cdr.sdtm.model.FormVariableMetaDataDTO;
import com.cdr.sdtm.model.FormVariablesMetaData;
import com.cdr.sdtm.model.FormVariablesMetaDataId;
import com.cdr.sdtm.model.PathToSdtmMatrixDTO;
import com.cdr.sdtm.model.SDTMDomainMetadata;
import com.cdr.sdtm.model.SDTMDomainMetadataDTO;
import com.cdr.sdtm.model.SDTMDomainMetadataId;
import com.cdr.sdtm.model.SDTMTargerMetadataDTO;
import com.cdr.sdtm.model.SDTMTargerMetadataTabDTO;
import com.cdr.sdtm.model.SDTMVariableMetadata;
import com.cdr.sdtm.model.SDTMVariableMetadataDTO;
import com.cdr.sdtm.model.SDTMVariableMetadataId;
import com.cdr.sdtm.model.SDTMVersionDomainDTO;
import com.cdr.sdtm.model.SdtmTargetMetadataExcelDTO;
import com.cdr.sdtm.model.ServerEnvironment;
import com.cdr.sdtm.model.ServerEnvironmentDTO;
import com.cdr.sdtm.model.ServerEnvironmentDetail;
import com.cdr.sdtm.model.ServerEnvironmentDetailDTO;
import com.cdr.sdtm.model.SourceFilterNameDTO;
import com.cdr.sdtm.model.SourceMetadataDTO;
import com.cdr.sdtm.model.SourceMetadataExcelDTO;
import com.cdr.sdtm.model.SourceMetadataTabDTO;
import com.cdr.sdtm.model.SourceTypeFilterDTO;
import com.cdr.sdtm.model.TATransformationTemplateDTO;
import com.cdr.sdtm.model.TemplateNmTransformationTemplateDTO;
import com.cdr.sdtm.model.TransformationTemplateFilterParams;
import com.cdr.sdtm.model.TransformationTemplateTabDTO;
import com.cdr.sdtm.model.VarLvlTransformationTemplateDTO;
import com.cdr.sdtm.model.VersionTransformationTemplateDTO;
import com.cdr.sdtm.repository.DatabaseEnvironmentRepository;
import com.cdr.sdtm.repository.FormMetadataRepository;
import com.cdr.sdtm.repository.FormVariableMetaDataRepository;
import com.cdr.sdtm.repository.ServerEnvironmentRepository;

@Service
@Transactional
public class MetadataManagementServiceImpl implements MetadataManagementService {

	
	@Autowired
	private SDTMVariableMetadataService sdtmVariableMetadataService;
	
	@Autowired
	private SDTMDomainMetadataService sdtmDomainMetadataService;
	
	@Autowired
	private FormMetadataRepository formMetaDataRepository;

	@Autowired
	private FormVariableMetaDataRepository formVariableMetaDataRepository;
	
	@Autowired
	private ServerEnvironmentRepository serverEnvironmentRepository;
	
	@Autowired
	private DatabaseEnvironmentRepository databaseEnvironmentRepository;
	
	@PersistenceContext
    private EntityManager em;
	
	@Override	
	public SDTMTargerMetadataTabDTO getSDTMTargerMetadataTabDTO(SDTMVersionDomainDTO sdtmVersionDomainDTO) {
		Map<String, List<SDTMVariableMetadataDTO>> domainNmSDTMVariableMap = null;
		SDTMTargerMetadataTabDTO sdtmTargerMetadataTabDTO = new SDTMTargerMetadataTabDTO();
		
		List<SDTMDomainMetadataDTO> sdtmDomainMetadataDTOs = null;
		List<SDTMVariableMetadataDTO> sdtmVariableMetadataDTOs = null;
		
		if(null != sdtmVersionDomainDTO && !CollectionUtils.isEmpty(sdtmVersionDomainDTO.getDomainDTO())) {
			sdtmDomainMetadataDTOs = sdtmDomainMetadataService.getByVersionAndDomainsName(sdtmVersionDomainDTO);
			sdtmVariableMetadataDTOs = sdtmVariableMetadataService.getByVersionAndDomainsName(sdtmVersionDomainDTO);
		}else {
			sdtmDomainMetadataDTOs = sdtmDomainMetadataService.getAllSDTMDomainMetadata();
			sdtmVariableMetadataDTOs = sdtmVariableMetadataService.getAllSDTMVariableMetadataDTO();
		}
		List<SDTMVersionDomainDTO> sdtmVersionDomainDTOs = new ArrayList<>();
		SDTMVersionDomainDTO sdtmVersionDomain = null;
		Map<String, List<SDTMDomainMetadataDTO>> versionSDTMDomainMap = null;
		Map<String, List<SDTMVariableMetadataDTO>> versionSDTMVariableMap = null;
		
		if(!CollectionUtils.isEmpty(sdtmDomainMetadataDTOs)) {
			SDTMTargerMetadataDTO sdtmTargerMetadataDTO = null;
			List<SDTMTargerMetadataDTO> sdtmTargerMetadataDTOs = new ArrayList<>();
			versionSDTMDomainMap = sdtmDomainMetadataDTOs.stream().collect(Collectors.groupingBy(SDTMDomainMetadataDTO::getVersion));
			System.out.println(sdtmVariableMetadataDTOs);
			if(!CollectionUtils.isEmpty(sdtmVariableMetadataDTOs)) {
				versionSDTMVariableMap = sdtmVariableMetadataDTOs.stream().collect(Collectors.groupingBy(SDTMVariableMetadataDTO::getVersion));
			}
			for(Entry<String, List<SDTMDomainMetadataDTO>> versionSDTMDomainEntry : versionSDTMDomainMap.entrySet()) {
				domainNmSDTMVariableMap = null;
				sdtmVersionDomain = new SDTMVersionDomainDTO();
				List<String> versionss = new ArrayList<>();
				versionss.add(versionSDTMDomainEntry.getKey());
				sdtmVersionDomain.setVersion(versionss);
				sdtmTargerMetadataDTO = new SDTMTargerMetadataDTO();
				sdtmTargerMetadataDTO.setVersion(versionSDTMDomainEntry.getKey());
				if(!CollectionUtils.isEmpty(versionSDTMVariableMap)) {
					List<SDTMVariableMetadataDTO> verSDTMVariableMetadataDTOs = versionSDTMVariableMap.get(versionSDTMDomainEntry.getKey());
					if(!CollectionUtils.isEmpty(verSDTMVariableMetadataDTOs)) {
						domainNmSDTMVariableMap =  verSDTMVariableMetadataDTOs.stream().collect(Collectors.groupingBy(SDTMVariableMetadataDTO::getDomainName));
					}
				}
				List<DomainFilterDTO> domaindto = new ArrayList<>();
				for(SDTMDomainMetadataDTO sdtmDomainMetadataDTO : versionSDTMDomainEntry.getValue()) {
					if(!CollectionUtils.isEmpty(domainNmSDTMVariableMap)){
						List<SDTMVariableMetadataDTO> domainNmSDTMVariableDTOs = domainNmSDTMVariableMap.get(sdtmDomainMetadataDTO.getDomainName());
						if(!CollectionUtils.isEmpty(domainNmSDTMVariableDTOs)) {
							sdtmDomainMetadataDTO.setSdtmVariableMetadataDTOs(domainNmSDTMVariableDTOs);
						}
					}
					DomainFilterDTO domainDTO = new DomainFilterDTO();
					domainDTO.setDomain(sdtmDomainMetadataDTO.getDomainName());
					domainDTO.setDomainDescription(sdtmDomainMetadataDTO.getDescription());
					domaindto.add(domainDTO);

				}
				Collections.sort(domaindto);
				sdtmTargerMetadataDTO.setSdtmDomainMetadataDTOs(versionSDTMDomainEntry.getValue());
				sdtmTargerMetadataDTOs.add(sdtmTargerMetadataDTO);
				sdtmVersionDomain.setDomainDTO(domaindto);
				sdtmVersionDomainDTOs.add(sdtmVersionDomain);
			}
			sdtmTargerMetadataTabDTO.setSdtmTargerMetadataDTOs(sdtmTargerMetadataDTOs);
			sdtmTargerMetadataTabDTO.setSdtmVersionDomainDTOs(sdtmVersionDomainDTOs);
		}
		return sdtmTargerMetadataTabDTO;
	}
	
	
	@Override
	public SourceMetadataTabDTO getSourceMetadataTabDTO(SourceTypeFilterDTO sourceTypeFilter) {
		List<FormMetaData> formMetaDataList = null;
		List<FormVariablesMetaData> formVariableMetaList = null;
		List<SourceTypeFilterDTO> sourceTypeFilterDTOs = new ArrayList<>();
		SourceMetadataTabDTO sourceMetadataTabDTO = new SourceMetadataTabDTO();
		List<SourceMetadataDTO> sourceMetadataDTOs = new ArrayList<>();
		List<String> sourceNames = new ArrayList<>();
		if(null == sourceTypeFilter || CollectionUtils.isEmpty(sourceTypeFilter.getSourceFilterNameDTO()) || null == sourceTypeFilter.getSourceType()) {
			formMetaDataList = formMetaDataRepository.findAll();
			sourceNames = formMetaDataList.stream().map(FormMetaData::getFormName).collect(Collectors.toList());
		}else {
			for(SourceFilterNameDTO SourceFilterNameDTO : sourceTypeFilter.getSourceFilterNameDTO() ) {
				sourceNames.add(SourceFilterNameDTO.getSourceName());
			}
			
			formMetaDataList = formMetaDataRepository.findByFormSourceAndFormNameIn(sourceTypeFilter.getSourceType(),sourceNames);
		}
		formVariableMetaList = formVariableMetaDataRepository.getFormNames(sourceNames);
		createSourceMetadataTabDTO(formMetaDataList, formVariableMetaList, sourceTypeFilterDTOs, sourceMetadataTabDTO,
				sourceMetadataDTOs);
		return sourceMetadataTabDTO;
	}


	private void createSourceMetadataTabDTO(List<FormMetaData> formMetaDataList,
			List<FormVariablesMetaData> formVariableMetaList, List<SourceTypeFilterDTO> sourceTypeFilterDTOs,
			SourceMetadataTabDTO sourceMetadataTabDTO, List<SourceMetadataDTO> sourceMetadataDTOs) {
		SourceTypeFilterDTO sourceTypeFilterDTO;
		SourceMetadataDTO sourceMetadataDTO;
		if(!CollectionUtils.isEmpty(formMetaDataList)) {
			Map<String,List<FormVariablesMetaData>> formNmAndFormVariableMetaMap = null;
			Map<String,List<FormMetaData>> sourceTypeformMap = formMetaDataList.stream().collect(Collectors.groupingBy(FormMetaData::getFormSource));
			if(!CollectionUtils.isEmpty(formVariableMetaList)) {
				formNmAndFormVariableMetaMap = formVariableMetaList.stream().collect(Collectors.groupingBy(FormVariablesMetaData::getFormName));
			}
			
			for(Entry<String, List<FormMetaData>> entry : sourceTypeformMap.entrySet()) {
				List<String> sourcetypes = new ArrayList<>();
				sourceMetadataDTO = new SourceMetadataDTO(); 
				sourceMetadataDTO.setSourceType(entry.getKey());
				sourceTypeFilterDTO = new SourceTypeFilterDTO();
				sourcetypes.add(entry.getKey());
				sourceTypeFilterDTO.setSourceType(sourcetypes);
				List<SourceFilterNameDTO> sourceFilterNameDTOs = new ArrayList<>();
				if(!CollectionUtils.isEmpty(entry.getValue())) {
					Map<String, FormMetaData> formNmformMetaDataMap = entry.getValue().stream().collect(Collectors.toMap(FormMetaData::getFormName, f->f));
					for(Entry<String,FormMetaData> formNmformMetaDataMapEntry: formNmformMetaDataMap.entrySet()) {
						SourceFilterNameDTO SourceFilterNameDTO = new SourceFilterNameDTO();
						SourceFilterNameDTO.setSourceName(formNmformMetaDataMapEntry.getKey());
						SourceFilterNameDTO.setSourceDescription(formNmformMetaDataMapEntry.getValue().getFormDescription());
						sourceFilterNameDTOs.add(SourceFilterNameDTO);
					}
					Collections.sort(sourceFilterNameDTOs);
					sourceTypeFilterDTO.setSourceFilterNameDTO(sourceFilterNameDTOs);
					List<FormMetaDataDTO> formMetaDataDTOs = createFormMetaDataDTOs(formNmformMetaDataMap, formNmAndFormVariableMetaMap);
					sourceMetadataDTO.setFormMetaDataDTOs(formMetaDataDTOs);
				}
				sourceMetadataDTOs.add(sourceMetadataDTO);
				sourceTypeFilterDTOs.add(sourceTypeFilterDTO);
			}
			sourceMetadataTabDTO.setSourceMetadataDTO(sourceMetadataDTOs);
			sourceMetadataTabDTO.setSourceTypeFilterDTOs(sourceTypeFilterDTOs);
		}
	}

	private List<FormMetaDataDTO> createFormMetaDataDTOs(Map<String, FormMetaData> formNmformMetaDataMap,
			Map<String, List<FormVariablesMetaData>> formNmAndFormVariableMetaMap) {
		List<FormMetaDataDTO> formMetaDataDTOs = null;
		List<FormVariablesMetaData> formVariableMetaDatas = null;
		List<FormVariableMetaDataDTO> formVariableMetaDataDTOs = null;
		if(!CollectionUtils.isEmpty(formNmformMetaDataMap)) {
			formMetaDataDTOs = new ArrayList<>();
			for(Entry<String,FormMetaData> formNmformMetaDataMapEntry: formNmformMetaDataMap.entrySet()) {
				FormMetaData formMetaData = formNmformMetaDataMapEntry.getValue();
				FormMetaDataDTO formMetaDataDTO = new FormMetaDataDTO();
				BeanUtils.copyProperties(formMetaData.id, formMetaDataDTO);
				BeanUtils.copyProperties(formMetaData, formMetaDataDTO);
				if(!CollectionUtils.isEmpty(formNmAndFormVariableMetaMap)) {
					formVariableMetaDatas = formNmAndFormVariableMetaMap.get(formNmformMetaDataMapEntry.getKey());
					if(!CollectionUtils.isEmpty(formVariableMetaDatas)) {
						formVariableMetaDataDTOs = new ArrayList<>();
						for(FormVariablesMetaData formVariableMetaData: formVariableMetaDatas) {
							FormVariableMetaDataDTO  formVariableMetaDataDTO = new FormVariableMetaDataDTO();
							BeanUtils.copyProperties(formVariableMetaData.id, formVariableMetaDataDTO);
							BeanUtils.copyProperties(formVariableMetaData, formVariableMetaDataDTO);
							formVariableMetaDataDTOs.add(formVariableMetaDataDTO);
						}
						Collections.sort(formVariableMetaDataDTOs);	
						formMetaDataDTO.setFormVariableMetaDataDTOs(formVariableMetaDataDTOs);
					}	
				}	
				formMetaDataDTOs.add(formMetaDataDTO);
			}
			Collections.sort(formMetaDataDTOs);
		}
		
		return formMetaDataDTOs;
	}
	
	@Override
	public TransformationTemplateTabDTO getTransformationTemplateTabDTO(TransformationTemplateFilterParams filterParams) {
		Set<String> therapeuticAreas = new HashSet<>();
		Set<String> studySources = new HashSet<>();
		Set<String> templateNames = new HashSet<>();
		Set<String> versions = new HashSet<>();
		Set<String> domainNames = new HashSet<>();
		List<PathToSdtmMatrixDTO> pathToSdtmMatrixDTOs = null;
		TransformationTemplateTabDTO transformationTemplateTabDTO = new TransformationTemplateTabDTO();
		pathToSdtmMatrixDTOs = getPathToSdtmMatrixDTO(filterParams);
		Map<String, Map<String, Map<String, Map<String, List<PathToSdtmMatrixDTO>>>>> transformationTemplateTabMap = pathToSdtmMatrixDTOs.stream().collect(Collectors.groupingBy(PathToSdtmMatrixDTO::getTherapeuticArea, Collectors.groupingBy(PathToSdtmMatrixDTO::getStudy,
				Collectors.groupingBy(PathToSdtmMatrixDTO::getBusinessRuleVersion, Collectors.groupingBy(PathToSdtmMatrixDTO::getDomain)))));
		List<TATransformationTemplateDTO> taTransformationTemplateDTOs = new ArrayList<>();
		TransformationTemplateFilterParams transformationTemplateFilterParams = new TransformationTemplateFilterParams();
		for(Entry<String, Map<String, Map<String, Map<String, List<PathToSdtmMatrixDTO>>>>> taPathToSdtmEntry : transformationTemplateTabMap.entrySet()) {
			TATransformationTemplateDTO taTransformationTemplateDTO = new TATransformationTemplateDTO();
			taTransformationTemplateDTO.setTherapeuticArea(taPathToSdtmEntry.getKey());
			therapeuticAreas.add(taPathToSdtmEntry.getKey());
			if(!CollectionUtils.isEmpty(taPathToSdtmEntry.getValue())) {
				List<TemplateNmTransformationTemplateDTO> templateNmTransformationTemplateDTOs = new ArrayList<>();
				for(Entry<String, Map<String, Map<String, List<PathToSdtmMatrixDTO>>>> studyPathToSdtmEntry : taPathToSdtmEntry.getValue().entrySet()) {
					TemplateNmTransformationTemplateDTO templateNmTransformationTemplateDTO = new TemplateNmTransformationTemplateDTO();
					templateNmTransformationTemplateDTO.setTemplateName(studyPathToSdtmEntry.getKey());
					templateNames.add(studyPathToSdtmEntry.getKey());
					if(!CollectionUtils.isEmpty(studyPathToSdtmEntry.getValue())) {
						List<VersionTransformationTemplateDTO> versionTransformationTemplateDTOs = new ArrayList<>();
						for(Entry<String, Map<String, List<PathToSdtmMatrixDTO>>> versionPathToSdtmEntry : studyPathToSdtmEntry.getValue().entrySet()) {
							VersionTransformationTemplateDTO versionTransformationTemplateDTO = new VersionTransformationTemplateDTO();
							versionTransformationTemplateDTO.setVersion(versionPathToSdtmEntry.getKey());
							versions.add(versionPathToSdtmEntry.getKey());
							if(!CollectionUtils.isEmpty(versionPathToSdtmEntry.getValue())) {
								List<DomainTransformationTemplateDTO> domainTransformationTemplateDTOs = new ArrayList<>();
								for(Entry<String, List<PathToSdtmMatrixDTO>> domainPathToSdtmEntry : versionPathToSdtmEntry.getValue().entrySet()) {
									DomainTransformationTemplateDTO domainTransformationTemplateDTO = new DomainTransformationTemplateDTO();
									domainTransformationTemplateDTO.setDomain(domainPathToSdtmEntry.getKey());
									domainNames.add(domainPathToSdtmEntry.getKey());
									if(!CollectionUtils.isEmpty(domainPathToSdtmEntry.getValue())) {
										List<VarLvlTransformationTemplateDTO> varLvlTransformationTemplateDTOs = new ArrayList<>();
										Set<String> sources = new HashSet<>();
										for(PathToSdtmMatrixDTO pathToSdtmMatrixDTO : domainPathToSdtmEntry.getValue()) {
											domainTransformationTemplateDTO.setDomainDescription(pathToSdtmMatrixDTO.getDomainLabel());
											sources.add(pathToSdtmMatrixDTO.getFormName());
											studySources.add(pathToSdtmMatrixDTO.getSource());
											VarLvlTransformationTemplateDTO varLvlTransformationTemplateDTO = new VarLvlTransformationTemplateDTO();
											if(pathToSdtmMatrixDTO.getFormName() != "")
											{
											varLvlTransformationTemplateDTO.setSourceForm(pathToSdtmMatrixDTO.getFormLable()+'('+pathToSdtmMatrixDTO.getFormName()+')');
											}
											else {
												varLvlTransformationTemplateDTO.setSourceForm(pathToSdtmMatrixDTO.getFormName());	
											}
											if(pathToSdtmMatrixDTO.getSourceFile() != "")
											{
											varLvlTransformationTemplateDTO.setSourceFormVariable(pathToSdtmMatrixDTO.getSourceField()+'('+pathToSdtmMatrixDTO.getSourceFile()+')');
											}
											else{
												varLvlTransformationTemplateDTO.setSourceFormVariable(pathToSdtmMatrixDTO.getSourceFile());	
											}varLvlTransformationTemplateDTO.setSdtmTargetVariable(pathToSdtmMatrixDTO.getTargetField() +'('+pathToSdtmMatrixDTO.getTargetFile()+')');
											varLvlTransformationTemplateDTO.setTransformationCode(pathToSdtmMatrixDTO.getBack_transformation_logic());
											varLvlTransformationTemplateDTO.setTransformationType(pathToSdtmMatrixDTO.getTransformation_type());
											varLvlTransformationTemplateDTO.setNotes(pathToSdtmMatrixDTO.getNotes());
											varLvlTransformationTemplateDTOs.add(varLvlTransformationTemplateDTO);
										}
										Collections.sort(varLvlTransformationTemplateDTOs);
										domainTransformationTemplateDTO.setSourceFiles(String.join(",", sources));
										domainTransformationTemplateDTO.setVarLvlTransformationTemplateDTOs(varLvlTransformationTemplateDTOs);
									}
									domainTransformationTemplateDTOs.add(domainTransformationTemplateDTO);
								}
								Collections.sort(domainTransformationTemplateDTOs);
								versionTransformationTemplateDTO.setDomainTransformationTemplateDTO(domainTransformationTemplateDTOs);
							}
							versionTransformationTemplateDTOs.add(versionTransformationTemplateDTO);
						}
						templateNmTransformationTemplateDTO.setVersionTransformationTemplateDTO(versionTransformationTemplateDTOs);
					}
					templateNmTransformationTemplateDTOs.add(templateNmTransformationTemplateDTO);
				}
				taTransformationTemplateDTO.setTemplateNmTransformationTemplateDTOs(templateNmTransformationTemplateDTOs);
			}
			taTransformationTemplateDTOs.add(taTransformationTemplateDTO);
			transformationTemplateTabDTO.setTaTransformationTemplateDTOs(taTransformationTemplateDTOs);
		}
		transformationTemplateFilterParams.setDomainNames(domainNames);
		transformationTemplateFilterParams.setStudySources(studySources);
		transformationTemplateFilterParams.setTemplateNames(templateNames);
		transformationTemplateFilterParams.setTherapeuticAreas(therapeuticAreas);
		transformationTemplateFilterParams.setVersions(versions);
		transformationTemplateTabDTO.setTransformationTemplateFilterParams(transformationTemplateFilterParams);
		return transformationTemplateTabDTO;
	}
	


	public String saveDirectory(DirectoryMetadataDTO directoryMetadataDTO) {
		if(null != directoryMetadataDTO) {
			if(null != directoryMetadataDTO.getServerEnvironmentDTO()) {
				ServerEnvironment serverEnvironment = new ServerEnvironment();
				ServerEnvironmentDTO serverEnvironmentDTO = directoryMetadataDTO.getServerEnvironmentDTO();
				BeanUtils.copyProperties(serverEnvironmentDTO, serverEnvironment);
				if(!CollectionUtils.isEmpty(serverEnvironmentDTO.getServerEnvironmentDetailDTOs())) {
					Set<ServerEnvironmentDetail> serverEnvironmentDetailSet = new HashSet<>();
					for(ServerEnvironmentDetailDTO serverEnvironmentDetailDTO : serverEnvironmentDTO.getServerEnvironmentDetailDTOs()) {
						ServerEnvironmentDetail serverEnvironmentDetail = new ServerEnvironmentDetail();
						BeanUtils.copyProperties(serverEnvironmentDetailDTO, serverEnvironmentDetail);
						serverEnvironmentDetail.setServerEnvironment(serverEnvironment);
						serverEnvironmentDetailSet.add(serverEnvironmentDetail);
					}
					serverEnvironment.setServerEnvironmentDetails(serverEnvironmentDetailSet);
				}
				serverEnvironmentRepository.deleteAll();
				serverEnvironmentRepository.saveAndFlush(serverEnvironment);
			}
			if(null != directoryMetadataDTO.getDatabaseEnvironmentDTO()) {
				DatabaseEnvironment databaseEnvironment = new DatabaseEnvironment();
				DatabaseEnvironmentDTO databaseEnvironmentDTO = directoryMetadataDTO.getDatabaseEnvironmentDTO();
				BeanUtils.copyProperties(databaseEnvironmentDTO,databaseEnvironment);
				if(!CollectionUtils.isEmpty(databaseEnvironmentDTO.getDatabaseEnvironmentDetailDTOs())) {
					Set<DatabaseEnvironmentDetail> databaseEnvironmentDetailDTOSet = new HashSet<>();
					for(DatabaseEnvironmentDetailDTO databaseEnvironmentDetailDTO : databaseEnvironmentDTO.getDatabaseEnvironmentDetailDTOs()) {
						DatabaseEnvironmentDetail databaseEnvironmentDetail = new DatabaseEnvironmentDetail();
						BeanUtils.copyProperties(databaseEnvironmentDetailDTO, databaseEnvironmentDetail);
						databaseEnvironmentDetail.setDatabaseEnvironment(databaseEnvironment);
						databaseEnvironmentDetailDTOSet.add(databaseEnvironmentDetail);
					}
					databaseEnvironment.setDatabaseEnvironmentDetails(databaseEnvironmentDetailDTOSet);;
				}
				databaseEnvironmentRepository.deleteAll();
				databaseEnvironmentRepository.saveAndFlush(databaseEnvironment);
			}
		}
		
		return "success";		
	}
	
	@Override
	public void saveSourceMetadata(String filePath) throws IOException {
			Iterator<Row> iterator = getRowFromFilePath(filePath);
			List<SourceMetadataExcelDTO> sourceMetadataExcelDTOList = new ArrayList<>();
			while (iterator.hasNext()) {
				Row currentRow = iterator.next();
				SourceMetadataExcelDTO sourceMetadataExcelDTO = new SourceMetadataExcelDTO();
				sourceMetadataExcelDTO.assignSourceMetadataExcelDTO(currentRow);
				sourceMetadataExcelDTOList.add(sourceMetadataExcelDTO);
			}
			validateSourceMetadataExcel(sourceMetadataExcelDTOList);
			Map<String, List<SourceMetadataExcelDTO>> SourceMetadataAndVariableMap = sourceMetadataExcelDTOList.stream().collect(Collectors.groupingBy(SourceMetadataExcelDTO :: getFormMetadataKey));
			List<FormMetaData> formMetaDataList = new ArrayList<>();
			List<FormVariablesMetaData> formVariablesMetaDataList = new ArrayList<>();
			for(Entry<String, List<SourceMetadataExcelDTO>> sourceMetadataAndVariableEntry : SourceMetadataAndVariableMap.entrySet()) {
				FormMetaData formMetaData = null;
				List<SourceMetadataExcelDTO> sourceMetadataExcelDTOs = sourceMetadataAndVariableEntry.getValue();
				if(!CollectionUtils.isEmpty(sourceMetadataExcelDTOs)) {
					for(SourceMetadataExcelDTO sourceMetadataExcelDTO : sourceMetadataExcelDTOs) {
						if(formMetaData == null) {
							formMetaData = populateFormMetaData(sourceMetadataExcelDTO);
							formMetaDataList.add(formMetaData);
						}

						FormVariablesMetaData formVariablesMetaData = populateFormVariablesMetaData(
								sourceMetadataExcelDTO);
						formVariablesMetaDataList.add(formVariablesMetaData);
					}
				}
			}
			
			formMetaDataRepository.saveAll(formMetaDataList);
			formVariableMetaDataRepository.saveAll(formVariablesMetaDataList);
			formMetaDataRepository.flush();
			formVariableMetaDataRepository.flush();
	}


	/**
	 * @param sourceMetadataExcelDTO
	 * @return
	 */
	private FormVariablesMetaData populateFormVariablesMetaData(SourceMetadataExcelDTO sourceMetadataExcelDTO) {
		FormVariablesMetaData formVariablesMetaData = new FormVariablesMetaData();
		FormVariablesMetaDataId formVariablesMetaDataId = new FormVariablesMetaDataId();
		formVariablesMetaDataId.setFormName(sourceMetadataExcelDTO.getFormName());
		formVariablesMetaData.setFormDescription(sourceMetadataExcelDTO.getFormDescription());
		formVariablesMetaDataId.setFormVariableName(sourceMetadataExcelDTO.getFormVariableName());
		formVariablesMetaData.setId(formVariablesMetaDataId);
		formVariablesMetaData.setFormVariableDescription(sourceMetadataExcelDTO.getFormVariableDescription());
		return formVariablesMetaData;
	}


	/**
	 * @param sourceMetadataExcelDTO
	 * @return
	 */
	private FormMetaData populateFormMetaData(SourceMetadataExcelDTO sourceMetadataExcelDTO) {
		FormMetaData formMetaData;
		formMetaData = new FormMetaData();
		FormMetaDataId formMetaDataId = new FormMetaDataId();
		formMetaDataId.setFormName(sourceMetadataExcelDTO.getFormName());
		formMetaData.setFormDescription(sourceMetadataExcelDTO.getFormDescription());
		formMetaDataId.setFormSource(sourceMetadataExcelDTO.getFormType());
		formMetaData.setId(formMetaDataId);
		return formMetaData;
	}


	/**
	 * @param filePath
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private Iterator<Row> getRowFromFilePath(String filePath) throws FileNotFoundException, IOException {
		Workbook workbook = null;
		Iterator<Row> rowIterator = null;
		FileInputStream excelFile = null;
		try {
			excelFile = new FileInputStream(new File(filePath));
			workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			rowIterator = datatypeSheet.iterator();
			rowIterator.next();
		}finally {
			excelFile.close();
			workbook.close();
		}
		return rowIterator;
	}
	
	/**
	 * @param sourceMetadataExcelDTOList
	 */
	private void validateSourceMetadataExcel(List<SourceMetadataExcelDTO> sourceMetadataExcelDTOList) {
		
		Long rowNumber = 1L;
		List<String> notNullErrorLns = new ArrayList<>();
		List<String> desErrorLns = new ArrayList<>();
		List<String> varErrorLns = new ArrayList<>();
		Map<String,String> descMap = new HashMap<>();
		Map<String,String> varMap = new HashMap<>();
		for(int i = 0 ; i < sourceMetadataExcelDTOList.size(); i++) {
			rowNumber++;
			SourceMetadataExcelDTO currentRow = sourceMetadataExcelDTOList.get(i);
			String lastDesc = descMap.put(currentRow.getFormName(), currentRow.getFormDescription());
			if(!StringUtils.isEmpty(lastDesc) && !lastDesc.equals(currentRow.getFormDescription())) {
				desErrorLns.add(rowNumber.toString());		
			}
			if(StringUtils.isEmpty(currentRow.getFormName()) || StringUtils.isEmpty(currentRow.getFormType()) || StringUtils.isEmpty(currentRow.getFormVariableName())) {
				notNullErrorLns.add(rowNumber.toString());
			}
			String lastVar = varMap.put(currentRow.getFormMetadataKey(), currentRow.getFormVariableName());
			if(!StringUtils.isEmpty(lastVar) && lastVar.equals(currentRow.getFormVariableName())) {
				varErrorLns.add(rowNumber.toString());		
			}
			
		}
		
		if(!CollectionUtils.isEmpty(notNullErrorLns)) {
			throw new RuntimeException("One of the Mandatory Field is missing at line numbers: " + String.join(",", notNullErrorLns));
		}
		if(!CollectionUtils.isEmpty(desErrorLns)) {
			throw new RuntimeException("Same Form Name have different Description at line numbers: " + String.join(",", desErrorLns));
		}
		if(!CollectionUtils.isEmpty(varErrorLns)) {
			throw new RuntimeException("Form Name, Version has duplicate Variable Name at line numbers: "+ String.join(",", varErrorLns));
		}
		
	}
	
	/**
	 * @param sdtmTargetMetadataExcelDTOList
	 */
	private void validateTargetMetadataExcel(List<SdtmTargetMetadataExcelDTO> sdtmTargetMetadataExcelDTOList) {

		Long rowNumber = 1L;
		List<String> notNullErrorLns = new ArrayList<>();
		List<String> desErrorLns = new ArrayList<>();
		List<String> varErrorLns = new ArrayList<>();
		Map<String,String> descMap = new HashMap<>();
		Map<String,String> varMap = new HashMap<>();
		for(int i = 0 ; i < sdtmTargetMetadataExcelDTOList.size(); i++) {
			rowNumber++;
			SdtmTargetMetadataExcelDTO currentRow = sdtmTargetMetadataExcelDTOList.get(i);
			String lastDesc = descMap.put(currentRow.getDomainName(), currentRow.getDescription());
			if(!StringUtils.isEmpty(lastDesc) && !currentRow.getDescription().equals(lastDesc)) {
				desErrorLns.add(rowNumber.toString());		
			}
			if(StringUtils.isEmpty(currentRow.getDomainName()) || StringUtils.isEmpty(currentRow.getVersion()) || StringUtils.isEmpty(currentRow.getSdtmVariableName())) {
				notNullErrorLns.add(rowNumber.toString());
			}
			String lastVar = varMap.put(currentRow.getSdtmTargetMetadataKey(), currentRow.getSdtmVariableName());
			if(!StringUtils.isEmpty(lastVar) && lastVar.equals(currentRow.getSdtmVariableName())) {
				varErrorLns.add(rowNumber.toString());
			}
		}
		if(!CollectionUtils.isEmpty(notNullErrorLns)) {
			throw new RuntimeException("One of the Mandatory Field is missing at line numbers " + String.join(",", notNullErrorLns));
		}
		if(!CollectionUtils.isEmpty(desErrorLns)) {
			throw new RuntimeException("Domain Name, Version combination have different Description at line numbers: "+ String.join(",", desErrorLns));
		}
		if(!CollectionUtils.isEmpty(varErrorLns)) {
			throw new RuntimeException("Domain Name, Version has duplicate Variable Name at line numbers: "+ String.join(",", varErrorLns));
		}
	}
	

	@Override	
	public void saveSdtmTargetMetadata(String filePath) throws IOException {
		Iterator<Row> iterator = getRowFromFilePath(filePath);
		List<SdtmTargetMetadataExcelDTO> sdtmTargetMetadataExcelDTOList = new ArrayList<>();
		while (iterator.hasNext()) {
			Row currentRow = iterator.next();
			SdtmTargetMetadataExcelDTO sdtmTargetMetadataExcelDTO = new SdtmTargetMetadataExcelDTO();
			sdtmTargetMetadataExcelDTO.assignSdtmTargetMetadataExcelDTO(currentRow);
			sdtmTargetMetadataExcelDTOList.add(sdtmTargetMetadataExcelDTO);
		}
		if(!CollectionUtils.isEmpty(sdtmTargetMetadataExcelDTOList)) {
			validateTargetMetadataExcel(sdtmTargetMetadataExcelDTOList);
			Map<String, List<SdtmTargetMetadataExcelDTO>> sdtmTargetMetadataAndVariableMap = sdtmTargetMetadataExcelDTOList.stream().collect(Collectors.groupingBy(SdtmTargetMetadataExcelDTO :: getSdtmTargetMetadataKey));
			List<SDTMDomainMetadata> sdtmDomainMetadataList = new ArrayList<>();
			List<SDTMVariableMetadata> sdtmVariableMetadataList = new ArrayList<>();
			for(Entry<String, List<SdtmTargetMetadataExcelDTO>> sdtmTargetMetadataAndVariableEntry : sdtmTargetMetadataAndVariableMap.entrySet()) {
				SDTMDomainMetadata sdtmDomainMetadata = null;
				List<SdtmTargetMetadataExcelDTO> sdtmTargetMetadataExcelDTOs = sdtmTargetMetadataAndVariableEntry.getValue();
				if(!CollectionUtils.isEmpty(sdtmTargetMetadataExcelDTOs)) {

					for(SdtmTargetMetadataExcelDTO sdtmTargetMetadataExcelDTO : sdtmTargetMetadataExcelDTOs) {
						if(sdtmDomainMetadata == null) {
							sdtmDomainMetadata = createSDTMDomainMetadata(sdtmTargetMetadataExcelDTO);
							sdtmDomainMetadataList.add(sdtmDomainMetadata);
						}

						SDTMVariableMetadata sdtmVariableMetadata = createSDTMVariableMetadata(sdtmTargetMetadataExcelDTO);
						sdtmVariableMetadataList.add(sdtmVariableMetadata);
					}
				}
			}

			sdtmDomainMetadataService.saveSDTMDomainMetadataList(sdtmDomainMetadataList);
			sdtmVariableMetadataService.saveSDTMVariableMetadataList(sdtmVariableMetadataList);
		}
	}


	/**
	 * @param sdtmTargetMetadataExcelDTO
	 * @return
	 */
	private SDTMVariableMetadata createSDTMVariableMetadata(SdtmTargetMetadataExcelDTO sdtmTargetMetadataExcelDTO) {
		SDTMVariableMetadata sdtmVariableMetadata = new SDTMVariableMetadata();
		SDTMVariableMetadataId sdtmVariableMetadataId = new SDTMVariableMetadataId();
		sdtmVariableMetadataId.setDomainName(sdtmTargetMetadataExcelDTO.getDomainName());
		sdtmVariableMetadataId.setSdtmVariableName(sdtmTargetMetadataExcelDTO.getSdtmVariableName());
		sdtmVariableMetadataId.setVersion(sdtmTargetMetadataExcelDTO.getVersion());
		sdtmVariableMetadata.setId(sdtmVariableMetadataId);
		sdtmVariableMetadata.setDomainDescription(sdtmTargetMetadataExcelDTO.getDescription());
		sdtmVariableMetadata.setSdtmVariableDescription(sdtmTargetMetadataExcelDTO.getSdtmVariableDescription());
		sdtmVariableMetadata.setType(sdtmTargetMetadataExcelDTO.getType());
		sdtmVariableMetadata.setControlledTermsCodelistFormat(sdtmTargetMetadataExcelDTO.getControlledTermsCodelistFormat());
		sdtmVariableMetadata.setRole(sdtmTargetMetadataExcelDTO.getRole());
		sdtmVariableMetadata.setCdsicNotes(sdtmTargetMetadataExcelDTO.getCdsicNotes());
		sdtmVariableMetadata.setCore(sdtmTargetMetadataExcelDTO.getCore());
		return sdtmVariableMetadata;
	}

	/**
	 * @param sdtmTargetMetadataExcelDTO
	 * @return
	 */
	private SDTMDomainMetadata createSDTMDomainMetadata(SdtmTargetMetadataExcelDTO sdtmTargetMetadataExcelDTO) {
		SDTMDomainMetadata sdtmDomainMetadata = new SDTMDomainMetadata();
		SDTMDomainMetadataId sdtmDomainMetadataId = new SDTMDomainMetadataId();
		sdtmDomainMetadataId.setDomainName(sdtmTargetMetadataExcelDTO.getDomainName());
		sdtmDomainMetadataId.setVersion(sdtmTargetMetadataExcelDTO.getVersion());
		sdtmDomainMetadata.setId(sdtmDomainMetadataId);
		sdtmDomainMetadata.setDescription(sdtmTargetMetadataExcelDTO.getDescription());
		sdtmDomainMetadata.setClazz(sdtmTargetMetadataExcelDTO.getClazz());
		sdtmDomainMetadata.setStructure(sdtmTargetMetadataExcelDTO.getStructure());
		sdtmDomainMetadata.setPurpose(sdtmTargetMetadataExcelDTO.getPurpose());
		sdtmDomainMetadata.setKeys(sdtmTargetMetadataExcelDTO.getKeys());
		sdtmDomainMetadata.setLocation(sdtmTargetMetadataExcelDTO.getLocation());
		sdtmDomainMetadata.setDomainNameExtension("null");
		return sdtmDomainMetadata;
	}
	
	/**
	 * @param filterParams
	 * @return
	 */
	private List<PathToSdtmMatrixDTO> getPathToSdtmMatrixDTO(TransformationTemplateFilterParams filterParams){

		StringBuffer queryStr = new StringBuffer("Select pathtosdtm0_.Matrix_ID, pathtosdtm0_.Study_Title, pathtosdtm0_.Domain_Name, pathtosdtm0_.Domain_Description, pathtosdtm0_.Domain_Name_Extension, pathtosdtm0_.Sub_Domain_Description, pathtosdtm0_.Form_Name, pathtosdtm0_.Form_Description, pathtosdtm0_.Form_Name_Extension, pathtosdtm0_.Form_Variable_Name, pathtosdtm0_.Form_Variable_Description, pathtosdtm0_.SDTM_Variable_Name, pathtosdtm0_.SDTM_Variable_Description, pathtosdtm0_.Join_Criteria, pathtosdtm0_.Transformation_Type, pathtosdtm0_.Transformation_Pseudo_Code, pathtosdtm0_.Transformation_Code, pathtosdtm0_.Domain_Status, pathtosdtm0_.Initial_Creation_Date, pathtosdtm0_.Update_Date, pathtosdtm0_.Flag, pathtosdtm0_.Notes, pathtosdtm0_.Version, pathtosdtm0_.Baseline_Name, study1_.Therapeutic_Area, study1_.Study_Source ")
				.append("from Path_To_SDTM_Matrix pathtosdtm0_ cross join Study_Metadata study1_ ")
				.append("where pathtosdtm0_.Study_Title=study1_.Study_Title ");

		if(filterParams != null){
			if(!CollectionUtils.isEmpty(filterParams.getTherapeuticAreas())){
				queryStr.append("AND study1_.Therapeutic_Area in( :therapeuticAreas ) ");
			}
			if(!CollectionUtils.isEmpty(filterParams.getStudySources())){
				queryStr.append("AND study1_.Study_Source IN( :studySources ) ");
			}
			if(!CollectionUtils.isEmpty(filterParams.getVersions())){
				queryStr.append("AND pathtosdtm0_.Version IN( :versions ) ");
			}
			if(!CollectionUtils.isEmpty(filterParams.getTemplateNames())){
				queryStr.append("AND pathtosdtm0_.Study_Title IN( :templateNames ) "); 
			}
			if(!CollectionUtils.isEmpty(filterParams.getDomainNames())){
				queryStr.append("AND pathtosdtm0_.Domain_Name IN( :domainNames ) ");	
			}
		}

		Query query = em.createNativeQuery(queryStr.toString(),"pathToSdtmMatrixDTOMapping");

		if(null != filterParams){
			if(!CollectionUtils.isEmpty(filterParams.getTherapeuticAreas())){query.setParameter("therapeuticAreas", filterParams.getTherapeuticAreas());}
			if(!CollectionUtils.isEmpty(filterParams.getStudySources())){query.setParameter("studySources", filterParams.getStudySources());}
			if(!CollectionUtils.isEmpty(filterParams.getVersions())){query.setParameter("versions",filterParams.getVersions() );}
			if(!CollectionUtils.isEmpty(filterParams.getTemplateNames())){query.setParameter("templateNames", filterParams.getTemplateNames() );}
			if(!CollectionUtils.isEmpty(filterParams.getDomainNames())){query.setParameter("domainNames",filterParams.getDomainNames() );}
		}

		List<PathToSdtmMatrixDTO> pathToSdtmMatrixDTOs = query.getResultList();	
		em.close();
		return pathToSdtmMatrixDTOs;
	}
	
}
 