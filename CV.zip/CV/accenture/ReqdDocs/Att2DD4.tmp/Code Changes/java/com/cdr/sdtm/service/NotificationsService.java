/**
 * 
 */
package com.cdr.sdtm.service;

import java.util.List;

import com.cdr.sdtm.model.Notification;

/**
 * @author twdas
 *
 */
public interface NotificationsService {
	
	List<Notification> findByStudyIds(List<String> studyId, String userRole);

	Notification create(Notification notification);

	int deleteNotifications(Integer id);

	int updateNotificationStatus(List<Integer> ids);

	int updateStopStatus(Integer id);


}
