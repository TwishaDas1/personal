/**
 * 
 */
package com.cdr.sdtm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdr.sdtm.model.Notification;
import com.cdr.sdtm.repository.NotificationsRepository;

/**
 * @author twdas
 *
 */
@Service
public class NotificationsServiceImpl implements NotificationsService{
	
	@Autowired
	NotificationsRepository notificationsRepository;

	@Override
	public List<Notification> findByStudyIds(List<String> studyIds, String userRole) {
		return notificationsRepository.findByStudyIdsAndUserRole(studyIds, userRole);
	}
	
	@Override
	public Notification create(Notification notification) {		
		
		return notificationsRepository.save(notification);
		
	}

	@Override
	public int deleteNotifications(Integer id) {
		return notificationsRepository.deleteNotifications(id);
	}

	@Override
	public int updateNotificationStatus(List<Integer> ids) {
		return notificationsRepository.updateNotificationStatus(ids);
	}

	@Override
	public int updateStopStatus(Integer id) {
		return notificationsRepository.updateStopStatus(id);
	}


}
