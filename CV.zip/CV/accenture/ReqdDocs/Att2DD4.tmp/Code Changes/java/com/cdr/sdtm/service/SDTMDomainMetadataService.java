package com.cdr.sdtm.service;

import java.util.List;

import com.cdr.sdtm.model.SDTMDomainMetadata;
import com.cdr.sdtm.model.SDTMDomainMetadataDTO;
import com.cdr.sdtm.model.SDTMVersionDomainDTO;

public interface SDTMDomainMetadataService {

	List<SDTMDomainMetadataDTO> getAllSDTMDomainMetadata();

	List<SDTMDomainMetadataDTO> getByVersionAndDomainsName(SDTMVersionDomainDTO sdtmVersionDomainDTO);

	void saveSDTMDomainMetadataList(List<SDTMDomainMetadata> sdtmDomainMetadataList);
 
}
