package com.cdr.sdtm.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.cdr.sdtm.model.DomainFilterDTO;
import com.cdr.sdtm.model.SDTMDomainMetadata;
import com.cdr.sdtm.model.SDTMDomainMetadataDTO;
import com.cdr.sdtm.model.SDTMDomainMetadataId;
import com.cdr.sdtm.model.SDTMVersionDomainDTO;
import com.cdr.sdtm.repository.SDTMDomainMetadataRepository;

@Service
@Transactional
public class SDTMDomainMetadataServiceImpl implements SDTMDomainMetadataService {

	@Autowired
	private SDTMDomainMetadataRepository sdtmDomainMetadataRepository;
	
	@Override
	public List<SDTMDomainMetadataDTO> getAllSDTMDomainMetadata() {
		List<SDTMDomainMetadata> sdtmDomainMetadatas = sdtmDomainMetadataRepository.findAll();
		List<SDTMDomainMetadataDTO> sdtmDomainMetadataDTOs = populateSDTMDomainMetadataDTO(sdtmDomainMetadatas);
		Collections.sort(sdtmDomainMetadataDTOs);
		return sdtmDomainMetadataDTOs;
	}

	private List<SDTMDomainMetadataDTO> populateSDTMDomainMetadataDTO(List<SDTMDomainMetadata> sdtmDomainMetadatas) {
		List<SDTMDomainMetadataDTO> sdtmDomainMetadataDTOs = null;
		if(!CollectionUtils.isEmpty(sdtmDomainMetadatas)) {
			sdtmDomainMetadataDTOs = new ArrayList<>();
			for(SDTMDomainMetadata sdtmDomainMetadata : sdtmDomainMetadatas) {
				SDTMDomainMetadataDTO sdtmDomainMetadataDTO = new SDTMDomainMetadataDTO();
				BeanUtils.copyProperties(sdtmDomainMetadata, sdtmDomainMetadataDTO);
				BeanUtils.copyProperties(sdtmDomainMetadata.getId(), sdtmDomainMetadataDTO);
				sdtmDomainMetadataDTOs.add(sdtmDomainMetadataDTO);
			}
		}
		return sdtmDomainMetadataDTOs;
	}
	
	@Override
	public List<SDTMDomainMetadataDTO> getByVersionAndDomainsName(SDTMVersionDomainDTO sdtmVersionDomainDTO){
		List<SDTMDomainMetadataDTO> sdtmDomainMetadataDTOs = null;
		SDTMDomainMetadataId id = new SDTMDomainMetadataId();
		List<String> domains = new ArrayList<>();
		for (DomainFilterDTO domainFilterDTO :sdtmVersionDomainDTO.getDomainDTO()) {
			domains.add(domainFilterDTO.getDomain());
		}
		if(null != sdtmVersionDomainDTO && !CollectionUtils.isEmpty(domains)) {
//chnaged here on for loop
			for(String version : sdtmVersionDomainDTO.getVersion()) {
			id.setDomainName(domains.get(0));
			id.setVersion(version);

			Optional<SDTMDomainMetadata> sdtmDomainMetadata = sdtmDomainMetadataRepository.findById(id);
			if(sdtmDomainMetadata.isPresent()) {
				List<SDTMDomainMetadata> sdtmDomainMetadatas = new ArrayList<>();
				sdtmDomainMetadatas.add(sdtmDomainMetadata.get());
				sdtmDomainMetadataDTOs = populateSDTMDomainMetadataDTO(sdtmDomainMetadatas);
			}
			}
		}
		Collections.sort(sdtmDomainMetadataDTOs);
		return sdtmDomainMetadataDTOs;
	}

	@Override
	public void saveSDTMDomainMetadataList(List<SDTMDomainMetadata> sdtmDomainMetadataList) {
		sdtmDomainMetadataRepository.saveAll(sdtmDomainMetadataList);
		sdtmDomainMetadataRepository.flush();
	}
	
}
 