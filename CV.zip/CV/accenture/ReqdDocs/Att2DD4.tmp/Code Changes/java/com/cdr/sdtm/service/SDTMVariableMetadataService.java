package com.cdr.sdtm.service;

import java.util.List;

import com.cdr.sdtm.model.SDTMVariableMetadata;
import com.cdr.sdtm.model.SDTMVariableMetadataDTO;
import com.cdr.sdtm.model.SDTMVersionDomainDTO;

public interface SDTMVariableMetadataService {

	List<SDTMVariableMetadataDTO>  getAllSDTMVariableMetadataDTO();

	List<SDTMVariableMetadataDTO> getByVersionAndDomainsName(SDTMVersionDomainDTO sdtmVersionDomainDTO);

	void saveSDTMVariableMetadataList(List<SDTMVariableMetadata> sdtmVariableMetadataList);
	 
}
