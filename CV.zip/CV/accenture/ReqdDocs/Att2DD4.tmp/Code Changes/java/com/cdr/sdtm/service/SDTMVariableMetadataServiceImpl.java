package com.cdr.sdtm.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.cdr.sdtm.model.DomainFilterDTO;
import com.cdr.sdtm.model.SDTMVariableMetadata;
import com.cdr.sdtm.model.SDTMVariableMetadataDTO;
import com.cdr.sdtm.model.SDTMVersionDomainDTO;
import com.cdr.sdtm.repository.SDTMVariableMetadataRepository;

@Service
@Transactional
public class SDTMVariableMetadataServiceImpl implements SDTMVariableMetadataService {

	@Autowired
	private SDTMVariableMetadataRepository sdtmVariableMetadataRepository;
	
	@Override
	public List<SDTMVariableMetadataDTO> getAllSDTMVariableMetadataDTO() {
		
		List<SDTMVariableMetadata> sdtmVariableMetadatas = sdtmVariableMetadataRepository.findAll();
		List<SDTMVariableMetadataDTO> sdtmVariableMetadataDTOs = poupulateSDTMVariableMetadataDTO(
				sdtmVariableMetadatas);
		Collections.sort(sdtmVariableMetadataDTOs);
		return sdtmVariableMetadataDTOs;
	}

	private List<SDTMVariableMetadataDTO> poupulateSDTMVariableMetadataDTO(
			List<SDTMVariableMetadata> sdtmVariableMetadatas) {
		List<SDTMVariableMetadataDTO> sdtmVariableMetadataDTOs = null;
		if(!CollectionUtils.isEmpty(sdtmVariableMetadatas)) {
			sdtmVariableMetadataDTOs = new ArrayList<>();
			for(SDTMVariableMetadata sdtmVariableMetadata : sdtmVariableMetadatas) {
				SDTMVariableMetadataDTO sdtmVariableMetadataDTO = new SDTMVariableMetadataDTO();
				BeanUtils.copyProperties(sdtmVariableMetadata, sdtmVariableMetadataDTO);
				BeanUtils.copyProperties(sdtmVariableMetadata.getId(), sdtmVariableMetadataDTO);
				sdtmVariableMetadataDTOs.add(sdtmVariableMetadataDTO);
			}
		}
		return sdtmVariableMetadataDTOs;
	}

	@Override
	public List<SDTMVariableMetadataDTO> getByVersionAndDomainsName(SDTMVersionDomainDTO sdtmVersionDomainDTO) {
		List<SDTMVariableMetadataDTO> sdtmVariableMetadataDTOs =  null;
		List<String> domains = new ArrayList<>();
		for (DomainFilterDTO domainFilterDTO :sdtmVersionDomainDTO.getDomainDTO()) {
			domains.add(domainFilterDTO.getDomain());
		}
		if(null != sdtmVersionDomainDTO && !CollectionUtils.isEmpty(sdtmVersionDomainDTO.getVersion()) && !CollectionUtils.isEmpty(domains)) {
		List<SDTMVariableMetadata> sdtmVariableMetadatas = sdtmVariableMetadataRepository.getByVersionAndDomainsName(sdtmVersionDomainDTO.getVersion(), domains.get(0));
		sdtmVariableMetadataDTOs = poupulateSDTMVariableMetadataDTO(
				sdtmVariableMetadatas);
		if(sdtmVariableMetadataDTOs != null) {
			Collections.sort(sdtmVariableMetadataDTOs);
		}
		}
		
		return sdtmVariableMetadataDTOs;
	}

	@Override
	public void saveSDTMVariableMetadataList(List<SDTMVariableMetadata> sdtmVariableMetadataList) {
		sdtmVariableMetadataRepository.saveAll(sdtmVariableMetadataList);
		sdtmVariableMetadataRepository.flush();
	}
	 
}
