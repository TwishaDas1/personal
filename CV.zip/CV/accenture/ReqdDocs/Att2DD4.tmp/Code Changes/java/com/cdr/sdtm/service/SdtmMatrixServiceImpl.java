package com.cdr.sdtm.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.cdr.sdtm.model.BusinessRulesFieldsSelected;
import com.cdr.sdtm.model.Domain;
import com.cdr.sdtm.model.DomainMetadata;
import com.cdr.sdtm.model.DomainsByStatus;
import com.cdr.sdtm.model.GenericMessage;
import com.cdr.sdtm.model.JobRunStatus;
import com.cdr.sdtm.model.JoinMatrix;
//import com.cdr.sdtm.model.JoinMatrix;
import com.cdr.sdtm.model.Notification;
import com.cdr.sdtm.model.PathToSdtmDashBoard;
import com.cdr.sdtm.model.PathToSdtmMatrix;
import com.cdr.sdtm.model.TherapeuticAreas;
import com.cdr.sdtm.model.Transformation;
import com.cdr.sdtm.model.VersionDTO;
import com.cdr.sdtm.repository.DomainMetadataRepository;
import com.cdr.sdtm.repository.JobRunStatusRepository;
import com.cdr.sdtm.repository.JoinMatrixRepository;
//import com.cdr.sdtm.repository.JoinMatrixRepository;
import com.cdr.sdtm.repository.MatrixCustomRepository;
import com.cdr.sdtm.repository.NotificationsRepository;
import com.cdr.sdtm.repository.SdtmMatrixRepository;
import com.cdr.sdtm.repository.StudyRepository;
import com.cdr.sdtm.repository.TherapeuticRepository;
import com.cdr.sdtm.repository.TransRepository;

@Service
public class SdtmMatrixServiceImpl implements SdtmMatrixService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SdtmMatrixServiceImpl.class);

	@Autowired
	SdtmMatrixRepository sdtmMatrixRepository;

	@Autowired
	JobRunStatusRepository jobRunStatusRepository;

	@Autowired
	TransRepository transRepository;

	@Autowired
	TherapeuticRepository therapeuticRepository;
	@Autowired
	NotificationsRepository notificationsRepository;
	@Autowired
	StudyRepository studyRepository;
	@Autowired
	DomainMetadataRepository studyDomainRepository;

	@Autowired
	MatrixCustomRepository matrixCustomRepository;
	
	@Autowired
	JoinMatrixRepository joinMatrixRepository;
	
	//@Autowired
	//JoinMatrixRepository joinMatrixRepository;
	

	@Override
	public PathToSdtmMatrix saveMatrix(PathToSdtmMatrix pathToSdtmMatrix) {
		return sdtmMatrixRepository.save(pathToSdtmMatrix);
	}

	@Override
	public List<PathToSdtmMatrix> saveMatrixForDomain(List<PathToSdtmMatrix> matrices) {
		return sdtmMatrixRepository.saveAll(matrices);
	}

	@Override
	public List<PathToSdtmMatrix> findByStudyAndDomain(String study, String domain, String version) {
		List<JobRunStatus> jobRunList = jobRunStatusRepository.findByStudyAndDomain(study, domain);
		if (jobRunList.size() == 0) {
			JobRunStatus jobRun = new JobRunStatus();
			jobRun.setStudy(study);
			jobRun.setDomain(domain);
			jobRun.setJobDisabled("N");
			jobRun.setJobBaselineName("Working_Copy");
			jobRun.setMessage("In Progress");
			jobRun.setJob_status("");
			jobRunStatusRepository.save(jobRun);

		}
		return sdtmMatrixRepository.findByStudyAndDomainAndBusinessRuleVersionOrderByBaselineNameDesc(study, domain, version);
	}

	@Override
	public List<PathToSdtmMatrix> findByStudyAndDomainAndVersion(String study, String domain, String version) {
		List<JobRunStatus> jobRunList = jobRunStatusRepository.findByStudyAndDomain(study, domain);
		if (jobRunList.size() == 0) {
			JobRunStatus jobRun = new JobRunStatus();
			jobRun.setStudy(study);
			jobRun.setDomain(domain);
			jobRun.setJobDisabled("N");
			jobRun.setJobVersion(version);
			jobRun.setJobBaselineName("Working Copy");
			jobRun.setMessage("Not started");
			jobRun.setJob_status("");
			jobRunStatusRepository.save(jobRun);

		}
		return sdtmMatrixRepository.findByStudyAndDomainAndBusinessRuleVersionOrderByBaselineNameDesc(study, domain, version);
	}
	
	@Override
	public int findWorkingCopyDomains(String study, String domain, String version) {
	
		return sdtmMatrixRepository.findWorkingCopyDomains(study, domain, version);
	}

	@Override
	public boolean updateMatrix(PathToSdtmMatrix pathToSdtmMatrix, Long id) {
		Optional<PathToSdtmMatrix> _matrixData = findById(id);
		if (_matrixData.isPresent()) {
			PathToSdtmMatrix _matrix = _matrixData.get();
			_matrix.setRuleFlag(pathToSdtmMatrix.getRuleFlag());
			_matrix.setNotes(pathToSdtmMatrix.getNotes());
			_matrix.setTargetField(pathToSdtmMatrix.getTargetField());
			_matrix.setFormLable(pathToSdtmMatrix.getFormLable());
			_matrix.setFormName(pathToSdtmMatrix.getFormName());
			_matrix.setSourceFile(pathToSdtmMatrix.getSourceFile());
			_matrix.setSourceField(pathToSdtmMatrix.getSourceField());
			_matrix.setJoinLogic(pathToSdtmMatrix.getJoinLogic());
			_matrix.setTransformation_type(pathToSdtmMatrix.getTransformation_type());
			_matrix.setTransformation_logic(pathToSdtmMatrix.getTransformation_logic());
			// _matrix.setConcatLogic(pathToSdtmMatrix.getConcatLogic());
			// _matrix.setCustomCode(pathToSdtmMatrix.getCustomCode());
			// _matrix.setDateForComputation(pathToSdtmMatrix.getDateForComputation());
			// _matrix.setOperation(pathToSdtmMatrix.getOperation());
			// _matrix.setAddVar(pathToSdtmMatrix.getAddVar());
			// if(pathToSdtmMatrix.getTransformation_logic() != null &&
			// pathToSdtmMatrix.getTransformation_logic() != "" &&
			// pathToSdtmMatrix.getTransformation_type() != null) {
			// _matrix.setBack_transformation_logic(getTransformationLogic(pathToSdtmMatrix.getTransformation_type(),pathToSdtmMatrix.getTransformation_logic()));
			// }
			_matrix.setBack_transformation_logic(pathToSdtmMatrix.getBack_transformation_logic());
			_matrix.setUpdateDate(new Date());
			sdtmMatrixRepository.save(_matrix);
			return true;
		}
		return false;
	}

	@Override
	public Optional<PathToSdtmMatrix> findById(Long id) {
		return sdtmMatrixRepository.findById(id);
	}

	@Override
	public boolean deleteById(Long matrixId) {
		Optional<PathToSdtmMatrix> _matrixData = findById(matrixId);
		if (_matrixData.isPresent()) {
			sdtmMatrixRepository.deleteById(matrixId);
			return true;
		}
		return false;
	}

	@Override
	public List<Transformation> getTransTypes() {
		return transRepository.findAll();
	}

	@Override
	public List<TherapeuticAreas> getAllTherapeuticAreas() {
		return therapeuticRepository.findAll();
	}

	public String getTransformationLogic(String type, String logic) {
		String storedLogic = "";
		// String delims = "[+\\-]+";

		switch (type) {
		case "Manual Entry":
			storedLogic = logic;
			break;

		case "Concatenation":
			storedLogic = "CONCAT(" + logic + ")";
			break;

		case "Upper":
			storedLogic = "UPPER(" + logic + ")";
			break;

		case "Lower":
			storedLogic = "LOWER(" + logic + ")";
			break;

		case "Minimum":
			storedLogic = "MIN(" + logic + ")";
			break;
		case "Maximum":
			storedLogic = "MAX(" + logic + ")";
			break;
		case "Average":
			storedLogic = "AVG(" + logic + ")";
			break;
		case "Arithemetic Operation":
			storedLogic = "ARITH(" + logic + ")";
			break;
		case "Number of Days":
			storedLogic = "DAYDIFF(" + logic + ")";
			break;
		case "ISO Date Format":
			storedLogic = "DATEISO(" + logic + ")";
			break;
		case "Lookup Transformation":
			storedLogic = "CODE_LIST(" + logic + ")";
			break;
		case "Date Computation": // String[] tokens = logic.split(delims);
			storedLogic = "DATECOMPUTATION" + logic;
			break;
		case "No Transformation":
			storedLogic = "No Transformation";
			break;
		case "Sequence Generator":
			storedLogic = "SEQGENERATOR(" + logic + ")";
			break;
		case "Custom Code":
			storedLogic = "PYTHONSCRIPT(" + logic + ")";
			break;

		}
		return storedLogic;
	}

	@Override
	public List<String> findDistinctStudies(String version) {
		return sdtmMatrixRepository.findDistinctStudies(version);
	}

	@Override
	public List<Domain> findDomainByStudy(String study) {
		List<Object[]> values = sdtmMatrixRepository.findDomainByStudy(study);
		Domain domain = null;
		List<Domain> results = new ArrayList<Domain>();
		if (values.size() > 0) {
			results.add(new Domain("All", "All"));
		}

		for (Object[] value : values) {
			domain = new Domain((String) value[0], (String) value[1]);
			results.add(domain);
		}
		return results;
	}

	@Override
	public List<String> findDistinctSDTMVariables() {
		return sdtmMatrixRepository.findDistinctSDTMVariables();
	}

	@Override
	
	
	public List<PathToSdtmMatrix> findAll(PathToSdtmMatrix matrix) {

		ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues()
				.withStringMatcher(StringMatcher.CONTAINING).withIgnorePaths("id")
				.withMatcher("study", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT))
				.withMatcher("domain", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT))
				.withMatcher("baselineName", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT))
				.withMatcher("businessRuleVersion", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT));

		Example<PathToSdtmMatrix> example = Example.of(matrix, matcher);

		return sdtmMatrixRepository.findAll(example);
	}

	@Override
	public List<PathToSdtmMatrix> getBusinessRulesByStudyAndVersion(PathToSdtmMatrix matrix) {
		List<PathToSdtmMatrix> matrixList = null;
		try {

			ExampleMatcher matcher = ExampleMatcher.matching().withIgnoreNullValues()
					.withStringMatcher(StringMatcher.CONTAINING).withIgnorePaths("id")
					.withMatcher("study", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT))
					.withMatcher("version", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT));

			Example<PathToSdtmMatrix> example = Example.of(matrix, matcher);

			matrixList = sdtmMatrixRepository.findAll(example);
			;

			if (matrixList.stream().anyMatch(x -> x.getDomainStatus().equals("In Progress"))) {
				return matrixList.stream().filter(br -> br.getDomainStatus().equals("In Progress"))
						.collect(Collectors.toList());
			} else if (matrixList.stream().anyMatch(x -> x.getDomainStatus().equals("Ready for Review"))) {
				return matrixList.stream().filter(br -> br.getDomainStatus().equals("Ready for Review"))
						.collect(Collectors.toList());
			} else if (matrixList.stream().anyMatch(x -> x.getDomainStatus().equals("Rejected"))) {
				return matrixList.stream().filter(br -> br.getDomainStatus().equals("Rejected"))
						.collect(Collectors.toList());
			} else if (matrixList.stream().anyMatch(x -> x.getDomainStatus().equals("Approved"))) {
				return matrixList.stream().filter(br -> br.getDomainStatus().equals("Approved"))
						.collect(Collectors.toList());
			} else if (matrixList.stream().anyMatch(x -> x.getDomainStatus().equals("Not Started"))) {
				return matrixList.stream().filter(br -> br.getDomainStatus().equals("Not Started"))
						.collect(Collectors.toList());
			} else {
				return new ArrayList<PathToSdtmMatrix>();
			}

			

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return matrixList;

	}

	@Override
	public PathToSdtmMatrix createMatrix(PathToSdtmMatrix pathToSdtmMatrix) {
		PathToSdtmMatrix _matrix = new PathToSdtmMatrix();
		_matrix.setRuleFlag(pathToSdtmMatrix.getRuleFlag());
		_matrix.setNotes(pathToSdtmMatrix.getNotes());
		_matrix.setStudy(pathToSdtmMatrix.getStudy());
		_matrix.setDomain(pathToSdtmMatrix.getDomain());
		_matrix.setSubDomain(pathToSdtmMatrix.getSubDomain());
		_matrix.setTargetField(pathToSdtmMatrix.getTargetField());
		_matrix.setFormLable(pathToSdtmMatrix.getFormLable());
		_matrix.setFormName(pathToSdtmMatrix.getFormName());
		_matrix.setSourceFile(pathToSdtmMatrix.getSourceFile());
		_matrix.setSourceField(pathToSdtmMatrix.getSourceField());
		_matrix.setJoinLogic(pathToSdtmMatrix.getJoinLogic());
		_matrix.setTransformation_type(pathToSdtmMatrix.getTransformation_type());
		_matrix.setTransformation_logic(pathToSdtmMatrix.getTransformation_logic());
		if (pathToSdtmMatrix.getTransformation_logic() != null && pathToSdtmMatrix.getTransformation_logic() != ""
				&& pathToSdtmMatrix.getTransformation_type() != null) {
			_matrix.setBack_transformation_logic(getTransformationLogic(pathToSdtmMatrix.getTransformation_type(),
					pathToSdtmMatrix.getTransformation_logic()));
		}
		_matrix.setInitialCreationDate(new Date());
		_matrix.setDomainLabel(pathToSdtmMatrix.getFormLable());
		_matrix.setDomainStatus(pathToSdtmMatrix.getDomainStatus());
		return sdtmMatrixRepository.save(_matrix);
	}

	@Override
	public int deleteMatricesByStudyandDomain(String study, String domain, String version) {
		return sdtmMatrixRepository.deleteMatricesByStudyandDomainandVersion(study, domain, version);
	}

	public List<Object[]> fetchObjectLevelByStudyAndDomain(String study, String version, String domain,
			String baseline) {
		return sdtmMatrixRepository.fetchObjectLevelByStudyAndDomain(study, version, domain, baseline);
	}

	public List<Object[]> fetchObjectLevelData(String study, String version) {
		return sdtmMatrixRepository.fetchObjectLevelData(study, version);
	}

	public List<PathToSdtmDashBoard> fetchDashBoardData() {
		return sdtmMatrixRepository.fetchDashBoardData().stream().filter(s -> s.getStudyStatus().equals("Active"))
				.collect(Collectors.toList());
	}

	@Override
	public List<PathToSdtmMatrix>  updateDomainStatus(String study, String domain, String status, String businessRuleVersion,String baselineName) {
		String baseline = baselineName;
		List<PathToSdtmMatrix> businessRulesList = new ArrayList<PathToSdtmMatrix>();
		if (status.equalsIgnoreCase("Approved")) {
			//raiseNotifications("Business Rules Approved", study, getDomainDescription(domain), status, "analyst");
		}
		if (status.equalsIgnoreCase("Rejected")) {
			sdtmMatrixRepository.updateDomainStatus(study, domain, status, businessRuleVersion, baseline);
			//raiseNotifications("Business Rules Rejected", study, getDomainDescription(domain), status, "analyst");
		}
		if (status.equalsIgnoreCase("Ready for Review")) {
			sdtmMatrixRepository.updateDomainStatus(study, domain, status, businessRuleVersion, baseline);
			//raiseNotifications("Business Rules Ready for Review", study, getDomainDescription(domain), status,
					//"manager");
		}
		if (status.equals("Approved")) {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			baseline = formatter.format(LocalDate.now());
			List<JoinMatrix> matrixList = joinMatrixRepository.findByStudyTitleDomainNameVersionIn(study, domain,businessRuleVersion);
			if(matrixList.size()>0) {
				joinMatrixRepository.updateJoinMatrixTable(study, domain, businessRuleVersion, baseline);
			}
			
			sdtmMatrixRepository.updateDomainStatus(study, domain, status, businessRuleVersion, baseline);
			
			PathToSdtmMatrix matrix = new PathToSdtmMatrix(study,domain);
			matrix.setBusinessRuleVersion(businessRuleVersion);
			matrix.setBaselineName(baseline);
			businessRulesList = this.findAll(matrix);
		}
		
		

		return businessRulesList;
	}

	@Override
	public int updateRuleFlag(Long id, String flag) {
		return sdtmMatrixRepository.updateRuleFlag(id, flag);
	}

	@Override
	public int updateNotesForRules(String study, String domain, List<Long> selectedRules, boolean isAllRulesSelected,
			String notes) {
		if (isAllRulesSelected) {
			return sdtmMatrixRepository.updateNotesForRules(study, domain, notes);
		} else {
			return sdtmMatrixRepository.updateNotesForSelectedRules(selectedRules, notes);
		}
	}

	@Override
	public int updateFlagsForRules(String study, String domain, List<Long> selectedRules, boolean isAllRulesSelected,
			String notes) {
		if (notes == null) {
			if (isAllRulesSelected) {
				return sdtmMatrixRepository.updateFlagsForRulesEmptyNotes(study, domain);
			} else {
				return sdtmMatrixRepository.updateFlagsForSelectedRulesEmptyNotes(selectedRules);
			}
		} else {
			if (isAllRulesSelected) {
				return sdtmMatrixRepository.updateFlagsForRules(study, domain, notes);
			} else {
				return sdtmMatrixRepository.updateFlagsForSelectedRules(selectedRules, notes);
			}
		}
	}

	@Override
	public List<PathToSdtmMatrix> importBusinessRules(String newStudy, String oldStudy, List<String> domains, String version) {

		List<PathToSdtmMatrix> matrices, insertMatrices = null;
		List<PathToSdtmMatrix> allMatrices = new ArrayList<PathToSdtmMatrix>();
		PathToSdtmMatrix matrix = null;
		List<String> domainLabelList = new ArrayList<String>();
		for (String domain : domains) {
			
			//Get the business rules for the old study
			matrices = findByStudyAndDomain(oldStudy, domain, version);
			if (matrices != null && matrices.size() > 0) {
				//delete the working copy rules if already existed for new study
				int deleted = deleteMatricesByStudyandDomain(newStudy, domain, version);
			}
			
			if (matrices != null && matrices.size() > 0) {
				insertMatrices = new ArrayList<PathToSdtmMatrix>();
				for (PathToSdtmMatrix template : matrices) {
					matrix = new PathToSdtmMatrix();
					matrix.setStudy(newStudy);
					matrix.setDomain(template.getDomain());
					matrix.setDomainLabel(template.getDomainLabel());
					matrix.setDomainNameExt(template.getDomainNameExt());
					matrix.setSubDomain(template.getSubDomain());
					matrix.setFormName(template.getFormName());
					matrix.setFormLable(template.getFormLable());
					matrix.setFormExt(template.getFormExt());
					matrix.setTargetField(template.getTargetField());
					matrix.setTargetFile(template.getTargetFile());
					matrix.setSourceFile(template.getSourceFile());
					matrix.setSourceField(template.getSourceField());
					matrix.setJoinLogic(template.getJoinLogic());
					matrix.setTransformation_type(template.getTransformation_type());
					matrix.setTransformation_logic(template.getTransformation_logic());
					matrix.setBack_transformation_logic(template.getBack_transformation_logic());
					matrix.setDomainStatus("In Progress");
					matrix.setRuleFlag(template.getRuleFlag());
					matrix.setNotes(template.getNotes());
					matrix.setInitialCreationDate(new Date());
					matrix.setBaselineName("Working_Copy");
					matrix.setBusinessRuleVersion(template.getBusinessRuleVersion());

					insertMatrices.add(matrix);
					if (!domainLabelList.contains(template.getDomainLabel())) {
						domainLabelList.add(template.getDomainLabel());
						raiseNotifications("Domain", newStudy, template.getDomainLabel(), null);
					}

				}
				allMatrices.addAll(saveMatrixForDomain(insertMatrices));
			}
		}

		// raiseNotifications("Domain", newStudy, null, null,domainLabelList);
		return allMatrices;
	}

	@Override
	public List<String> checkForDomains(String newStudy, List<String> domains, String studyVersion) {
		List<String> existingDomains = new ArrayList<String>();
		for (String domain : domains) {
			int count = findWorkingCopyDomains(newStudy, domain, studyVersion);
			if (count > 0) {
				existingDomains.add(domain);
			}
		}
		return existingDomains;
	}

	private void raiseNotifications(String changedField, String study, String domain, String status) {
		Notification notification = new Notification();
		LOGGER.info("raising notifications...");
		notification.setCreate_dt(LocalDateTime.now());
		LOGGER.info("fetching date..." + notification.getCreate_dt());
		notification.setNotification_delete("N");
		notification.setNotification_desc(getNotificationDesc(changedField, study, domain, status));
		notification.setNotification_stop("N");
		LOGGER.info("fetching study...");
		notification.setStudyID(studyRepository.getStudyId(study));
		LOGGER.info("fetching study..." + notification.getStudyID());
		notification.setTask_desc(getTaskDesc(changedField, domain));
		notification.setTask_due_date(getTaskDueDate(changedField, notification.getCreate_dt()));

		notificationsRepository.save(notification);
		// Check if there are tasks to close
		List<String> studyIdsToFetch = new ArrayList();
		studyIdsToFetch.add(notification.getStudyID());
		List<Notification> listOfRelatedNotifications = notificationsRepository.findByStudyIds(studyIdsToFetch);
		if (changedField == "Business Rules Ready for Review") {
			System.out.println("inside loop for business rules ready for review");
			for (Notification notificationInLoop : listOfRelatedNotifications) {
				if (notificationInLoop.getTask_desc() != null
						&& (notificationInLoop.getTask_desc().contains("Configure business rules for")
								|| notificationInLoop.getTask_desc()
										.contains("Address issues with rejected business rules for"))) {
					if (notificationInLoop.getTask_desc().contains(domain)) {
						System.out.println("updating table inside loop for business rules ready for review");
						notificationsRepository.updateTaskAsComplete(notificationInLoop.getId());
					}
				}
			}
		}
		if ((changedField == "Business Rules Approved") || (changedField == "Business Rules Rejected")) {
			for (Notification notificationInLoop : listOfRelatedNotifications) {
				if (notificationInLoop.getTask_desc() != null
						&& notificationInLoop.getTask_desc().contains("Review business rule configuration for")) {
					if (notificationInLoop.getTask_desc().contains(domain)) {
						notificationsRepository.updateTaskAsComplete(notificationInLoop.getId());
					}
				}
			}
		}
	}

	private void raiseNotifications(String changedField, String study, String domain, String status, String userRole) {
		Notification notification = new Notification();
		LOGGER.info("raising notifications...");
		notification.setCreate_dt(LocalDateTime.now());
		LOGGER.info("fetching date..." + notification.getCreate_dt());
		notification.setNotification_delete("N");
		notification.setNotification_desc(getNotificationDesc(changedField, study, domain, status));
		notification.setNotification_stop("N");
		LOGGER.info("fetching study...");
		notification.setStudyID(studyRepository.getStudyId(study));
		LOGGER.info("fetching study..." + notification.getStudyID());
		notification.setTask_desc(getTaskDesc(changedField, domain));
		notification.setTask_due_date(getTaskDueDate(changedField, notification.getCreate_dt()));
		notification.setUserRole(userRole);

		notificationsRepository.save(notification);
		// Check if there are tasks to close
		List<String> studyIdsToFetch = new ArrayList();
		studyIdsToFetch.add(notification.getStudyID());
		List<Notification> listOfRelatedNotifications = notificationsRepository.findByStudyIds(studyIdsToFetch);
		if (changedField == "Business Rules Ready for Review") {
			System.out.println("inside loop for business rules ready for review");
			for (Notification notificationInLoop : listOfRelatedNotifications) {
				if (notificationInLoop.getTask_desc() != null
						&& (notificationInLoop.getTask_desc().contains("Configure business rules for")
								|| notificationInLoop.getTask_desc()
										.contains("Address issues with rejected business rules for"))) {
					if (notificationInLoop.getTask_desc().contains(domain)) {
						System.out.println("updating table inside loop for business rules ready for review");
						notificationsRepository.updateTaskAsComplete(notificationInLoop.getId());
					}
				}
			}
		}
		if ((changedField == "Business Rules Approved") || (changedField == "Business Rules Rejected")) {
			for (Notification notificationInLoop : listOfRelatedNotifications) {
				if (notificationInLoop.getTask_desc() != null
						&& notificationInLoop.getTask_desc().contains("Review business rule configuration for")) {
					if (notificationInLoop.getTask_desc().contains(domain)) {
						notificationsRepository.updateTaskAsComplete(notificationInLoop.getId());
					}
				}
			}
		}
	}

	private LocalDateTime getTaskDueDate(String changedField, LocalDateTime create_dt) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		if (changedField == "Domain") {
			// LocalDate taskDueDate = LocalDate.parse(create_dt, formatter).plus(2,
			// ChronoUnit.WEEKS);
			create_dt.plusWeeks(2);

			return create_dt.plusWeeks(2);
		}
		if (changedField == "Business Rules Ready for Review") {
			// LocalDate taskDueDate = LocalDateTime.p.parse(create_dt, formatter).plus(1,
			// ChronoUnit.WEEKS);

			return create_dt.plusWeeks(2).plusWeeks(1);
		}
		return null;
	}

	private String getTaskDesc(String changedField, String domain) {
		if (changedField == "Domain") {
			return "Configure business rules for " + domain + " domain ";
		}
		if (changedField == "Business Rules Rejected") {
			return "Address issues with rejected business rules for " + domain + " domain.";
		}
		if (changedField == "Business Rules Ready for Review") {
			return "Review business rule configuration for  " + domain + " domain";
		}
		return null;
	}

	private String getNotificationDesc(String changedField, String study, String domain, String status) {

		if (changedField == "Business Rules Approved") {
			return domain + " domain's business rules have been approved";
		}
		if (changedField == "Business Rules Rejected") {
			return domain + " domain's business rules have been rejected";
		}
		if (changedField == "Business Rules Ready for Review") {
			return domain + " domain is ready for review";
		}
		if (changedField == "Domain") {
			return domain + " domain has been added to " + study
					+ " study. Please complete business rules configuration within 2 weeks.";
		}

		return null;
	}

	private String getDomainDescription(String domain) {
		DomainMetadata details = studyDomainRepository.findById(domain).orElse(null);
		if (details != null) {
			domain = details.getDescription();
		}
		System.out.println("getDomainDescription " + domain);

		return domain;
	}

	private String getDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localDate = LocalDate.now();
		return dtf.format(localDate).toString(); // 2016-11-16
	}

	@Override
	public List<String> getVersionsByStudyTitle(String studyTitle) {
		List<String> domainStatusList = new ArrayList<>();
		Set<String> versionsSet = new HashSet<>();
		List<String> versionsList = new ArrayList<>();
		
		domainStatusList.add("In Progress");
		domainStatusList.add("Approved");
		domainStatusList.add("Ready For Review");
		domainStatusList.add("Not Started");
		Set<VersionDTO> versionDTOsSet = sdtmMatrixRepository.getApplicableVersionDTOs(studyTitle, domainStatusList);
		
		if(!CollectionUtils.isEmpty(versionDTOsSet)) {
			List<VersionDTO> versionDTOsList = new ArrayList<>(versionDTOsSet); 
			Collections.sort(versionDTOsList, Comparator.reverseOrder());
			
			for(VersionDTO versionDTOList : versionDTOsList) {
				if(versionDTOList.getBusinessRuleVersion().equals("Working_Copy")) {
					// versionsList.add(0, versionDTOList.getBusinessRuleVersion());
				} else {
					versionsSet.add(versionDTOList.getBusinessRuleVersion());
				}
			}
		
				versionsList.addAll(versionsSet);
		}
		
		return versionsList;
	}
	

	@Override
	public DomainsByStatus getDomainsByStudyAndVersion(String studyTitle, String version) {
		DomainsByStatus domainStatus = new DomainsByStatus();
		List<Domain> list = matrixCustomRepository.getDomainsByStudyAndVersion(studyTitle, version);
		domainStatus.setApproved(list.stream().filter(s -> s.getDomainStatus().equals("Approved"))
				.sorted(Comparator.comparing(Domain::getDomainLabel)).collect(Collectors.toList()));
		domainStatus.setNotStarted(list.stream().filter(s -> s.getDomainStatus().equals("Not Started"))
				.sorted(Comparator.comparing(Domain::getDomainLabel)).collect(Collectors.toList()));
		domainStatus.setReadyForReview(list.stream().filter(s -> s.getDomainStatus().equals("Ready for Review"))
				.sorted(Comparator.comparing(Domain::getDomainLabel)).collect(Collectors.toList()));
		domainStatus.setRejected(list.stream().filter(s -> s.getDomainStatus().equals("Rejected"))
				.sorted(Comparator.comparing(Domain::getDomainLabel)).collect(Collectors.toList()));
		domainStatus.setInProgress(list.stream().filter(s -> s.getDomainStatus().equals("In Progress"))
				.sorted(Comparator.comparing(Domain::getDomainLabel)).collect(Collectors.toList()));
		return domainStatus;
	}

	@Override
	public List<String> getBaselinesByStudyVersionDomain(String studyTitle, String version, String domain) {
		List<String> baselinesList =  sdtmMatrixRepository.getBaselinesByStudyVersionDomain(studyTitle, version, domain);
		List<String> list = new ArrayList<>();
		List<String> orderedBaselinesList = new ArrayList<>();
		for(String baselines : baselinesList) {
			if(baselines.equals("Working_Copy")) {
				orderedBaselinesList.add(0,baselines);
			}
			else {
				list.add(baselines);
			}
		}
		orderedBaselinesList.addAll(list);
		return orderedBaselinesList;
	}

	@Override
	public String deleteWorkingCopyBR(BusinessRulesFieldsSelected brFields) {
		String message;
		int count = sdtmMatrixRepository.deleteWorkingCopyBR(brFields.getBrStudy(), brFields.getBrSdtmDomain(),
				brFields.getBrVersion());
		if (count > 0) {
			return "Records Deleted Successfully";
		} else {
			return "No Records Deleted";
		}
		
	}

	

}
