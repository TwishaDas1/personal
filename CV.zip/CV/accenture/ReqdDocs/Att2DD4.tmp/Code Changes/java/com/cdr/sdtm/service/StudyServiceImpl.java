package com.cdr.sdtm.service;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.ExampleMatcher.StringMatcher;
import org.springframework.stereotype.Service;

import com.cdr.sdtm.model.Notification;
import com.cdr.sdtm.model.Study;
import com.cdr.sdtm.repository.MatrixCustomRepository;
import com.cdr.sdtm.repository.NotificationsRepository;
import com.cdr.sdtm.repository.StudyRepository;

@Service
public class StudyServiceImpl implements StudyService {
	
	public static final String ALL = "all";
	
	@Autowired
	StudyRepository studyRepository;
	@Autowired
	NotificationsRepository notificationsRepository;
	
	@Autowired
	MatrixCustomRepository matrixCustomRepository;
	
	
	@Override
	public List<Study> findByStudyID(String studyID) {
		return studyRepository.findByStudyID(studyID);
	}

	@Override
	public Study createStudy(Study study, String userRole) {

		study.setInitialCreationDate(LocalDateTime.now());
		
		//if Study version is changed remove all the working copies
		if(study.isVersionChanged()) {
			studyRepository.deleteStudyWorkingCopies(study.getTitle());
		}
		
		//notifications
		if(study.getPhase()!=null) {
		 raiseNotifications("Phase",study.getStudyID(),null,study.getPhase(),study.getTitle(),userRole);			 
		}
		if(study.getManager()!=null) {
			raiseNotifications("Manager",study.getStudyID(),null,study.getManager(),study.getTitle(),userRole);			 
		}
		if(study.getAnalyst()!=null) {
			 raiseNotifications("Analyst",study.getStudyID(),null,study.getAnalyst(),study.getTitle(), userRole);			 
		}
		 if(study.getDbLockDate()!=null) {
			 raiseNotifications("DbLockDateAdded",study.getStudyID(),null,getDate(study.getDbLockDate()),study.getTitle(), userRole);			 
		 }
		return studyRepository.save(study);
		
	}

	@Override
	public boolean updateStudy(Study study, String id) {
		 Optional<Study> _studyData = findById(id);
		 if(_studyData.isPresent()) {
		 Study _study = _studyData.get();
		 _study.setTitle(study.getTitle());
		 
		 if( !(_study.getPhase().equalsIgnoreCase(study.getPhase()))) {
			 raiseNotifications("Phase",id,_study.getPhase(),study.getPhase(),study.getTitle(), "");			 
		 }
		 _study.setPhase(study.getPhase());
		 _study.setStatus(study.getStatus());
		 _study.setTherapeuticArea(study.getTherapeuticArea());
		 _study.setSource(study.getSource());
		 
		 if( !(_study.getManager().equalsIgnoreCase(study.getManager()))) {
			 raiseNotifications("Manager",id,_study.getManager(),study.getManager(),study.getTitle(), "");			 
		 }
		 _study.setManager(study.getManager());
		 
		 if( !(_study.getAnalyst().equalsIgnoreCase(study.getAnalyst()))) {
			 raiseNotifications("Analyst",id,_study.getAnalyst(),study.getAnalyst(),study.getTitle(), "");			 

		 }
		 _study.setAnalyst(study.getAnalyst());
		 
		 if(_study.getDbLockDate()==null && study.getDbLockDate()!=null) {
			 raiseNotifications("DbLockDateAdded",id,null,getDate(study.getDbLockDate()),study.getTitle(), "");			 
		 }
		 else if( (_study.getDbLockDate().after(study.getDbLockDate())) 
				 || (_study.getDbLockDate().before(study.getDbLockDate()))) {
			 raiseNotifications("DbLockDateChanged",id,getDate(_study.getDbLockDate()),
					getDate(study.getDbLockDate()),study.getTitle(),"" );			 
		 }
		 _study.setDbLockDate(study.getDbLockDate());
		  studyRepository.save(_study);
		  return true;
		 }
		 return false;
	}

	private void raiseNotifications(String changedField,String id,String previousValue,String newValue,String studyName, String userRole ) {
		Notification notification = new Notification();
		
		notification.setCreate_dt(LocalDateTime.now());
		notification.setNotification_delete("N");
		notification.setNotification_desc(getNotificationDesc(changedField,previousValue,newValue,studyName));
		notification.setNotification_stop("N");
		notification.setStudyID(id);
		notification.setTask_desc(getTaskDesc(changedField));
		notification.setTask_due_date(getTaskDueDate(changedField,notification.getCreate_dt()));
		notification.setUserRole(userRole);
		
		notificationsRepository.save(notification);
	}

	private LocalDateTime getTaskDueDate(String changedField, LocalDateTime create_dt) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

		if(changedField =="Domain") {
	       // LocalDate taskDueDate = LocalDate.parse(create_dt, formatter).plus(2, ChronoUnit.WEEKS);

			return create_dt.plusWeeks(2);			
		}
		return null;
	}

	private String getTaskDesc(String changedField) {
		if(changedField =="Domain") {
			return "Configure business rules for [Domain description name] domain";			
		}
		return null;
	}

	private String getNotificationDesc(String changedField ,String previousVal , String newVal,String studyName) {
		
		if(changedField =="Manager") {
			return "You have been assigned Study Manager to "+studyName;
		}
		if(changedField =="Phase") {
			return "Study phase has been changed from "+previousVal+" to "+newVal;
		}
		if(changedField =="Analyst") {
			return "You have been assigned Study Analyst to "+studyName;
		}
		if(changedField =="DbLockDateAdded") {
			return "DB Lock Date has been set as "+newVal;
		}
		if(changedField =="DbLockDateChanged") {
			return "DB Lock Date has been changed from "+previousVal+" to "+newVal;
		}

		return null;
	}

	private String getDate(Timestamp ts) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localDate ;
		if(ts==null) {
		 localDate = LocalDate.now();
		}else {
		 localDate = ts.toLocalDateTime().toLocalDate();
		}
		return dtf.format(localDate).toString(); //2016-11-16
	}

	@Override
	public List<Study> getStudies() {
		return studyRepository.findAll();
	}

	@Override
	public boolean deleteById(String id) {
		Optional<Study> _studyData = findById(id);
		if(_studyData.isPresent()) {
			studyRepository.deleteById(id);
			return true;
		} 
		return false;
	}

	@Override
	public Optional<Study> findById(String id) {
		return studyRepository.findById(id);
	}
	
	public List<Study> findAll(Study study) {
		
		if(ALL.equalsIgnoreCase(study.getTherapeuticArea())) {
			study.setTherapeuticArea(null);
		}
		if(ALL.equalsIgnoreCase(study.getTitle())) {
			study.setTitle(null);
		}
		if(ALL.equalsIgnoreCase(study.getPhase())) {
			study.setPhase(null);
		}
		if(ALL.equalsIgnoreCase(study.getStatus())) {
			study.setStatus(null);
		}
		if(ALL.equalsIgnoreCase(study.getSource())) {
			study.setSource(null);
		}
		
		ExampleMatcher matcher = ExampleMatcher.matching()
											   .withIgnoreNullValues()
											   .withStringMatcher(StringMatcher.CONTAINING)
											   .withIgnorePaths("id")
											   .withMatcher("status", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT))
											   .withMatcher("phase", ExampleMatcher.GenericPropertyMatcher.of(StringMatcher.EXACT));
		
		Example<Study> example = Example.of(study, matcher);
		
		return studyRepository.findAll(example);
		
	}

	@Override
	public List<Study> getStudyTitles() {
		return matrixCustomRepository.getStudyTitles(); 
	}

	@Override
	public List<String> findStudyIds() {
		return studyRepository.findStudyIds(); 
	}

	@Override
	public List<String> findStudiesBytherapeuticArea(String therapeuticArea) {
		return studyRepository.findStudiesBytherapeuticArea(therapeuticArea);
	}
	

}
